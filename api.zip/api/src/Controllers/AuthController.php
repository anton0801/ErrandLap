<?php

declare(strict_types=1);

namespace ErrandRun\Controllers;

use ErrandRun\Core\ApiException;
use ErrandRun\Core\Clock;
use ErrandRun\Core\Config;
use ErrandRun\Core\Database;
use ErrandRun\Core\Request;
use ErrandRun\Core\Response;
use ErrandRun\Core\Validator;
use ErrandRun\Http\AuthContext;
use ErrandRun\Security\AuditLog;
use ErrandRun\Security\PasswordService;
use ErrandRun\Security\RateLimiter;
use ErrandRun\Security\TokenService;
use ErrandRun\Sync\SettingsRepository;

final class AuthController
{
    private const LOCK_THRESHOLD = 10;
    private const LOCK_SECONDS   = 900;

    public function register(Request $request): void
    {
        RateLimiter::hit(RateLimiter::bucket('register:ip', $request->ip), Config::int('RATE_REGISTER_PER_IP', 5), 3600);

        $validator = new Validator($request->json());
        $validator->rejectUnknown(['email', 'password', 'display_name', 'device_name']);
        $email = $validator->email('email');
        $password = $validator->password('password');
        $displayName = $validator->string('display_name', false, 0, 80) ?? '';
        $deviceName = $validator->string('device_name', false, 0, 120) ?? 'Unknown device';
        $validator->stop();

        /** @var string $email */
        /** @var string $password */
        $policyError = PasswordService::policyError($password, $email, $displayName);
        if ($policyError !== null) {
            throw ApiException::validation(['password' => $policyError]);
        }

        $now = Clock::now();
        $userId = TokenService::uuid();

        try {
            Database::run(
                'INSERT INTO users (id, email, password_hash, display_name, password_changed_at, created_at, updated_at)
                 VALUES (:id, :email, :hash, :name, :changed, :created, :updated)',
                [
                    'id'      => $userId,
                    'email'   => $email,
                    'hash'    => PasswordService::hash($password),
                    'name'    => $displayName,
                    'changed' => Clock::sql($now),
                    'created' => Clock::sql($now),
                    'updated' => Clock::sql($now),
                ],
            );
        } catch (\PDOException $exception) {
            if ($exception->getCode() === '23000') {
                AuditLog::record(AuditLog::REGISTER, 'duplicate', $request, null, $email);
                // Deliberately the same wording as a valid-but-taken address elsewhere,
                // so this endpoint cannot be used to enumerate accounts beyond what
                // signing up already reveals.
                throw ApiException::conflict('That email address is already registered.');
            }
            throw $exception;
        }

        $tokens = TokenService::issue($userId, $deviceName, $request);
        AuditLog::record(AuditLog::REGISTER, 'success', $request, $userId, $email);

        Response::json([
            'user'   => $this->userPayload($userId, $email, $displayName, Clock::iso($now)),
            'tokens' => $tokens,
        ], 201);
    }

    public function login(Request $request): void
    {
        $validator = new Validator($request->json());
        $validator->rejectUnknown(['email', 'password', 'device_name']);
        $email = $validator->email('email');
        $rawPassword = $validator->raw('password');
        $deviceName = $validator->string('device_name', false, 0, 120) ?? 'Unknown device';
        if (!is_string($rawPassword) || $rawPassword === '') {
            $validator->addError('password', 'This field is required.');
        }
        $validator->stop();

        /** @var string $email */
        /** @var string $password */
        $password = (string) $rawPassword;

        RateLimiter::hit(RateLimiter::bucket('login:ip', $request->ip), Config::int('RATE_LOGIN_PER_IP', 30), 900);
        $emailBucket = RateLimiter::bucket('login:email', $email);
        RateLimiter::hit($emailBucket, Config::int('RATE_LOGIN_PER_EMAIL', 10), 900);

        $user = Database::first(
            'SELECT id, email, password_hash, display_name, failed_attempts, locked_until, created_at
               FROM users WHERE email = :email LIMIT 1',
            ['email' => $email],
        );

        if ($user === null) {
            // Same amount of work as a real verification, so timing says nothing.
            PasswordService::burnTime($password);
            AuditLog::record(AuditLog::LOGIN, 'unknown_account', $request, null, $email);
            throw ApiException::unauthorized('That email or password is not right.', 'invalid_credentials');
        }

        $lockedUntil = Clock::fromSql($user['locked_until'] === null ? null : (string) $user['locked_until']);
        if ($lockedUntil !== null && $lockedUntil > Clock::now()) {
            AuditLog::record(AuditLog::LOGIN, 'locked', $request, (string) $user['id'], $email);
            throw ApiException::locked(
                'Too many failed attempts. This account is locked for a short while.',
                max(1, $lockedUntil->getTimestamp() - time()),
            );
        }

        if (!PasswordService::verify($password, (string) $user['password_hash'])) {
            $attempts = ((int) $user['failed_attempts']) + 1;
            $lock = $attempts >= self::LOCK_THRESHOLD ? Clock::sql(Clock::plusSeconds(self::LOCK_SECONDS)) : null;
            Database::run(
                'UPDATE users SET failed_attempts = :attempts, locked_until = :lock, updated_at = :now WHERE id = :id',
                ['attempts' => $attempts, 'lock' => $lock, 'now' => Clock::sql(), 'id' => $user['id']],
            );
            AuditLog::record(AuditLog::LOGIN, 'bad_password', $request, (string) $user['id'], $email, ['attempts' => $attempts]);
            throw ApiException::unauthorized('That email or password is not right.', 'invalid_credentials');
        }

        if (PasswordService::needsRehash((string) $user['password_hash'])) {
            Database::run(
                'UPDATE users SET password_hash = :hash WHERE id = :id',
                ['hash' => PasswordService::hash($password), 'id' => $user['id']],
            );
        }

        Database::run(
            'UPDATE users SET failed_attempts = 0, locked_until = NULL, updated_at = :now WHERE id = :id',
            ['now' => Clock::sql(), 'id' => $user['id']],
        );
        RateLimiter::clear($emailBucket);

        $tokens = TokenService::issue((string) $user['id'], $deviceName, $request);
        AuditLog::record(AuditLog::LOGIN, 'success', $request, (string) $user['id'], $email);

        Response::json([
            'user' => $this->userPayload(
                (string) $user['id'],
                (string) $user['email'],
                (string) $user['display_name'],
                Clock::isoFromSql((string) $user['created_at']) ?? Clock::iso(),
            ),
            'tokens' => $tokens,
        ]);
    }

    public function refresh(Request $request): void
    {
        RateLimiter::hit(RateLimiter::bucket('refresh:ip', $request->ip), Config::int('RATE_REFRESH_PER_IP', 120), 900);

        $validator = new Validator($request->json());
        $validator->rejectUnknown(['refresh_token']);
        $token = $validator->string('refresh_token', true, 10, 200);
        $validator->stop();

        /** @var string $token */
        try {
            $rotated = TokenService::rotate($token, $request);
        } catch (ApiException $exception) {
            if ($exception->code() === 'refresh_reuse') {
                AuditLog::record(AuditLog::TOKEN_REUSE, 'revoked', $request);
            }
            throw $exception;
        }

        $user = Database::first(
            'SELECT id, email, display_name, created_at FROM users WHERE id = :id LIMIT 1',
            ['id' => $rotated['user_id']],
        );
        if ($user === null) {
            throw ApiException::unauthorized('This account no longer exists.', 'account_deleted');
        }

        AuditLog::record(AuditLog::REFRESH, 'success', $request, (string) $user['id']);

        Response::json([
            'user' => $this->userPayload(
                (string) $user['id'],
                (string) $user['email'],
                (string) $user['display_name'],
                Clock::isoFromSql((string) $user['created_at']) ?? Clock::iso(),
            ),
            'tokens' => [
                'session_id'         => $rotated['session_id'],
                'access_token'       => $rotated['access_token'],
                'refresh_token'      => $rotated['refresh_token'],
                'access_expires_at'  => $rotated['access_expires_at'],
                'refresh_expires_at' => $rotated['refresh_expires_at'],
            ],
        ]);
    }

    public function logout(Request $request, AuthContext $auth): void
    {
        TokenService::revokeSession($auth->sessionId, 'logout');
        AuditLog::record(AuditLog::LOGOUT, 'success', $request, $auth->userId);
        Response::json(['signed_out' => true]);
    }

    public function logoutAll(Request $request, AuthContext $auth): void
    {
        $count = TokenService::revokeAllForUser($auth->userId, 'logout_all');
        AuditLog::record(AuditLog::LOGOUT_ALL, 'success', $request, $auth->userId, null, ['sessions' => $count]);
        Response::json(['signed_out' => true, 'sessions_ended' => $count]);
    }

    /** @return array<string, mixed> */
    private function userPayload(string $id, string $email, string $displayName, string $createdAt): array
    {
        $settings = SettingsRepository::fetch($id);
        return [
            'id'           => $id,
            'email'        => $email,
            'display_name' => $displayName,
            'created_at'   => $createdAt,
            'settings'     => $settings,
        ];
    }
}
