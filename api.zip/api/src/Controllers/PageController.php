<?php

declare(strict_types=1);

namespace ErrandRun\Controllers;

use ErrandRun\Core\Config;
use ErrandRun\Core\Request;
use ErrandRun\Core\Response;

/**
 * The public pages: the front page, the privacy page and the support page.
 *
 * They live in the same deployment as the API because the App Store needs a
 * privacy URL and a support URL, and one domain is one thing to keep alive.
 * Everything the pages say about names and addresses comes from configuration —
 * nothing about the operator is written into the source.
 */
final class PageController
{
    public function home(Request $request): void
    {
        Response::html($this->render('home', [
            'title'       => $this->site()['name'] . ' — plan the errands that actually fit today',
            'description' => 'Errand Run plans household errands around real opening hours, real travel'
                . ' time and the free window you actually have.',
            'activePage'  => '/',
        ]));
    }

    public function privacy(Request $request): void
    {
        Response::html($this->render('privacy', [
            'title'       => 'Privacy — ' . $this->site()['name'],
            'description' => 'What Errand Run stores, why, for how long, and how to delete all of it.',
            'activePage'  => '/conditions-privacy',
        ]));
    }

    public function support(Request $request): void
    {
        Response::html($this->render('support', [
            'title'       => 'Support — ' . $this->site()['name'],
            'description' => 'How to get help with Errand Run, and answers to the questions that come up most.',
            'activePage'  => '/support',
        ]));
    }

    /** A tiny mark in the app's colours, so a browser tab is not blank. */
    public function favicon(Request $request): void
    {
        $svg = '<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 64 64">'
            . '<defs><linearGradient id="f" x1="0" y1="1" x2="1" y2="0">'
            . '<stop offset="0" stop-color="#FF3426"/><stop offset="0.52" stop-color="#FF7A18"/>'
            . '<stop offset="1" stop-color="#FFD24A"/></linearGradient></defs>'
            . '<rect width="64" height="64" rx="12" fill="#171316"/>'
            . '<path d="M20 46 L38 46 L44 18 L26 18 Z" fill="url(#f)"/>'
            . '<rect x="30" y="8" width="9" height="9" transform="rotate(45 34.5 12.5)" fill="#FFD24A"/>'
            . '</svg>';

        http_response_code(200);
        header('Content-Type: image/svg+xml');
        header('Cache-Control: public, max-age=604800');
        header_remove('Pragma');
        echo $svg;
    }

    /** Search engines have nothing to index behind /v1. */
    public function robots(Request $request): void
    {
        http_response_code(200);
        header('Content-Type: text/plain; charset=utf-8');
        header('Cache-Control: public, max-age=86400');
        header_remove('Pragma');
        echo "User-agent: *\nDisallow: /v1/\nAllow: /\n";
    }

    /**
     * A browser that wandered onto a wrong address gets a page, not a JSON object.
     */
    public function notFound(Request $request): void
    {
        $content = '<span class="section-label">404</span>'
            . '<h1>Nothing Here</h1>'
            . '<p class="lead">That address does not exist on this site.</p>'
            . '<div class="actions">'
            . '<a class="btn fire" href="/"><span>Front Page</span></a>'
            . '<a class="btn ghost" href="/support"><span>Support</span></a>'
            . '</div>';

        Response::html($this->page($content, [
            'title'       => 'Not found — ' . $this->site()['name'],
            'description' => '',
            'activePage'  => '',
        ]), 404, 0);
    }

    /**
     * Whatever the operator configured. Nothing here is invented in code: with no
     * configuration the pages still read correctly, just less specifically.
     *
     * @return array<string, string>
     */
    private function site(): array
    {
        // A key present but empty counts as not set, so a half-filled .env
        // still produces a page that reads properly.
        $value = static function (string $key, string $fallback): string {
            $raw = trim((string) Config::get($key, ''));
            return $raw === '' ? $fallback : $raw;
        };

        return [
            // Must match AppMode in the app: while the shipped build keeps
            // everything on the phone, these pages must not describe accounts,
            // syncing or the mini-game, because none of that is in the app yet.
            'connected'       => Config::get('APP_MODE', 'local') === 'connected',
            'name'            => $value('SITE_NAME', 'Errand Run'),
            'owner'           => $value('SITE_OWNER', 'The developer of Errand Run'),
            'support_email'   => $value('SUPPORT_EMAIL', 'support@runoferrandapp.site'),
            'app_store'       => $value('APP_STORE_URL', ''),
            'region'          => $value('SITE_REGION', ''),
            'privacy_updated' => $value(
                'PRIVACY_UPDATED',
                date('j F Y', filemtime(__DIR__ . '/../Views/privacy.php') ?: time()),
            ),
        ];
    }

    /** @param array<string, string> $meta */
    private function render(string $view, array $meta): string
    {
        $site = $this->site();
        $e = static fn (?string $value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');

        ob_start();
        require __DIR__ . '/../Views/' . $view . '.php';
        $content = (string) ob_get_clean();

        return $this->page($content, $meta);
    }

    /** @param array<string, string> $meta */
    private function page(string $content, array $meta): string
    {
        $site = $this->site();
        $title = $meta['title'];
        $description = $meta['description'];
        $activePage = $meta['activePage'];

        ob_start();
        require __DIR__ . '/../Views/layout.php';
        return (string) ob_get_clean();
    }
}
