<?php

declare(strict_types=1);

namespace ErrandRun\Controllers;

use ErrandRun\Core\ApiException;
use ErrandRun\Core\Clock;
use ErrandRun\Core\Database;
use ErrandRun\Core\Request;
use ErrandRun\Core\Response;
use ErrandRun\Core\Validator;
use ErrandRun\Http\AuthContext;
use ErrandRun\Security\AuditLog;
use ErrandRun\Security\PasswordService;
use ErrandRun\Security\RateLimiter;
use ErrandRun\Security\TokenService;
use ErrandRun\Sync\EntityRepository;
use ErrandRun\Sync\SettingsRepository;

final class ProfileController
{
    public function show(Request $request, AuthContext $auth): void
    {
        $user = Database::first(
            'SELECT id, email, display_name, created_at, password_changed_at, email_verified_at
               FROM users WHERE id = :id LIMIT 1',
            ['id' => $auth->userId],
        );
        if ($user === null) {
            throw ApiException::unauthorized('This account no longer exists.', 'account_deleted');
        }

        Response::json([
            'user' => [
                'id'                  => (string) $user['id'],
                'email'               => (string) $user['email'],
                'display_name'        => (string) $user['display_name'],
                'created_at'          => Clock::isoFromSql((string) $user['created_at']),
                'password_changed_at' => Clock::isoFromSql((string) $user['password_changed_at']),
                'email_verified'      => $user['email_verified_at'] !== null,
                'settings'            => SettingsRepository::fetch($auth->userId),
            ],
            'counts' => EntityRepository::counts($auth->userId),
        ]);
    }

    public function update(Request $request, AuthContext $auth): void
    {
        $validator = new Validator($request->json());
        $validator->rejectUnknown(['display_name', 'email', 'current_password']);
        $displayName = $validator->string('display_name', false, 0, 80);
        $email = $validator->email('email', false);
        $currentPassword = $validator->raw('current_password');
        $validator->stop();

        if ($displayName === null && $email === null) {
            throw ApiException::badRequest('Nothing to update.');
        }

        // Changing the address that owns the account always costs a password.
        if ($email !== null && $email !== $auth->email()) {
            if (!is_string($currentPassword) || $currentPassword === '') {
                throw ApiException::validation(['current_password' => 'Your current password is required to change the email.']);
            }
            $row = Database::first('SELECT password_hash FROM users WHERE id = :id LIMIT 1', ['id' => $auth->userId]);
            if ($row === null || !PasswordService::verify($currentPassword, (string) $row['password_hash'])) {
                AuditLog::record(AuditLog::PROFILE_UPDATE, 'bad_password', $request, $auth->userId);
                throw ApiException::unauthorized('That password is not right.', 'invalid_credentials');
            }

            try {
                Database::run(
                    'UPDATE users SET email = :email, email_verified_at = NULL, updated_at = :now WHERE id = :id',
                    ['email' => $email, 'now' => Clock::sql(), 'id' => $auth->userId],
                );
            } catch (\PDOException $exception) {
                if ($exception->getCode() === '23000') {
                    throw ApiException::conflict('That email address is already registered.');
                }
                throw $exception;
            }
        }

        if ($displayName !== null) {
            Database::run(
                'UPDATE users SET display_name = :name, updated_at = :now WHERE id = :id',
                ['name' => $displayName, 'now' => Clock::sql(), 'id' => $auth->userId],
            );
        }

        AuditLog::record(AuditLog::PROFILE_UPDATE, 'success', $request, $auth->userId);
        $this->show($request, $auth);
    }

    public function changePassword(Request $request, AuthContext $auth): void
    {
        RateLimiter::hit(RateLimiter::bucket('password:user', $auth->userId), 10, 3600);

        $validator = new Validator($request->json());
        $validator->rejectUnknown(['current_password', 'new_password', 'keep_other_sessions']);
        $current = $validator->raw('current_password');
        $new = $validator->password('new_password');
        $keepOthers = $validator->bool('keep_other_sessions', false) ?? false;
        if (!is_string($current) || $current === '') {
            $validator->addError('current_password', 'This field is required.');
        }
        $validator->stop();

        /** @var string $new */
        $row = Database::first('SELECT password_hash, email, display_name FROM users WHERE id = :id LIMIT 1', ['id' => $auth->userId]);
        if ($row === null || !PasswordService::verify((string) $current, (string) $row['password_hash'])) {
            AuditLog::record(AuditLog::PASSWORD_CHANGE, 'bad_password', $request, $auth->userId);
            throw ApiException::unauthorized('That password is not right.', 'invalid_credentials');
        }

        if (PasswordService::verify($new, (string) $row['password_hash'])) {
            throw ApiException::validation(['new_password' => 'The new password must be different.']);
        }

        $policyError = PasswordService::policyError($new, (string) $row['email'], (string) $row['display_name']);
        if ($policyError !== null) {
            throw ApiException::validation(['new_password' => $policyError]);
        }

        $now = Clock::sql();
        Database::run(
            'UPDATE users SET password_hash = :hash, password_changed_at = :changed, updated_at = :updated WHERE id = :id',
            ['hash' => PasswordService::hash($new), 'changed' => $now, 'updated' => $now, 'id' => $auth->userId],
        );

        // A password change signs out every other device unless asked otherwise.
        $ended = $keepOthers ? 0 : TokenService::revokeAllForUser($auth->userId, 'password_change', $auth->sessionId);

        AuditLog::record(AuditLog::PASSWORD_CHANGE, 'success', $request, $auth->userId, null, ['sessions_ended' => $ended]);
        Response::json(['password_changed' => true, 'sessions_ended' => $ended]);
    }

    public function sessions(Request $request, AuthContext $auth): void
    {
        Response::json(['sessions' => TokenService::listSessions($auth->userId, $auth->sessionId)]);
    }

    /** @param array<string, string> $params */
    public function revokeSession(Request $request, AuthContext $auth, array $params): void
    {
        $sessionId = strtoupper($params['id'] ?? '');
        if (preg_match('/^[0-9A-F-]{36}$/', $sessionId) !== 1) {
            throw ApiException::notFound('No such session.');
        }

        $row = Database::first(
            'SELECT id FROM sessions WHERE id = :id AND user_id = :user_id AND revoked_at IS NULL LIMIT 1',
            ['id' => $sessionId, 'user_id' => $auth->userId],
        );
        if ($row === null) {
            throw ApiException::notFound('No such session.');
        }

        TokenService::revokeSession($sessionId, 'revoked_by_user');
        AuditLog::record(AuditLog::SESSION_REVOKE, 'success', $request, $auth->userId, null, ['session' => $sessionId]);
        Response::json(['revoked' => true, 'was_current' => $sessionId === $auth->sessionId]);
    }

    /**
     * Deletes the account and everything attached to it. The foreign keys cascade,
     * so no orphan row can survive.
     */
    public function destroy(Request $request, AuthContext $auth): void
    {
        RateLimiter::hit(RateLimiter::bucket('delete:user', $auth->userId), 5, 3600);

        $validator = new Validator($request->json());
        $validator->rejectUnknown(['password', 'confirm']);
        $password = $validator->raw('password');
        $confirm = $validator->string('confirm', true, 1, 20);
        if (!is_string($password) || $password === '') {
            $validator->addError('password', 'This field is required.');
        }
        $validator->stop();

        if ($confirm !== 'DELETE') {
            throw ApiException::validation(['confirm' => 'Send "DELETE" to confirm.']);
        }

        $row = Database::first('SELECT password_hash, email FROM users WHERE id = :id LIMIT 1', ['id' => $auth->userId]);
        if ($row === null || !PasswordService::verify((string) $password, (string) $row['password_hash'])) {
            AuditLog::record(AuditLog::ACCOUNT_DELETE, 'bad_password', $request, $auth->userId);
            throw ApiException::unauthorized('That password is not right.', 'invalid_credentials');
        }

        $email = (string) $row['email'];
        Database::transaction(static function () use ($auth): void {
            TokenService::revokeAllForUser($auth->userId, 'account_deleted');
            Database::run('DELETE FROM users WHERE id = :id', ['id' => $auth->userId]);
        });

        // Written after the cascade: the user row is gone, only the email hash remains.
        AuditLog::record(AuditLog::ACCOUNT_DELETE, 'success', $request, null, $email);

        Response::json(['deleted' => true]);
    }
}
