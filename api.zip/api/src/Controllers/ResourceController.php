<?php

declare(strict_types=1);

namespace ErrandRun\Controllers;

use ErrandRun\Core\ApiException;
use ErrandRun\Core\Clock;
use ErrandRun\Core\Request;
use ErrandRun\Core\Response;
use ErrandRun\Http\AuthContext;
use ErrandRun\Sync\Collections;
use ErrandRun\Sync\EntityRepository;

/**
 * REST resources for every synced collection:
 *   GET    /v1/{collection}
 *   POST   /v1/{collection}
 *   GET    /v1/{collection}/{id}
 *   PUT    /v1/{collection}/{id}
 *   DELETE /v1/{collection}/{id}
 */
final class ResourceController
{
    /** @param array<string, string> $params */
    public function index(Request $request, AuthContext $auth, array $params): void
    {
        $collection = Collections::fromPath($params['collection'] ?? '');

        $since = null;
        if (isset($request->query['since']) && $request->query['since'] !== '') {
            $since = Clock::parseIso($request->query['since']);
            if ($since === null) {
                throw ApiException::badRequest('The "since" parameter must be an ISO-8601 timestamp.');
            }
        }

        $includeDeleted = ($request->query['include_deleted'] ?? '0') === '1';
        $limit = isset($request->query['limit']) ? (int) $request->query['limit'] : 1000;

        $items = EntityRepository::pull($auth->userId, $collection, $since, $includeDeleted, $limit);

        Response::json([
            'collection'  => Collections::toPath($collection),
            'items'       => $items,
            'count'       => count($items),
            'server_time' => Clock::iso(),
        ]);
    }

    /** @param array<string, string> $params */
    public function store(Request $request, AuthContext $auth, array $params): void
    {
        $collection = Collections::fromPath($params['collection'] ?? '');
        $body = $request->json();

        // A resource POST carries the model itself; the envelope is optional.
        $item = $this->envelope($body);
        $normalised = EntityRepository::normaliseItem($collection, $item);
        $result = EntityRepository::upsert($auth->userId, $collection, $normalised);

        Response::json(['item' => $result['item'], 'status' => $result['status']], $result['status'] === 'created' ? 201 : 200);
    }

    /** @param array<string, string> $params */
    public function show(Request $request, AuthContext $auth, array $params): void
    {
        $collection = Collections::fromPath($params['collection'] ?? '');
        $id = $this->identifier($collection, $params['id'] ?? '');

        $item = EntityRepository::fetch($auth->userId, $collection, $id);
        if ($item === null || ($item['deleted'] ?? false) === true) {
            throw ApiException::notFound('No such item.');
        }

        Response::json(['item' => $item]);
    }

    /** @param array<string, string> $params */
    public function update(Request $request, AuthContext $auth, array $params): void
    {
        $collection = Collections::fromPath($params['collection'] ?? '');
        $id = $this->identifier($collection, $params['id'] ?? '');

        $item = $this->envelope($request->json());
        $item['id'] = $id;

        $normalised = EntityRepository::normaliseItem($collection, $item);
        $result = EntityRepository::upsert($auth->userId, $collection, $normalised);

        if ($result['status'] === 'kept_server') {
            throw ApiException::conflict(
                'A newer version of this item is already stored.',
                ['item' => $result['item']],
            );
        }

        Response::json(['item' => $result['item'], 'status' => $result['status']]);
    }

    /** @param array<string, string> $params */
    public function destroy(Request $request, AuthContext $auth, array $params): void
    {
        $collection = Collections::fromPath($params['collection'] ?? '');
        $id = $this->identifier($collection, $params['id'] ?? '');

        $deleted = EntityRepository::softDelete($auth->userId, $collection, $id, Clock::now());
        if (!$deleted) {
            throw ApiException::notFound('No such item.');
        }

        Response::json(['deleted' => true, 'id' => $id]);
    }

    /**
     * Accepts either {"payload": {...}, "updated_at": "..."} or the bare model.
     *
     * @param array<string, mixed> $body
     * @return array<string, mixed>
     */
    private function envelope(array $body): array
    {
        if (isset($body['payload']) && is_array($body['payload'])) {
            return $body;
        }

        $updatedAt = $body['updatedAt'] ?? $body['updated_at'] ?? Clock::iso();
        return [
            'id'         => $body['id'] ?? ($body['key'] ?? null),
            'updated_at' => is_string($updatedAt) ? $updatedAt : Clock::iso(),
            'deleted'    => false,
            'payload'    => $body,
        ];
    }

    private function identifier(string $collection, string $raw): string
    {
        $config = Collections::config($collection);
        $value = trim($raw);

        if ($config['id_type'] === 'uuid') {
            if (preg_match('/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/', $value) !== 1) {
                throw ApiException::notFound('No such item.');
            }
            return strtoupper($value);
        }

        if ($value === '' || mb_strlen($value) > 190 || preg_match('/^[\x20-\x7E]+$/', $value) !== 1) {
            throw ApiException::notFound('No such item.');
        }
        return $value;
    }
}
