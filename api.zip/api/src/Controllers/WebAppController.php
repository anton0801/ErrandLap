<?php

declare(strict_types=1);

namespace ErrandRun\Controllers;

use ErrandRun\Core\ApiException;
use ErrandRun\Core\Clock;
use ErrandRun\Core\Request;
use ErrandRun\Core\Response;
use ErrandRun\Core\Validator;
use ErrandRun\Security\RateLimiter;
use ErrandRun\Web\PlayerSession;
use ErrandRun\Web\Season;

/**
 * The little web app that the native app opens in a WebView.
 *
 *   GET  /app                → the page itself
 *   GET  /app/spark.css      → styles
 *   GET  /app/spark.js       → the game
 *   GET  /app/api/state      → who this player is and what season it is
 *   POST /app/api/round      → a finished round
 *
 * Identity is one cookie and nothing else: no account, no token, no personal
 * data. Assets are served through PHP rather than as plain files so the whole
 * thing keeps working under the same single rewrite rule.
 */
final class WebAppController
{
    private const ROUND_MS = 45_000;

    public function page(Request $request): void
    {
        $player = PlayerSession::open($request, countVisit: true);
        PlayerSession::sweep();

        $season = Season::current();
        $stats = PlayerSession::present($player);

        ob_start();
        require __DIR__ . '/../Views/webapp.php';
        $html = (string) ob_get_clean();

        // This page runs its own script, so it gets its own policy: still no
        // outside hosts, no inline code, no framing.
        Response::html($html, 200, 0, csp: "default-src 'none'; "
            . "script-src 'self'; style-src 'self'; img-src 'self' data:; "
            . "connect-src 'self'; base-uri 'none'; form-action 'none'; frame-ancestors 'none'");
    }

    public function styles(Request $request): void
    {
        $this->asset(__DIR__ . '/../Web/assets/spark.css', 'text/css; charset=utf-8');
    }

    public function script(Request $request): void
    {
        $this->asset(__DIR__ . '/../Web/assets/spark.js', 'application/javascript; charset=utf-8');
    }

    public function state(Request $request): void
    {
        $player = PlayerSession::open($request);

        Response::json([
            'player'      => PlayerSession::present($player),
            'season'      => Season::current(),
            'server_time' => Clock::iso(),
        ]);
    }

    public function round(Request $request): void
    {
        $player = PlayerSession::open($request);
        $playerId = (string) ($player['id'] ?? '');
        if ($playerId === '') {
            throw ApiException::badRequest('No player session.');
        }

        RateLimiter::hit(RateLimiter::bucket('play:round', $playerId), 40, 900);

        $validator = new Validator($request->json());
        $validator->rejectUnknown(['score', 'combo', 'sparks', 'duration_ms']);
        $score = $validator->int('score', true, 0, 100_000);
        $combo = $validator->int('combo', true, 0, 500);
        $sparks = $validator->int('sparks', true, 0, 500);
        $duration = $validator->int('duration_ms', true, 0, 600_000);
        $validator->stop();

        /** @var int $score */
        /** @var int $combo */
        /** @var int $sparks */
        /** @var int $duration */

        // A round is a fixed length. Anything much shorter or longer did not
        // happen the way it was reported, so it is not recorded.
        if ($duration < self::ROUND_MS - 5_000 || $duration > self::ROUND_MS + 20_000) {
            throw ApiException::badRequest('That round length does not look like a round.');
        }

        // The most a spark can be worth is its gold value at the highest combo.
        // Anything above that is impossible however well you play.
        $ceiling = $sparks * 25 * 5;
        if ($score > $ceiling) {
            throw ApiException::badRequest('That score does not match the sparks caught.');
        }

        $updated = PlayerSession::recordRound($playerId, $score, $combo, $sparks);

        Response::json([
            'player'   => PlayerSession::present($updated),
            'improved' => $score > 0 && $score >= (int) ($updated['best_score'] ?? 0),
        ]);
    }

    private function asset(string $path, string $contentType): void
    {
        if (!is_file($path)) {
            throw ApiException::notFound('No such file.');
        }

        $body = (string) file_get_contents($path);
        $etag = '"' . substr(hash('sha256', $body), 0, 24) . '"';

        if (($_SERVER['HTTP_IF_NONE_MATCH'] ?? '') === $etag) {
            http_response_code(304);
            header('ETag: ' . $etag);
            exit;
        }

        http_response_code(200);
        header('Content-Type: ' . $contentType);
        header('ETag: ' . $etag);
        header('Cache-Control: public, max-age=600');
        header_remove('Pragma');
        echo $body;
    }
}
