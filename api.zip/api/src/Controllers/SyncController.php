<?php

declare(strict_types=1);

namespace ErrandRun\Controllers;

use ErrandRun\Core\ApiException;
use ErrandRun\Core\Clock;
use ErrandRun\Core\Config;
use ErrandRun\Core\Database;
use ErrandRun\Core\Request;
use ErrandRun\Core\Response;
use ErrandRun\Core\Validator;
use ErrandRun\Http\AuthContext;
use ErrandRun\Security\RateLimiter;
use ErrandRun\Sync\Collections;
use ErrandRun\Sync\EntityRepository;
use ErrandRun\Sync\SettingsRepository;

/**
 * Delta sync in one round trip.
 *
 * GET  /v1/sync?since=…  → everything that changed on the server since that moment
 * POST /v1/sync          → push local changes, and get the same delta back
 *
 * Conflicts are settled by the edit time the client recorded: the newer edit wins,
 * and the loser is returned so the client can adopt it without another request.
 */
final class SyncController
{
    public function pull(Request $request, AuthContext $auth): void
    {
        $since = null;
        if (isset($request->query['since']) && $request->query['since'] !== '') {
            $since = Clock::parseIso($request->query['since']);
            if ($since === null) {
                throw ApiException::badRequest('The "since" parameter must be an ISO-8601 timestamp.');
            }
        }

        Response::json($this->delta($auth->userId, $since));
    }

    public function push(Request $request, AuthContext $auth): void
    {
        RateLimiter::hit(RateLimiter::bucket('sync:user', $auth->userId), Config::int('RATE_SYNC_PER_USER', 240), 300);

        $body = $request->json();
        $validator = new Validator($body);
        $validator->rejectUnknown(array_merge(
            ['since', 'settings'],
            array_map(static fn (string $name): string => Collections::toPath($name), Collections::all()),
        ));
        $sinceRaw = $validator->string('since', false, 0, 40);
        $validator->stop();

        $since = null;
        if ($sinceRaw !== null && $sinceRaw !== '') {
            $since = Clock::parseIso($sinceRaw);
            if ($since === null) {
                throw ApiException::validation(['since' => 'This must be an ISO-8601 timestamp.']);
            }
        }

        $maxItems = Config::int('SYNC_MAX_PUSH_ITEMS', 500);
        $applied = [];
        $conflicts = [];
        $total = 0;

        // One transaction: a half-applied batch would leave the client guessing.
        Database::transaction(static function () use (
            $body, $auth, $maxItems, &$applied, &$conflicts, &$total
        ): void {
            if (isset($body['settings'])) {
                if (!is_array($body['settings']) || array_is_list($body['settings'])) {
                    throw ApiException::validation(['settings' => 'This field must be an object.']);
                }
                $payload = $body['settings']['payload'] ?? null;
                $updatedAtRaw = $body['settings']['updated_at'] ?? null;
                if (!is_array($payload) || array_is_list($payload)) {
                    throw ApiException::validation(['settings.payload' => 'This field must be an object.']);
                }
                $updatedAt = is_string($updatedAtRaw) ? Clock::parseIso($updatedAtRaw) : null;
                if ($updatedAt === null) {
                    throw ApiException::validation(['settings.updated_at' => 'This must be an ISO-8601 timestamp.']);
                }
                /** @var array<string, mixed> $payload */
                $result = SettingsRepository::save($auth->userId, $payload, $updatedAt);
                if ($result['status'] === 'kept_server') {
                    $conflicts['settings'] = $result['settings'];
                } else {
                    $applied['settings'] = 1;
                }
            }

            foreach (Collections::all() as $collection) {
                $key = Collections::toPath($collection);
                $items = $body[$key] ?? null;
                if ($items === null) {
                    continue;
                }
                if (!is_array($items) || !array_is_list($items)) {
                    throw ApiException::validation([$key => 'This field must be an array.']);
                }

                $total += count($items);
                if ($total > $maxItems) {
                    throw ApiException::badRequest(
                        sprintf('Too many items in one push (limit %d). Send them in batches.', $maxItems),
                    );
                }

                $appliedCount = 0;
                foreach ($items as $index => $item) {
                    if (!is_array($item) || array_is_list($item)) {
                        throw ApiException::validation([$key . '.' . $index => 'Each item must be an object.']);
                    }
                    /** @var array<string, mixed> $item */
                    $normalised = EntityRepository::normaliseItem($collection, $item, $key . '.' . $index);
                    $result = EntityRepository::upsert($auth->userId, $collection, $normalised);
                    if ($result['status'] === 'kept_server') {
                        $conflicts[$key][] = $result['item'];
                    } else {
                        $appliedCount++;
                    }
                }
                if ($appliedCount > 0) {
                    $applied[$key] = $appliedCount;
                }
            }
        });

        EntityRepository::purgeTombstones($auth->userId);

        $delta = $this->delta($auth->userId, $since);
        $delta['applied'] = $applied === [] ? new \stdClass() : $applied;
        $delta['conflicts'] = $conflicts === [] ? new \stdClass() : $conflicts;

        Response::json($delta);
    }

    /**
     * @return array<string, mixed>
     */
    private function delta(string $userId, ?\DateTimeImmutable $since): array
    {
        $payload = [
            'server_time' => Clock::iso(),
            'since'       => $since === null ? null : Clock::iso($since),
        ];

        $settings = SettingsRepository::fetch($userId);
        if ($settings !== null) {
            $serverUpdated = $settings['server_updated_at'] ?? null;
            $include = $since === null;
            if (!$include && is_string($serverUpdated)) {
                $moment = Clock::parseIso($serverUpdated);
                $include = $moment !== null && $moment > $since;
            }
            $payload['settings'] = $include ? $settings : null;
        } else {
            $payload['settings'] = null;
        }

        foreach (Collections::all() as $collection) {
            $payload[Collections::toPath($collection)] = EntityRepository::pull($userId, $collection, $since);
        }

        return $payload;
    }
}
