<?php

declare(strict_types=1);

namespace ErrandRun\Core;

/**
 * Every error the client is allowed to see. Anything else becomes a generic 500,
 * so internal details never leak through the API.
 */
class ApiException extends \RuntimeException
{
    /** @param array<string, mixed> $details */
    public function __construct(
        private readonly int $status,
        private readonly string $errorCode,
        string $message,
        private readonly array $details = [],
        private readonly array $headers = [],
        ?\Throwable $previous = null,
    ) {
        parent::__construct($message, 0, $previous);
    }

    public function status(): int
    {
        return $this->status;
    }

    public function code(): string
    {
        return $this->errorCode;
    }

    /** @return array<string, mixed> */
    public function details(): array
    {
        return $this->details;
    }

    /** @return array<string, string> */
    public function headers(): array
    {
        return $this->headers;
    }

    /** @param array<string, mixed> $details */
    public static function badRequest(string $message, array $details = []): self
    {
        return new self(400, 'bad_request', $message, $details);
    }

    /** @param array<string, mixed> $fields */
    public static function validation(array $fields): self
    {
        return new self(422, 'validation_failed', 'Some fields are not valid.', ['fields' => $fields]);
    }

    public static function unauthorized(string $message = 'Authentication is required.', string $code = 'unauthorized'): self
    {
        return new self(401, $code, $message, [], ['WWW-Authenticate' => 'Bearer realm="errandrun"']);
    }

    public static function forbidden(string $message = 'Not allowed.'): self
    {
        return new self(403, 'forbidden', $message);
    }

    public static function notFound(string $message = 'Not found.'): self
    {
        return new self(404, 'not_found', $message);
    }

    public static function conflict(string $message, array $details = []): self
    {
        return new self(409, 'conflict', $message, $details);
    }

    public static function locked(string $message, int $retryAfter): self
    {
        return new self(423, 'account_locked', $message, ['retry_after' => $retryAfter], ['Retry-After' => (string) $retryAfter]);
    }

    public static function tooManyRequests(int $retryAfter): self
    {
        return new self(
            429,
            'rate_limited',
            'Too many requests. Slow down and try again shortly.',
            ['retry_after' => $retryAfter],
            ['Retry-After' => (string) $retryAfter],
        );
    }

    public static function payloadTooLarge(): self
    {
        return new self(413, 'payload_too_large', 'The request body is too large.');
    }
}
