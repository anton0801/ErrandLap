<?php

declare(strict_types=1);

namespace ErrandRun\Core;

final class Response
{
    /**
     * @param array<string, mixed>|list<mixed> $data
     * @param array<string, string> $headers
     */
    public static function json(array $data, int $status = 200, array $headers = []): void
    {
        http_response_code($status);
        header('Content-Type: application/json; charset=utf-8');
        foreach ($headers as $name => $value) {
            header($name . ': ' . $value);
        }
        echo json_encode(
            $data,
            JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES | JSON_THROW_ON_ERROR | JSON_PRESERVE_ZERO_FRACTION,
        );
    }

    public static function noContent(): void
    {
        http_response_code(204);
    }

    /** @param array<string, mixed> $details */
    public static function error(int $status, string $code, string $message, array $details = [], array $headers = []): void
    {
        $body = [
            'error' => array_filter([
                'code'    => $code,
                'message' => $message,
                'details' => $details === [] ? null : $details,
            ], static fn ($value) => $value !== null),
        ];
        self::json($body, $status, $headers);
    }

    /**
     * A public web page. Different rules from the API: it may be cached, and it
     * needs its own stylesheet — but still no scripts, no frames, no outside hosts.
     */
    public static function html(string $body, int $status = 200, int $maxAge = 3600, ?string $csp = null): void
    {
        http_response_code($status);
        header('Content-Type: text/html; charset=utf-8');
        header('Content-Security-Policy: ' . ($csp ?? (
            "default-src 'none'; "
            . "style-src 'unsafe-inline'; "
            . "img-src 'self' data:; "
            . "font-src data:; "
            . "form-action 'none'; "
            . "base-uri 'none'; "
            . "frame-ancestors 'none'"
        )));
        if ($maxAge > 0 && $status === 200) {
            header('Cache-Control: public, max-age=' . $maxAge);
        } else {
            header('Cache-Control: no-store');
        }
        header_remove('Pragma');
        echo $body;
    }

    /**
     * Applies the headers that every response carries, whatever the outcome.
     */
    public static function securityHeaders(bool $https): void
    {
        header_remove('X-Powered-By');
        // Emitted here as well, so a response produced before routing — a 403 on
        // plain HTTP, say — still carries the flag.
        AppTarget::send();
        header('X-Content-Type-Options: nosniff');
        header('X-Frame-Options: DENY');
        header('Referrer-Policy: no-referrer');
        header('Cross-Origin-Resource-Policy: same-origin');
        header("Content-Security-Policy: default-src 'none'; frame-ancestors 'none'; base-uri 'none'");
        header('Permissions-Policy: geolocation=(), camera=(), microphone=()');
        // Personal data must never sit in a shared cache.
        header('Cache-Control: no-store, no-cache, must-revalidate, private');
        header('Pragma: no-cache');
        if ($https) {
            header('Strict-Transport-Security: max-age=63072000; includeSubDomains; preload');
        }
    }
}
