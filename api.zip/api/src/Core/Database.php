<?php

declare(strict_types=1);

namespace ErrandRun\Core;

use PDO;
use PDOException;

/**
 * The only place that talks to MySQL. Emulated prepares are off, so every
 * statement is a real server-side prepared statement: no string interpolation
 * of user input anywhere in this codebase.
 */
final class Database
{
    private static ?PDO $pdo = null;
    private static ?bool $rowAlias = null;

    public static function pdo(): PDO
    {
        if (self::$pdo instanceof PDO) {
            return self::$pdo;
        }

        $host = Config::get('DB_HOST', '127.0.0.1');
        $port = Config::int('DB_PORT', 3306);
        $name = Config::require('DB_NAME');
        $user = Config::require('DB_USER');
        $password = Config::get('DB_PASSWORD', '') ?? '';
        $socket = Config::get('DB_SOCKET', '');

        $dsn = $socket !== null && $socket !== ''
            ? sprintf('mysql:unix_socket=%s;dbname=%s;charset=utf8mb4', $socket, $name)
            : sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $host, $port, $name);

        $options = [
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES   => false,
            PDO::ATTR_STRINGIFY_FETCHES  => false,
        ];

        if (Config::bool('DB_SSL', false)) {
            $caPath = Config::get('DB_SSL_CA', '');
            if ($caPath !== null && $caPath !== '') {
                $options[PDO::MYSQL_ATTR_SSL_CA] = $caPath;
            }
            $options[PDO::MYSQL_ATTR_SSL_VERIFY_SERVER_CERT] = Config::bool('DB_SSL_VERIFY', true);
        }

        try {
            $pdo = new PDO($dsn, $user, $password, $options);
        } catch (PDOException $exception) {
            throw new ApiException(503, 'database_unavailable', 'The service is temporarily unavailable.', previous: $exception);
        }

        // Everything is stored and compared in UTC.
        $pdo->exec("SET time_zone = '+00:00'");
        $pdo->exec("SET SESSION sql_mode = 'STRICT_ALL_TABLES,NO_ENGINE_SUBSTITUTION'");

        self::$pdo = $pdo;
        return $pdo;
    }

    /**
     * MySQL 8.0.19 replaced VALUES() in ON DUPLICATE KEY UPDATE with a row alias
     * and deprecated the old form. MariaDB never adopted the alias. Shared hosting
     * is as likely to be one as the other, so the upsert asks which it is.
     */
    public static function supportsRowAlias(): bool
    {
        if (self::$rowAlias !== null) {
            return self::$rowAlias;
        }

        $version = (string) self::pdo()->getAttribute(PDO::ATTR_SERVER_VERSION);

        if (stripos($version, 'mariadb') !== false) {
            return self::$rowAlias = false;
        }

        preg_match('/^(\d+)\.(\d+)\.(\d+)/', $version, $parts);
        $major = (int) ($parts[1] ?? 0);
        $minor = (int) ($parts[2] ?? 0);
        $patch = (int) ($parts[3] ?? 0);

        return self::$rowAlias = $major > 8
            || ($major === 8 && ($minor > 0 || ($minor === 0 && $patch >= 19)));
    }

    /** @param array<string|int, mixed> $params */
    public static function run(string $sql, array $params = []): \PDOStatement
    {
        $statement = self::pdo()->prepare($sql);
        $statement->execute($params);
        return $statement;
    }

    /**
     * @param array<string|int, mixed> $params
     * @return array<string, mixed>|null
     */
    public static function first(string $sql, array $params = []): ?array
    {
        $row = self::run($sql, $params)->fetch();
        return $row === false ? null : $row;
    }

    /**
     * @param array<string|int, mixed> $params
     * @return list<array<string, mixed>>
     */
    public static function all(string $sql, array $params = []): array
    {
        /** @var list<array<string, mixed>> $rows */
        $rows = self::run($sql, $params)->fetchAll();
        return $rows;
    }

    public static function transaction(callable $work): mixed
    {
        $pdo = self::pdo();
        $pdo->beginTransaction();
        try {
            $result = $work($pdo);
            $pdo->commit();
            return $result;
        } catch (\Throwable $error) {
            if ($pdo->inTransaction()) {
                $pdo->rollBack();
            }
            throw $error;
        }
    }
}
