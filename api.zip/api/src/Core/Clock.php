<?php

declare(strict_types=1);

namespace ErrandRun\Core;

use DateTimeImmutable;
use DateTimeZone;

/**
 * One time zone in the whole system: UTC. The client converts for display.
 */
final class Clock
{
    public const SQL_FORMAT = 'Y-m-d H:i:s.v';

    public static function utc(): DateTimeZone
    {
        return new DateTimeZone('UTC');
    }

    public static function now(): DateTimeImmutable
    {
        return new DateTimeImmutable('now', self::utc());
    }

    public static function sql(?DateTimeImmutable $moment = null): string
    {
        return ($moment ?? self::now())->setTimezone(self::utc())->format(self::SQL_FORMAT);
    }

    public static function iso(?DateTimeImmutable $moment = null): string
    {
        return ($moment ?? self::now())->setTimezone(self::utc())->format('Y-m-d\TH:i:s.v\Z');
    }

    public static function fromSql(?string $value): ?DateTimeImmutable
    {
        if ($value === null || $value === '') {
            return null;
        }
        $moment = DateTimeImmutable::createFromFormat('Y-m-d H:i:s.u', $value, self::utc())
            ?: DateTimeImmutable::createFromFormat('Y-m-d H:i:s', $value, self::utc());
        return $moment === false ? null : $moment;
    }

    public static function isoFromSql(?string $value): ?string
    {
        $moment = self::fromSql($value);
        return $moment === null ? null : self::iso($moment);
    }

    /**
     * Accepts ISO-8601 with or without fractional seconds.
     */
    public static function parseIso(string $value): ?DateTimeImmutable
    {
        $value = trim($value);
        if ($value === '') {
            return null;
        }
        try {
            $moment = new DateTimeImmutable($value);
        } catch (\Exception) {
            return null;
        }
        return $moment->setTimezone(self::utc());
    }

    public static function plusSeconds(int $seconds, ?DateTimeImmutable $from = null): DateTimeImmutable
    {
        return ($from ?? self::now())->modify(sprintf('+%d seconds', $seconds));
    }
}
