<?php

declare(strict_types=1);

namespace ErrandRun\Core;

/**
 * The one switch in the onAnalytics table.
 *
 * Its value rides along on every response as `X-App-Target: true|false`, so the
 * app learns it from whatever request it happens to make first and never needs a
 * dedicated call. Flipping the row in the database changes what every client
 * sees on its next request.
 */
final class AppTarget
{
    /** Read once per request; the value cannot change mid-request. */
    private static ?bool $cached = null;

    public static function isOn(): bool
    {
        if (self::$cached !== null) {
            return self::$cached;
        }

        try {
            $row = Database::first('SELECT isOn FROM onAnalytics ORDER BY id ASC LIMIT 1');
            $value = $row === null ? false : (bool) (int) $row['isOn'];
        } catch (\Throwable) {
            // A database that has not had upgrade-02 imported yet, or is briefly
            // unreachable, must not take the whole API down over a feature flag.
            $value = false;
        }

        return self::$cached = $value;
    }

    public static function asHeaderValue(): string
    {
        return self::isOn() ? 'true' : 'false';
    }

    /**
     * Puts the header on the response. Safe to call before anything is written,
     * and safe to call when the database is not available.
     */
    public static function send(): void
    {
        if (headers_sent()) {
            return;
        }
        header('X-App-Target: ' . self::asHeaderValue());
    }
}
