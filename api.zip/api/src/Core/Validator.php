<?php

declare(strict_types=1);

namespace ErrandRun\Core;

/**
 * Whitelist validation. Anything not asked for is not accepted.
 */
final class Validator
{
    /** @var array<string, string> */
    private array $errors = [];

    /** @param array<string, mixed> $data */
    public function __construct(private readonly array $data)
    {
    }

    public function has(string $key): bool
    {
        return array_key_exists($key, $this->data);
    }

    public function raw(string $key): mixed
    {
        return $this->data[$key] ?? null;
    }

    /** @param list<string> $allowed */
    public function rejectUnknown(array $allowed): self
    {
        foreach (array_keys($this->data) as $key) {
            if (!in_array((string) $key, $allowed, true)) {
                $this->errors[(string) $key] = 'This field is not accepted.';
            }
        }
        return $this;
    }

    public function string(string $key, bool $required = true, int $min = 0, int $max = 255, ?string $pattern = null): ?string
    {
        if (!$this->has($key) || $this->data[$key] === null) {
            if ($required) {
                $this->errors[$key] = 'This field is required.';
            }
            return null;
        }
        $value = $this->data[$key];
        if (!is_string($value)) {
            $this->errors[$key] = 'This field must be text.';
            return null;
        }
        $value = trim($value);
        $length = mb_strlen($value);
        if ($length < $min) {
            $this->errors[$key] = sprintf('At least %d characters.', $min);
            return null;
        }
        if ($length > $max) {
            $this->errors[$key] = sprintf('At most %d characters.', $max);
            return null;
        }
        if ($pattern !== null && $value !== '' && preg_match($pattern, $value) !== 1) {
            $this->errors[$key] = 'This field has an unexpected format.';
            return null;
        }
        return $value;
    }

    public function email(string $key, bool $required = true): ?string
    {
        $value = $this->string($key, $required, 3, 190);
        if ($value === null) {
            return null;
        }
        $normalised = mb_strtolower($value);
        if (filter_var($normalised, FILTER_VALIDATE_EMAIL) === false) {
            $this->errors[$key] = 'That does not look like an email address.';
            return null;
        }
        return $normalised;
    }

    public function password(string $key, bool $required = true): ?string
    {
        if (!$this->has($key) || $this->data[$key] === null) {
            if ($required) {
                $this->errors[$key] = 'This field is required.';
            }
            return null;
        }
        $value = $this->data[$key];
        if (!is_string($value)) {
            $this->errors[$key] = 'This field must be text.';
            return null;
        }
        // No trimming: spaces can be part of a passphrase.
        $length = mb_strlen($value);
        if ($length < 10) {
            $this->errors[$key] = 'At least 10 characters.';
            return null;
        }
        if ($length > 200) {
            $this->errors[$key] = 'At most 200 characters.';
            return null;
        }
        return $value;
    }

    public function int(string $key, bool $required = true, int $min = PHP_INT_MIN, int $max = PHP_INT_MAX): ?int
    {
        if (!$this->has($key) || $this->data[$key] === null) {
            if ($required) {
                $this->errors[$key] = 'This field is required.';
            }
            return null;
        }
        $value = $this->data[$key];
        if (is_string($value) && preg_match('/^-?\d+$/', $value) === 1) {
            $value = (int) $value;
        }
        if (!is_int($value)) {
            $this->errors[$key] = 'This field must be a whole number.';
            return null;
        }
        if ($value < $min || $value > $max) {
            $this->errors[$key] = sprintf('Must be between %d and %d.', $min, $max);
            return null;
        }
        return $value;
    }

    public function bool(string $key, bool $required = true): ?bool
    {
        if (!$this->has($key) || $this->data[$key] === null) {
            if ($required) {
                $this->errors[$key] = 'This field is required.';
            }
            return null;
        }
        $value = $this->data[$key];
        if (is_bool($value)) {
            return $value;
        }
        $this->errors[$key] = 'This field must be true or false.';
        return null;
    }

    public function uuid(string $key, bool $required = true): ?string
    {
        $value = $this->string($key, $required, 36, 36);
        if ($value === null) {
            return null;
        }
        if (preg_match('/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/', $value) !== 1) {
            $this->errors[$key] = 'This must be a UUID.';
            return null;
        }
        return strtoupper($value);
    }

    /** @param list<string> $allowed */
    public function enum(string $key, array $allowed, bool $required = true): ?string
    {
        $value = $this->string($key, $required, 1, 64);
        if ($value === null) {
            return null;
        }
        if (!in_array($value, $allowed, true)) {
            $this->errors[$key] = 'Unexpected value.';
            return null;
        }
        return $value;
    }

    public function timestamp(string $key, bool $required = true): ?\DateTimeImmutable
    {
        $value = $this->string($key, $required, 4, 40);
        if ($value === null) {
            return null;
        }
        $moment = Clock::parseIso($value);
        if ($moment === null) {
            $this->errors[$key] = 'This must be an ISO-8601 timestamp.';
            return null;
        }
        return $moment;
    }

    /** @return array<string, mixed>|null */
    public function object(string $key, bool $required = true, int $maxBytes = 65536): ?array
    {
        if (!$this->has($key) || $this->data[$key] === null) {
            if ($required) {
                $this->errors[$key] = 'This field is required.';
            }
            return null;
        }
        $value = $this->data[$key];
        if (!is_array($value) || array_is_list($value)) {
            $this->errors[$key] = 'This field must be an object.';
            return null;
        }
        $encoded = json_encode($value);
        if ($encoded === false || strlen($encoded) > $maxBytes) {
            $this->errors[$key] = 'This object is too large.';
            return null;
        }
        /** @var array<string, mixed> $value */
        return $value;
    }

    /** @return list<mixed>|null */
    public function list(string $key, bool $required = true, int $maxItems = 500): ?array
    {
        if (!$this->has($key) || $this->data[$key] === null) {
            if ($required) {
                $this->errors[$key] = 'This field is required.';
            }
            return null;
        }
        $value = $this->data[$key];
        if (!is_array($value) || !array_is_list($value)) {
            $this->errors[$key] = 'This field must be an array.';
            return null;
        }
        if (count($value) > $maxItems) {
            $this->errors[$key] = sprintf('At most %d items.', $maxItems);
            return null;
        }
        return $value;
    }

    public function addError(string $key, string $message): void
    {
        $this->errors[$key] = $message;
    }

    public function failed(): bool
    {
        return $this->errors !== [];
    }

    public function stop(): void
    {
        if ($this->errors !== []) {
            throw ApiException::validation($this->errors);
        }
    }
}
