<?php

declare(strict_types=1);

namespace ErrandRun\Core;

final class Router
{
    /** @var list<array{method: string, pattern: string, regex: string, params: list<string>, handler: callable, auth: bool}> */
    private array $routes = [];

    public function get(string $pattern, callable $handler, bool $auth = true): void
    {
        $this->add('GET', $pattern, $handler, $auth);
    }

    public function post(string $pattern, callable $handler, bool $auth = true): void
    {
        $this->add('POST', $pattern, $handler, $auth);
    }

    public function patch(string $pattern, callable $handler, bool $auth = true): void
    {
        $this->add('PATCH', $pattern, $handler, $auth);
    }

    public function put(string $pattern, callable $handler, bool $auth = true): void
    {
        $this->add('PUT', $pattern, $handler, $auth);
    }

    public function delete(string $pattern, callable $handler, bool $auth = true): void
    {
        $this->add('DELETE', $pattern, $handler, $auth);
    }

    private function add(string $method, string $pattern, callable $handler, bool $auth): void
    {
        $params = [];
        $regex = preg_replace_callback(
            '/\{([a-zA-Z_][a-zA-Z0-9_]*)\}/',
            static function (array $matches) use (&$params): string {
                $params[] = $matches[1];
                return '([^/]+)';
            },
            $pattern,
        );

        $this->routes[] = [
            'method'  => $method,
            'pattern' => $pattern,
            'regex'   => '#^' . $regex . '$#',
            'params'  => $params,
            'handler' => $handler,
            'auth'    => $auth,
        ];
    }

    /**
     * @return array{handler: callable, params: array<string, string>, auth: bool}
     */
    public function match(Request $request): array
    {
        $allowed = [];

        // A HEAD request is a GET whose body is dropped by the server. Uptime
        // monitors use it, and answering 405 would read as an outage.
        $method = $request->method === 'HEAD' ? 'GET' : $request->method;

        foreach ($this->routes as $route) {
            if (preg_match($route['regex'], $request->path, $matches) !== 1) {
                continue;
            }
            if ($route['method'] !== $method) {
                $allowed[] = $route['method'];
                continue;
            }

            array_shift($matches);
            $params = [];
            foreach ($route['params'] as $index => $name) {
                $params[$name] = $matches[$index] ?? '';
            }

            return ['handler' => $route['handler'], 'params' => $params, 'auth' => $route['auth']];
        }

        if ($allowed !== []) {
            throw new ApiException(
                405,
                'method_not_allowed',
                'That method is not supported on this endpoint.',
                [],
                ['Allow' => implode(', ', array_unique($allowed))],
            );
        }

        throw ApiException::notFound('No such endpoint.');
    }
}
