<?php

declare(strict_types=1);

namespace ErrandRun\Core;

final class Request
{
    private ?array $json = null;

    private function __construct(
        public readonly string $method,
        public readonly string $path,
        /** @var array<string, string> */
        public readonly array $query,
        /** @var array<string, string> */
        public readonly array $headers,
        public readonly string $body,
        public readonly string $ip,
        public readonly string $userAgent,
        public readonly string $requestId,
    ) {
    }

    public static function capture(): self
    {
        $method = strtoupper((string) ($_SERVER['REQUEST_METHOD'] ?? 'GET'));
        $uri = (string) ($_SERVER['REQUEST_URI'] ?? '/');
        $path = parse_url($uri, PHP_URL_PATH);
        $path = is_string($path) ? $path : '/';
        $path = '/' . trim(rawurldecode($path), '/');

        $basePath = self::basePath();
        if ($basePath !== '' && str_starts_with($path, $basePath)) {
            $path = '/' . ltrim(substr($path, strlen($basePath)), '/');
        }

        $headers = [];
        foreach ($_SERVER as $key => $value) {
            if (is_string($key) && str_starts_with($key, 'HTTP_')) {
                $name = strtolower(str_replace('_', '-', substr($key, 5)));
                $headers[$name] = (string) $value;
            }
        }
        if (isset($_SERVER['CONTENT_TYPE'])) {
            $headers['content-type'] = (string) $_SERVER['CONTENT_TYPE'];
        }
        if (isset($_SERVER['CONTENT_LENGTH'])) {
            $headers['content-length'] = (string) $_SERVER['CONTENT_LENGTH'];
        }
        if (!isset($headers['authorization'])) {
            $authorization = self::authorizationHeader();
            if ($authorization !== null) {
                $headers['authorization'] = $authorization;
            }
        }

        $maxBody = Config::int('MAX_BODY_BYTES', 1_048_576);
        $declared = (int) ($headers['content-length'] ?? 0);
        if ($declared > $maxBody) {
            throw ApiException::payloadTooLarge();
        }

        $body = (string) file_get_contents('php://input', false, null, 0, $maxBody + 1);
        if (strlen($body) > $maxBody) {
            throw ApiException::payloadTooLarge();
        }

        $query = [];
        foreach ($_GET as $key => $value) {
            if (is_string($key) && is_scalar($value)) {
                $query[$key] = (string) $value;
            }
        }

        $requestId = $headers['x-request-id'] ?? '';
        if ($requestId === '' || !preg_match('/^[A-Za-z0-9._-]{1,64}$/', $requestId)) {
            $requestId = bin2hex(random_bytes(8));
        }

        return new self(
            method: $method,
            path: $path === '/' ? '/' : rtrim($path, '/'),
            query: $query,
            headers: $headers,
            body: $body,
            ip: self::clientIp($headers),
            userAgent: mb_substr($headers['user-agent'] ?? '', 0, 255),
            requestId: $requestId,
        );
    }

    /**
     * Where this API is mounted. Configured explicitly, or worked out from the
     * front controller's own path so an install in a sub-directory needs no setup.
     */
    private static function basePath(): string
    {
        $configured = trim((string) Config::get('BASE_PATH', ''));
        if ($configured !== '' && $configured !== '/') {
            return '/' . trim($configured, '/');
        }

        $script = (string) ($_SERVER['SCRIPT_NAME'] ?? '');
        foreach (['/public/index.php', '/index.php'] as $suffix) {
            if (str_ends_with($script, $suffix)) {
                $prefix = substr($script, 0, -strlen($suffix));
                return $prefix === '/' ? '' : rtrim($prefix, '/');
            }
        }

        return '';
    }

    /**
     * Shared hosting running PHP over CGI/FastCGI drops the Authorization header
     * before PHP sees it. These are the places the rewrite rules put it instead.
     */
    private static function authorizationHeader(): ?string
    {
        foreach (['HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION', 'REDIRECT_REDIRECT_HTTP_AUTHORIZATION'] as $key) {
            $value = $_SERVER[$key] ?? null;
            if (is_string($value) && $value !== '') {
                return $value;
            }
        }

        if (function_exists('apache_request_headers')) {
            $headers = apache_request_headers();
            if (is_array($headers)) {
                foreach ($headers as $name => $value) {
                    if (strtolower((string) $name) === 'authorization' && is_string($value) && $value !== '') {
                        return $value;
                    }
                }
            }
        }

        return null;
    }

    /** @param array<string, string> $headers */
    private static function clientIp(array $headers): string
    {
        $remote = (string) ($_SERVER['REMOTE_ADDR'] ?? '');

        // Only trust a forwarded address when the direct peer is a configured proxy.
        $trusted = Config::list('TRUSTED_PROXIES');
        if ($trusted !== [] && in_array($remote, $trusted, true)) {
            $forwarded = $headers['x-forwarded-for'] ?? '';
            if ($forwarded !== '') {
                $first = trim(explode(',', $forwarded)[0]);
                if (filter_var($first, FILTER_VALIDATE_IP) !== false) {
                    return $first;
                }
            }
        }

        return filter_var($remote, FILTER_VALIDATE_IP) !== false ? $remote : '0.0.0.0';
    }

    public function header(string $name): ?string
    {
        return $this->headers[strtolower($name)] ?? null;
    }

    public function bearerToken(): ?string
    {
        $header = $this->header('authorization');
        if ($header === null) {
            return null;
        }
        if (!preg_match('/^Bearer\s+(\S+)$/i', trim($header), $matches)) {
            return null;
        }
        return $matches[1];
    }

    /** @return array<string, mixed> */
    public function json(): array
    {
        if ($this->json !== null) {
            return $this->json;
        }

        if (trim($this->body) === '') {
            return $this->json = [];
        }

        $contentType = strtolower($this->header('content-type') ?? '');
        if ($contentType !== '' && !str_contains($contentType, 'application/json')) {
            throw ApiException::badRequest('The request body must be JSON (Content-Type: application/json).');
        }

        try {
            $decoded = json_decode($this->body, true, 64, JSON_THROW_ON_ERROR);
        } catch (\JsonException $exception) {
            throw ApiException::badRequest('The request body is not valid JSON.');
        }

        if (!is_array($decoded) || array_is_list($decoded)) {
            throw ApiException::badRequest('The request body must be a JSON object.');
        }

        /** @var array<string, mixed> $decoded */
        return $this->json = $decoded;
    }

    public function isSecure(): bool
    {
        if (($_SERVER['HTTPS'] ?? '') !== '' && strtolower((string) $_SERVER['HTTPS']) !== 'off') {
            return true;
        }
        // Some hosts only signal TLS through the port or an SSL flag of their own.
        if ((int) ($_SERVER['SERVER_PORT'] ?? 0) === 443) {
            return true;
        }
        if (strtolower((string) ($_SERVER['REQUEST_SCHEME'] ?? '')) === 'https') {
            return true;
        }
        if (($_SERVER['HTTP_X_FORWARDED_SSL'] ?? '') === 'on') {
            return true;
        }
        $trusted = Config::list('TRUSTED_PROXIES');
        $remote = (string) ($_SERVER['REMOTE_ADDR'] ?? '');
        if ($trusted !== [] && in_array($remote, $trusted, true)) {
            return strtolower($this->header('x-forwarded-proto') ?? '') === 'https';
        }
        return false;
    }

    public function isLocal(): bool
    {
        return in_array($this->ip, ['127.0.0.1', '::1', '0.0.0.0'], true);
    }

    public function ipBinary(): ?string
    {
        $packed = @inet_pton($this->ip);
        return $packed === false ? null : $packed;
    }
}
