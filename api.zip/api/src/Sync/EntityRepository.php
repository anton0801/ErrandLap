<?php

declare(strict_types=1);

namespace ErrandRun\Sync;

use ErrandRun\Core\ApiException;
use ErrandRun\Core\Clock;
use ErrandRun\Core\Config;
use ErrandRun\Core\Database;
use DateTimeImmutable;

/**
 * Storage for every synced collection.
 *
 * Every statement is scoped by user_id, and the tables are keyed on
 * (user_id, id), so one account can never read or write another's row even if a
 * caller supplies someone else's identifier.
 */
final class EntityRepository
{
    private const MAX_PAYLOAD_BYTES = 32768;

    /**
     * Validates one incoming item and returns it in a storable shape.
     *
     * @param array<string, mixed> $item
     * @return array{id: string, updated_at: DateTimeImmutable, deleted: bool, payload: array<string, mixed>}
     */
    public static function normaliseItem(string $collection, array $item, string $context = 'item'): array
    {
        $config = Collections::config($collection);
        $errors = [];

        $rawId = $item['id'] ?? ($item['key'] ?? null);
        $id = null;
        if (!is_string($rawId) || $rawId === '') {
            $errors[$context . '.id'] = 'This field is required.';
        } elseif ($config['id_type'] === 'uuid') {
            if (preg_match('/^[0-9a-fA-F]{8}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{4}-[0-9a-fA-F]{12}$/', $rawId) !== 1) {
                $errors[$context . '.id'] = 'This must be a UUID.';
            } else {
                $id = strtoupper($rawId);
            }
        } else {
            if (mb_strlen($rawId) > 190 || preg_match('/^[\x20-\x7E]+$/', $rawId) !== 1) {
                $errors[$context . '.id'] = 'This key is not acceptable.';
            } else {
                $id = $rawId;
            }
        }

        $deleted = false;
        if (array_key_exists('deleted', $item)) {
            if (!is_bool($item['deleted'])) {
                $errors[$context . '.deleted'] = 'This field must be true or false.';
            } else {
                $deleted = $item['deleted'];
            }
        }

        $updatedAt = null;
        $rawUpdated = $item['updated_at'] ?? null;
        if (!is_string($rawUpdated) || $rawUpdated === '') {
            $errors[$context . '.updated_at'] = 'This field is required.';
        } else {
            $parsed = Clock::parseIso($rawUpdated);
            if ($parsed === null) {
                $errors[$context . '.updated_at'] = 'This must be an ISO-8601 timestamp.';
            } else {
                // A client clock that runs ahead must not win every future conflict.
                $ceiling = Clock::plusSeconds(300);
                $updatedAt = $parsed > $ceiling ? $ceiling : $parsed;
            }
        }

        $payload = [];
        if (!$deleted) {
            $rawPayload = $item['payload'] ?? null;
            if (!is_array($rawPayload) || array_is_list($rawPayload)) {
                $errors[$context . '.payload'] = 'This field must be an object.';
            } else {
                $encoded = json_encode($rawPayload);
                if ($encoded === false || strlen($encoded) > self::MAX_PAYLOAD_BYTES) {
                    $errors[$context . '.payload'] = 'This object is too large.';
                } else {
                    foreach (array_keys($rawPayload) as $key) {
                        if (!in_array((string) $key, $config['allowed_keys'], true)) {
                            $errors[$context . '.payload.' . $key] = 'This field is not accepted.';
                        }
                    }
                    if (self::depth($rawPayload) > 8) {
                        $errors[$context . '.payload'] = 'This object is nested too deeply.';
                    }
                    /** @var array<string, mixed> $rawPayload */
                    $payload = $rawPayload;
                }
            }
        }

        if ($errors !== []) {
            throw ApiException::validation($errors);
        }

        /** @var string $id */
        /** @var DateTimeImmutable $updatedAt */
        return ['id' => $id, 'updated_at' => $updatedAt, 'deleted' => $deleted, 'payload' => $payload];
    }

    private static function depth(mixed $value, int $level = 1): int
    {
        if (!is_array($value) || $level > 12) {
            return $level;
        }
        $deepest = $level;
        foreach ($value as $child) {
            if (is_array($child)) {
                $deepest = max($deepest, self::depth($child, $level + 1));
            }
        }
        return $deepest;
    }

    /**
     * Writes one item, keeping whichever version was edited last.
     *
     * @param array{id: string, updated_at: DateTimeImmutable, deleted: bool, payload: array<string, mixed>} $item
     * @return array{status: string, item: array<string, mixed>}
     */
    public static function upsert(string $userId, string $collection, array $item): array
    {
        $config = Collections::config($collection);
        $table = $config['table'];
        $idColumn = $config['id_column'];
        $now = Clock::now();

        $existing = Database::first(
            sprintf('SELECT %s AS entity_id, revision, client_updated_at, deleted_at FROM %s WHERE user_id = :user_id AND %s = :id LIMIT 1', $idColumn, $table, $idColumn),
            ['user_id' => $userId, 'id' => $item['id']],
        );

        if ($existing !== null) {
            $existingUpdated = Clock::fromSql((string) $existing['client_updated_at']);
            if ($existingUpdated !== null && $existingUpdated > $item['updated_at']) {
                return ['status' => 'kept_server', 'item' => self::fetch($userId, $collection, $item['id']) ?? []];
            }
        }

        $extra = self::extractColumns($config, $item['payload'], $item['deleted']);

        $columns = array_merge(['user_id', $idColumn], array_keys($extra), [
            'payload', 'revision', 'client_updated_at', 'updated_at', 'deleted_at',
        ]);
        $placeholders = array_map(static fn (string $column): string => ':' . $column, $columns);

        $params = array_merge(
            ['user_id' => $userId, $idColumn => $item['id']],
            $extra,
            [
                'payload'           => json_encode($item['deleted'] ? new \stdClass() : $item['payload'], JSON_UNESCAPED_UNICODE),
                'revision'          => 1,
                'client_updated_at' => Clock::sql($item['updated_at']),
                'updated_at'        => Clock::sql($now),
                'deleted_at'        => $item['deleted'] ? Clock::sql($now) : null,
            ],
        );

        $alias = Database::supportsRowAlias();
        $incoming = static fn (string $column): string => $alias
            ? sprintf('%s = incoming.%s', $column, $column)
            : sprintf('%s = VALUES(%s)', $column, $column);

        $updates = array_map($incoming, array_keys($extra));
        $updates[] = $incoming('payload');
        $updates[] = sprintf('revision = %s.revision + 1', $table);
        $updates[] = $incoming('client_updated_at');
        $updates[] = $incoming('updated_at');
        $updates[] = $incoming('deleted_at');

        Database::run(
            sprintf(
                'INSERT INTO %s (%s) VALUES (%s)%s ON DUPLICATE KEY UPDATE %s',
                $table,
                implode(', ', $columns),
                implode(', ', $placeholders),
                $alias ? ' AS incoming' : '',
                implode(', ', $updates),
            ),
            $params,
        );

        return [
            'status' => $existing === null ? 'created' : 'updated',
            'item'   => self::fetch($userId, $collection, $item['id']) ?? [],
        ];
    }

    /**
     * @param array{columns: array<string, array{key: string, type: string, max?: int, default: mixed}>} $config
     * @param array<string, mixed> $payload
     * @return array<string, mixed>
     */
    private static function extractColumns(array $config, array $payload, bool $deleted): array
    {
        $values = [];
        foreach ($config['columns'] as $column => $rule) {
            $raw = $deleted ? null : ($payload[$rule['key']] ?? null);
            $values[$column] = match ($rule['type']) {
                'string' => is_string($raw) && $raw !== ''
                    ? mb_substr($raw, 0, $rule['max'] ?? 190)
                    : $rule['default'],
                'int' => is_int($raw) ? min($raw, $rule['max'] ?? PHP_INT_MAX) : (is_numeric($raw) ? (int) $raw : $rule['default']),
                'uuid_or_null' => is_string($raw) && preg_match('/^[0-9a-fA-F-]{36}$/', $raw) === 1 ? strtoupper($raw) : null,
                'date_or_null' => self::toDate($raw),
                default => $rule['default'],
            };
        }
        return $values;
    }

    private static function toDate(mixed $raw): ?string
    {
        if (!is_string($raw) || $raw === '') {
            return null;
        }
        $moment = Clock::parseIso($raw);
        return $moment?->format('Y-m-d');
    }

    /** @return array<string, mixed>|null */
    public static function fetch(string $userId, string $collection, string $id): ?array
    {
        $config = Collections::config($collection);
        $row = Database::first(
            sprintf(
                'SELECT %s AS entity_id, payload, revision, client_updated_at, updated_at, deleted_at
                   FROM %s WHERE user_id = :user_id AND %s = :id LIMIT 1',
                $config['id_column'],
                $config['table'],
                $config['id_column'],
            ),
            ['user_id' => $userId, 'id' => $id],
        );
        return $row === null ? null : self::present($row);
    }

    /**
     * @return list<array<string, mixed>>
     */
    public static function pull(string $userId, string $collection, ?DateTimeImmutable $since, bool $includeDeleted = true, int $limit = 1000): array
    {
        $config = Collections::config($collection);
        $limit = max(1, min($limit, Config::int('SYNC_PAGE_SIZE', 1000)));

        $sql = sprintf(
            'SELECT %s AS entity_id, payload, revision, client_updated_at, updated_at, deleted_at
               FROM %s
              WHERE user_id = :user_id',
            $config['id_column'],
            $config['table'],
        );
        $params = ['user_id' => $userId];

        if ($since !== null) {
            $sql .= ' AND updated_at > :since';
            $params['since'] = Clock::sql($since);
        }
        if (!$includeDeleted) {
            $sql .= ' AND deleted_at IS NULL';
        }

        $sql .= sprintf(' ORDER BY updated_at ASC LIMIT %d', $limit);

        return array_map(self::present(...), Database::all($sql, $params));
    }

    /** @param array<string, mixed> $row */
    private static function present(array $row): array
    {
        $payload = [];
        if (is_string($row['payload']) && $row['payload'] !== '') {
            $decoded = json_decode($row['payload'], true);
            if (is_array($decoded)) {
                /** @var array<string, mixed> $decoded */
                $payload = $decoded;
            }
        }

        return [
            'id'                => (string) $row['entity_id'],
            'deleted'           => $row['deleted_at'] !== null,
            'updated_at'        => Clock::isoFromSql((string) $row['client_updated_at']),
            'server_updated_at' => Clock::isoFromSql((string) $row['updated_at']),
            'revision'          => (int) $row['revision'],
            'payload'           => $payload === [] ? new \stdClass() : $payload,
        ];
    }

    public static function softDelete(string $userId, string $collection, string $id, DateTimeImmutable $updatedAt): bool
    {
        $config = Collections::config($collection);
        $now = Clock::now();

        $affected = Database::run(
            sprintf(
                'UPDATE %s
                    SET payload = :empty, deleted_at = :deleted, client_updated_at = :client, updated_at = :now,
                        revision = revision + 1
                  WHERE user_id = :user_id AND %s = :id AND deleted_at IS NULL',
                $config['table'],
                $config['id_column'],
            ),
            [
                'empty'   => '{}',
                'deleted' => Clock::sql($now),
                'client'  => Clock::sql($updatedAt),
                'now'     => Clock::sql($now),
                'user_id' => $userId,
                'id'      => $id,
            ],
        )->rowCount();

        return $affected > 0;
    }

    /** Tombstones are not kept forever. */
    public static function purgeTombstones(string $userId): void
    {
        $days = Config::int('TOMBSTONE_DAYS', 90);
        $cutoff = Clock::sql(Clock::plusSeconds(-$days * 86400));
        foreach (Collections::all() as $collection) {
            $config = Collections::config($collection);
            Database::run(
                sprintf('DELETE FROM %s WHERE user_id = :user_id AND deleted_at IS NOT NULL AND deleted_at < :cutoff LIMIT 500', $config['table']),
                ['user_id' => $userId, 'cutoff' => $cutoff],
            );
        }
    }

    /** @return array<string, int> */
    public static function counts(string $userId): array
    {
        $counts = [];
        foreach (Collections::all() as $collection) {
            $config = Collections::config($collection);
            $row = Database::first(
                sprintf('SELECT COUNT(*) AS total FROM %s WHERE user_id = :user_id AND deleted_at IS NULL', $config['table']),
                ['user_id' => $userId],
            );
            $counts[$collection] = (int) ($row['total'] ?? 0);
        }
        return $counts;
    }
}
