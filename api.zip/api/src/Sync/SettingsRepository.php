<?php

declare(strict_types=1);

namespace ErrandRun\Sync;

use DateTimeImmutable;
use ErrandRun\Core\ApiException;
use ErrandRun\Core\Clock;
use ErrandRun\Core\Database;

/**
 * One settings document per account: the profile fields the planner needs
 * (home, work, travel mode, buffer) plus the local preferences.
 */
final class SettingsRepository
{
    private const ALLOWED_KEYS = [
        'displayName', 'homeAddress', 'homeCoordinate', 'workAddress', 'workCoordinate',
        'travelMode', 'walkingPace', 'buffer', 'onboardingSeen', 'setupComplete',
        'notificationsEnabled', 'notifications', 'learnFromVisits',
    ];

    private const MAX_BYTES = 8192;

    /** @return array<string, mixed>|null */
    public static function fetch(string $userId): ?array
    {
        $row = Database::first(
            'SELECT payload, revision, client_updated_at, updated_at FROM user_settings WHERE user_id = :user_id LIMIT 1',
            ['user_id' => $userId],
        );
        if ($row === null) {
            return null;
        }

        $payload = json_decode((string) $row['payload'], true);
        return [
            'updated_at'        => Clock::isoFromSql((string) $row['client_updated_at']),
            'server_updated_at' => Clock::isoFromSql((string) $row['updated_at']),
            'revision'          => (int) $row['revision'],
            'payload'           => is_array($payload) && $payload !== [] ? $payload : new \stdClass(),
        ];
    }

    /**
     * @param array<string, mixed> $payload
     * @return array{status: string, settings: array<string, mixed>}
     */
    public static function save(string $userId, array $payload, DateTimeImmutable $updatedAt): array
    {
        $errors = [];
        foreach (array_keys($payload) as $key) {
            if (!in_array((string) $key, self::ALLOWED_KEYS, true)) {
                $errors['settings.payload.' . $key] = 'This field is not accepted.';
            }
        }
        $encoded = json_encode($payload, JSON_UNESCAPED_UNICODE);
        if ($encoded === false || strlen($encoded) > self::MAX_BYTES) {
            $errors['settings.payload'] = 'This object is too large.';
        }
        if ($errors !== []) {
            throw ApiException::validation($errors);
        }

        $existing = Database::first(
            'SELECT client_updated_at FROM user_settings WHERE user_id = :user_id LIMIT 1',
            ['user_id' => $userId],
        );
        if ($existing !== null) {
            $existingUpdated = Clock::fromSql((string) $existing['client_updated_at']);
            if ($existingUpdated !== null && $existingUpdated > $updatedAt) {
                return ['status' => 'kept_server', 'settings' => self::fetch($userId) ?? []];
            }
        }

        $now = Clock::now();
        $alias = Database::supportsRowAlias();
        Database::run(
            sprintf(
                'INSERT INTO user_settings (user_id, payload, revision, client_updated_at, updated_at)
                 VALUES (:user_id, :payload, 1, :client, :now)%1$s
                 ON DUPLICATE KEY UPDATE
                    payload = %2$s,
                    revision = user_settings.revision + 1,
                    client_updated_at = %3$s,
                    updated_at = %4$s',
                $alias ? ' AS incoming' : '',
                $alias ? 'incoming.payload' : 'VALUES(payload)',
                $alias ? 'incoming.client_updated_at' : 'VALUES(client_updated_at)',
                $alias ? 'incoming.updated_at' : 'VALUES(updated_at)',
            ),
            [
                'user_id' => $userId,
                'payload' => $encoded,
                'client'  => Clock::sql($updatedAt),
                'now'     => Clock::sql($now),
            ],
        );

        // The account-level display name follows the settings document.
        $displayName = $payload['displayName'] ?? null;
        if (is_string($displayName)) {
            Database::run(
                'UPDATE users SET display_name = :name, updated_at = :now WHERE id = :id',
                ['name' => mb_substr(trim($displayName), 0, 80), 'now' => Clock::sql($now), 'id' => $userId],
            );
        }

        return ['status' => $existing === null ? 'created' : 'updated', 'settings' => self::fetch($userId) ?? []];
    }
}
