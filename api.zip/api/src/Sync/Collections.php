<?php

declare(strict_types=1);

namespace ErrandRun\Sync;

use ErrandRun\Core\ApiException;

/**
 * The synced collections, described once and used by both the REST resources and
 * the delta-sync endpoint.
 *
 * `columns` are the fields lifted out of the payload into real SQL columns so the
 * server can index and validate them. `allowed_keys` is a whitelist: a payload
 * carrying anything else is rejected rather than stored.
 */
final class Collections
{
    public const PLACES       = 'places';
    public const ERRANDS      = 'errands';
    public const WINDOWS      = 'windows';
    public const RUNS         = 'runs';
    public const VISITS       = 'visits';
    public const WASTED_TRIPS = 'wasted_trips';
    public const TRAVEL_TIMES = 'travel_times';

    /** @return list<string> */
    public static function all(): array
    {
        return [
            self::PLACES,
            self::ERRANDS,
            self::WINDOWS,
            self::RUNS,
            self::VISITS,
            self::WASTED_TRIPS,
            self::TRAVEL_TIMES,
        ];
    }

    /** Maps the URL segment (kebab-case) onto the internal name. */
    public static function fromPath(string $segment): string
    {
        $name = str_replace('-', '_', $segment);
        if (!in_array($name, self::all(), true)) {
            throw ApiException::notFound('No such collection.');
        }
        return $name;
    }

    public static function toPath(string $collection): string
    {
        return str_replace('_', '-', $collection);
    }

    /**
     * @return array{
     *     table: string,
     *     id_column: string,
     *     id_type: string,
     *     columns: array<string, array{key: string, type: string, max?: int, default: mixed}>,
     *     allowed_keys: list<string>
     * }
     */
    public static function config(string $collection): array
    {
        return match ($collection) {
            self::PLACES => [
                'table'     => 'places',
                'id_column' => 'id',
                'id_type'   => 'uuid',
                'columns'   => [
                    'name'     => ['key' => 'name', 'type' => 'string', 'max' => 120, 'default' => ''],
                    'category' => ['key' => 'category', 'type' => 'string', 'max' => 24, 'default' => 'other'],
                ],
                'allowed_keys' => [
                    'id', 'name', 'address', 'category', 'hours', 'parking', 'queueEstimate',
                    'notes', 'photos', 'coordinate', 'createdAt', 'updatedAt',
                ],
            ],
            self::ERRANDS => [
                'table'     => 'errands',
                'id_column' => 'id',
                'id_type'   => 'uuid',
                'columns'   => [
                    'title'    => ['key' => 'title', 'type' => 'string', 'max' => 200, 'default' => ''],
                    'place_id' => ['key' => 'placeID', 'type' => 'uuid_or_null', 'default' => null],
                    'state'    => ['key' => 'state', 'type' => 'string', 'max' => 16, 'default' => 'open'],
                ],
                'allowed_keys' => [
                    'id', 'title', 'placeID', 'category', 'duration', 'deadline', 'priority',
                    'requiresDocuments', 'documents', 'canBeDelegated', 'dependsOn', 'notes',
                    'state', 'doneAt', 'shopping', 'recurrence', 'delegation', 'createdAt',
                    'lastPlannedRunID', 'updatedAt',
                ],
            ],
            self::WINDOWS => [
                'table'     => 'windows',
                'id_column' => 'id',
                'id_type'   => 'uuid',
                'columns'   => [
                    'title' => ['key' => 'title', 'type' => 'string', 'max' => 120, 'default' => ''],
                ],
                'allowed_keys' => [
                    'id', 'title', 'isRecurring', 'weekdays', 'date', 'start', 'end',
                    'from', 'to', 'travelMode', 'isEnabled', 'updatedAt',
                ],
            ],
            self::RUNS => [
                'table'     => 'runs',
                'id_column' => 'id',
                'id_type'   => 'uuid',
                'columns'   => [
                    'run_day' => ['key' => 'day', 'type' => 'date_or_null', 'default' => null],
                    'state'   => ['key' => 'state', 'type' => 'string', 'max' => 16, 'default' => 'planned'],
                ],
                'allowed_keys' => [
                    'id', 'day', 'windowID', 'windowTitle', 'start', 'end', 'from', 'to',
                    'travelMode', 'stops', 'didNotFit', 'state', 'startedAt', 'finishedAt',
                    'lateMinutes', 'returnTravel', 'updatedAt',
                ],
            ],
            self::VISITS => [
                'table'     => 'visits',
                'id_column' => 'id',
                'id_type'   => 'uuid',
                'columns'   => [
                    'place_id' => ['key' => 'placeID', 'type' => 'uuid_or_null', 'default' => null],
                ],
                'allowed_keys' => [
                    'id', 'placeID', 'errandID', 'date', 'estimated', 'actual', 'taskMinutes', 'updatedAt',
                ],
            ],
            self::WASTED_TRIPS => [
                'table'     => 'wasted_trips',
                'id_column' => 'id',
                'id_type'   => 'uuid',
                'columns'   => [
                    'place_id' => ['key' => 'placeID', 'type' => 'uuid_or_null', 'default' => null],
                    'reason'   => ['key' => 'reason', 'type' => 'string', 'max' => 32, 'default' => 'other'],
                ],
                'allowed_keys' => [
                    'id', 'placeID', 'errandID', 'date', 'reason', 'missing', 'notes', 'updatedAt',
                ],
            ],
            self::TRAVEL_TIMES => [
                'table'     => 'travel_times',
                'id_column' => 'cache_key',
                'id_type'   => 'key',
                'columns'   => [
                    'minutes' => ['key' => 'minutes', 'type' => 'int', 'max' => 100000, 'default' => 0],
                    'source'  => ['key' => 'source', 'type' => 'string', 'max' => 16, 'default' => 'manual'],
                ],
                'allowed_keys' => ['key', 'minutes', 'source', 'updatedAt'],
            ],
            default => throw ApiException::notFound('No such collection.'),
        };
    }
}
