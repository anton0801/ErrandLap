<?php

declare(strict_types=1);

namespace ErrandRun\Http;

/**
 * The authenticated caller for the current request.
 */
final class AuthContext
{
    /** @param array<string, mixed> $user */
    public function __construct(
        public readonly string $userId,
        public readonly string $sessionId,
        public readonly array $user,
    ) {
    }

    public function email(): string
    {
        return (string) ($this->user['email'] ?? '');
    }

    public function displayName(): string
    {
        return (string) ($this->user['display_name'] ?? '');
    }
}
