<?php

declare(strict_types=1);

namespace ErrandRun\Web;

use ErrandRun\Core\Clock;
use ErrandRun\Core\Config;
use ErrandRun\Core\Database;
use ErrandRun\Core\Request;
use ErrandRun\Security\TokenService;

/**
 * The player behind the WebView, identified by one cookie and nothing else.
 *
 * The cookie carries a random value and no data. The server keeps only its
 * SHA-256 hash, the same way it treats access tokens: a copy of the database
 * hands nobody a working session. There is no link to an account, so what
 * happens in the WebView cannot reach anyone's errands.
 */
final class PlayerSession
{
    public const COOKIE = 'er_play';

    /** Two years, refreshed on every visit, so the progress survives app restarts. */
    private const LIFETIME = 63_072_000;

    /**
     * Finds the player behind the request, or starts one, and refreshes the cookie.
     *
     * @return array<string, mixed>
     */
    public static function open(Request $request, bool $countVisit = false): array
    {
        $presented = $_COOKIE[self::COOKIE] ?? null;
        $player = null;

        if (is_string($presented) && $presented !== '' && strlen($presented) <= 128) {
            $player = Database::first(
                'SELECT * FROM web_players WHERE cookie_hash = :hash LIMIT 1',
                ['hash' => hash('sha256', $presented)],
            );
        }

        if ($player === null) {
            [$player, $presented] = self::create($request);
        }

        // Rolling expiry: an app opened regularly never loses its progress.
        self::sendCookie((string) $presented, $request);

        if ($countVisit) {
            Database::run(
                'UPDATE web_players SET visits = visits + 1, last_seen_at = :now WHERE id = :id',
                ['now' => Clock::sql(), 'id' => $player['id']],
            );
            $player['visits'] = ((int) $player['visits']) + 1;
        }

        return $player;
    }

    /** @return array{0: array<string, mixed>, 1: string} */
    private static function create(Request $request): array
    {
        $value = 'erp_' . rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
        $id = TokenService::uuid();
        $now = Clock::sql();

        Database::run(
            'INSERT INTO web_players (id, cookie_hash, state, created_at, updated_at, last_seen_at)
             VALUES (:id, :hash, :state, :created, :updated, :seen)',
            [
                'id'      => $id,
                'hash'    => hash('sha256', $value),
                'state'   => '{}',
                'created' => $now,
                'updated' => $now,
                'seen'    => $now,
            ],
        );

        $player = Database::first('SELECT * FROM web_players WHERE id = :id LIMIT 1', ['id' => $id]);

        return [$player ?? [], $value];
    }

    private static function sendCookie(string $value, Request $request): void
    {
        if (headers_sent()) {
            return;
        }

        setcookie(self::COOKIE, $value, [
            'expires'  => time() + self::LIFETIME,
            'path'     => '/',
            // Without HTTPS the browser drops a Secure cookie, which would look
            // like "cookies do not work" on a developer machine.
            'secure'   => $request->isSecure() || !Config::bool('ALLOW_INSECURE_HTTP', false),
            'httponly' => true,
            'samesite' => 'Lax',
        ]);
    }

    /**
     * Records a finished round and returns the player as it now stands.
     *
     * @return array<string, mixed>
     */
    public static function recordRound(string $playerId, int $score, int $combo, int $sparks): array
    {
        $now = Clock::now();
        $today = $now->format('Y-m-d');

        $player = Database::first('SELECT * FROM web_players WHERE id = :id LIMIT 1', ['id' => $playerId]);
        if ($player === null) {
            return [];
        }

        $lastPlayed = $player['last_played_on'] === null ? null : (string) $player['last_played_on'];
        $yesterday = $now->modify('-1 day')->format('Y-m-d');

        $streak = (int) $player['streak_days'];
        if ($lastPlayed === $today) {
            $streak = max(1, $streak);
        } elseif ($lastPlayed === $yesterday) {
            $streak = $streak + 1;
        } else {
            $streak = 1;
        }

        Database::run(
            'UPDATE web_players
                SET best_score     = GREATEST(best_score, :score_best),
                    last_score     = :score_last,
                    best_combo     = GREATEST(best_combo, :combo),
                    rounds_played  = rounds_played + 1,
                    sparks_caught  = sparks_caught + :sparks,
                    streak_days    = :streak,
                    best_streak    = GREATEST(best_streak, :streak_best),
                    last_played_on = :played_on,
                    updated_at     = :updated,
                    last_seen_at   = :seen
              WHERE id = :id',
            [
                'score_best'  => $score,
                'score_last'  => $score,
                'combo'       => $combo,
                'sparks'      => $sparks,
                'streak'      => $streak,
                'streak_best' => $streak,
                'played_on'   => $today,
                'updated'     => Clock::sql($now),
                'seen'        => Clock::sql($now),
                'id'          => $playerId,
            ],
        );

        return Database::first('SELECT * FROM web_players WHERE id = :id LIMIT 1', ['id' => $playerId]) ?? [];
    }

    /**
     * What the page and the API are allowed to know about the player.
     *
     * @param array<string, mixed> $player
     * @return array<string, mixed>
     */
    public static function present(array $player): array
    {
        return [
            'best_score'    => (int) ($player['best_score'] ?? 0),
            'last_score'    => (int) ($player['last_score'] ?? 0),
            'best_combo'    => (int) ($player['best_combo'] ?? 0),
            'rounds_played' => (int) ($player['rounds_played'] ?? 0),
            'sparks_caught' => (int) ($player['sparks_caught'] ?? 0),
            'streak_days'   => (int) ($player['streak_days'] ?? 0),
            'best_streak'   => (int) ($player['best_streak'] ?? 0),
            'visits'        => (int) ($player['visits'] ?? 0),
            'since'         => Clock::isoFromSql((string) ($player['created_at'] ?? '')),
        ];
    }

    /** Housekeeping: a player who never came back is not kept forever. */
    public static function sweep(): void
    {
        if (random_int(1, 200) !== 1) {
            return;
        }
        Database::run(
            'DELETE FROM web_players
              WHERE last_seen_at < :cutoff AND rounds_played = 0
              LIMIT 500',
            ['cutoff' => Clock::sql(Clock::plusSeconds(-30 * 86400))],
        );
    }
}
