<?php

declare(strict_types=1);

namespace ErrandRun\Web;

use DateTimeImmutable;
use ErrandRun\Core\Clock;

/**
 * The season the mini-game is running in.
 *
 * Decided by the server, not the device, so everyone is in the same season on the
 * same day and a phone with a wrong clock cannot pick its own difficulty. The
 * palette never changes — the studio's fire colours stay — what changes is the
 * name, the pace and how the sparks behave.
 */
final class Season
{
    /** @return array<string, mixed> */
    public static function current(?DateTimeImmutable $now = null): array
    {
        $now ??= Clock::now();
        $month = (int) $now->format('n');

        $season = match (true) {
            $month >= 3 && $month <= 5   => [
                'key'     => 'spring',
                'name'    => 'Spring Run',
                'tagline' => 'Everything reopens. Catch it while it is open.',
                'spawn'   => 780,
                'fade'    => 1750,
                'door'    => 0.12,
                'gold'    => 0.10,
            ],
            $month >= 6 && $month <= 8   => [
                'key'     => 'summer',
                'name'    => 'Summer Run',
                'tagline' => 'Long days, short lunch breaks.',
                'spawn'   => 700,
                'fade'    => 1600,
                'door'    => 0.14,
                'gold'    => 0.12,
            ],
            $month >= 9 && $month <= 11  => [
                'key'     => 'autumn',
                'name'    => 'Autumn Run',
                'tagline' => 'Doors close earlier every week.',
                'spawn'   => 640,
                'fade'    => 1450,
                'door'    => 0.18,
                'gold'    => 0.11,
            ],
            default                      => [
                'key'     => 'winter',
                'name'    => 'Winter Run',
                'tagline' => 'Short daylight. Shorter opening hours.',
                'spawn'   => 700,
                'fade'    => 1900,
                'door'    => 0.20,
                'gold'    => 0.09,
            ],
        };

        // Same sequence of sparks for everyone on the same day.
        $season['seed'] = (int) $now->format('Ymd');
        $season['day'] = $now->format('j F Y');
        $season['round_ms'] = 45_000;

        return $season;
    }
}
