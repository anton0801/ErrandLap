/*
 * Spark Run — a 45 second round inside the app's WebView.
 *
 * Nothing is stored in the page: the score, the streak and how long this player
 * has existed all come from the server, which knows them by one cookie. Close
 * the app, reopen it, and the numbers are still there — that is the point of
 * the exercise as much as the game is.
 */

(function () {
    'use strict';

    var body = document.body;
    var field = document.getElementById('field');

    var config = {
        roundMs: parseInt(body.dataset.round, 10) || 45000,
        spawnMs: parseInt(body.dataset.spawn, 10) || 700,
        fadeMs: parseInt(body.dataset.fade, 10) || 1600,
        doorChance: parseFloat(body.dataset.door) || 0.15,
        goldChance: parseFloat(body.dataset.gold) || 0.1,
        seed: parseInt(body.dataset.seed, 10) || 20260101
    };

    var stats = {
        best: parseInt(body.dataset.best, 10) || 0,
        streak: parseInt(body.dataset.streak, 10) || 0,
        rounds: parseInt(body.dataset.rounds, 10) || 0,
        visits: parseInt(body.dataset.visits, 10) || 0
    };

    /* ---- the bridge to whatever WebView is hosting this ------------------
     * Every call is optional. If the host implements nothing, the game still
     * works; it simply loses the haptics and the close button.
     */
    var native = {
        available: false,

        send: function (type, payload) {
            var message = Object.assign({ type: type, source: 'errandrun-web' }, payload || {});
            try {
                if (window.webkit && window.webkit.messageHandlers && window.webkit.messageHandlers.errandrun) {
                    window.webkit.messageHandlers.errandrun.postMessage(message);
                    return true;
                }
                if (window.ErrandRunNative && typeof window.ErrandRunNative.postMessage === 'function') {
                    window.ErrandRunNative.postMessage(JSON.stringify(message));
                    return true;
                }
            } catch (error) {
                /* A host that refuses messages is not a reason to stop playing. */
            }
            return false;
        },

        haptic: function (kind) {
            this.send('haptic', { style: kind });
        }
    };

    native.available = native.send('ready', { game: 'spark-run' });
    if (native.available) {
        document.getElementById('close-button').classList.remove('hidden');
    }

    /* The host can pause the round when it covers the screen, and resume after. */
    window.ErrandRunWeb = {
        pause: function () { if (state.running) { pauseRound(); } },
        resume: function () { if (state.running) { resumeRound(); } },
        version: 1
    };

    /* ---- a seeded generator, so everyone gets the same day ---------------- */

    function makeRandom(seed) {
        var value = seed % 2147483647;
        if (value <= 0) { value += 2147483646; }
        return function () {
            value = (value * 16807) % 2147483647;
            return (value - 1) / 2147483646;
        };
    }

    var random = makeRandom(config.seed);

    /* ---- elements -------------------------------------------------------- */

    var el = {
        timer: document.getElementById('timer'),
        score: document.getElementById('score'),
        barFill: document.getElementById('bar-fill'),
        startPanel: document.getElementById('start-panel'),
        endPanel: document.getElementById('end-panel'),
        startButton: document.getElementById('start-button'),
        againButton: document.getElementById('again-button'),
        closeButton: document.getElementById('close-button'),
        startStats: document.getElementById('start-stats'),
        endStats: document.getElementById('end-stats'),
        endTitle: document.getElementById('end-title'),
        endKicker: document.getElementById('end-kicker'),
        finalScore: document.getElementById('final-score'),
        savedNote: document.getElementById('saved-note'),
        combo: document.getElementById('combo-pill')
    };

    var state = {
        running: false,
        paused: false,
        score: 0,
        streak: 0,
        bestStreak: 0,
        caught: 0,
        endsAt: 0,
        remaining: 0,
        startedAt: 0,
        spawnTimer: null,
        tickTimer: null,
        targets: []
    };

    /* ---- helpers --------------------------------------------------------- */

    function multiplier() {
        return Math.min(5, Math.floor(state.streak / 5) + 1);
    }

    function showCombo() {
        var value = multiplier();
        if (value > 1) {
            el.combo.textContent = '×' + value;
            el.combo.classList.remove('hidden');
        } else {
            el.combo.classList.add('hidden');
        }
    }

    function floatText(x, y, text, miss) {
        var node = document.createElement('span');
        node.className = 'gain' + (miss ? ' miss' : '');
        node.textContent = text;
        node.style.left = x + 'px';
        node.style.top = y + 'px';
        field.appendChild(node);
        window.setTimeout(function () { node.remove(); }, 640);
    }

    function burst(x, y) {
        var node = document.createElement('div');
        node.className = 'burst';
        node.style.left = x + 'px';
        node.style.top = y + 'px';
        for (var i = 0; i < 6; i++) {
            var shard = document.createElement('i');
            var angle = (Math.PI * 2 * i) / 6;
            shard.style.transform = 'translate(' + Math.cos(angle) * 26 + 'px,' + Math.sin(angle) * 26 + 'px) rotate(45deg)';
            node.appendChild(shard);
        }
        field.appendChild(node);
        window.setTimeout(function () { node.remove(); }, 480);
    }

    /* ---- targets --------------------------------------------------------- */

    function spawn() {
        if (!state.running || state.paused) { return; }

        var box = field.getBoundingClientRect();
        var margin = 52;
        var x = margin + random() * Math.max(1, box.width - margin * 2);
        var y = margin + random() * Math.max(1, box.height - margin * 2);

        var roll = random();
        var kind = 'spark';
        if (roll < config.doorChance) {
            kind = 'door';
        } else if (roll < config.doorChance + config.goldChance) {
            kind = 'gold';
        }

        var life = kind === 'gold' ? config.fadeMs * 0.62 : config.fadeMs;

        var node = document.createElement('div');
        node.className = 'target ' + kind;
        node.style.left = x + 'px';
        node.style.top = y + 'px';
        node.innerHTML = '<span class="ring"></span><span class="core"></span>';

        var target = { node: node, kind: kind, x: x, y: y, dead: false };

        var ring = node.querySelector('.ring');
        ring.animate(
            [{ transform: 'scale(1)', opacity: 0.75 }, { transform: 'scale(0.25)', opacity: 0 }],
            { duration: life, easing: 'linear', fill: 'forwards' }
        );

        target.expiry = window.setTimeout(function () { expire(target); }, life);

        node.addEventListener('pointerdown', function (event) {
            event.preventDefault();
            hit(target);
        }, { passive: false });

        field.appendChild(node);
        state.targets.push(target);
    }

    function remove(target) {
        if (target.dead) { return; }
        target.dead = true;
        window.clearTimeout(target.expiry);
        target.node.classList.add('dying');
        window.setTimeout(function () { target.node.remove(); }, 200);
        state.targets = state.targets.filter(function (item) { return item !== target; });
    }

    function hit(target) {
        if (target.dead || !state.running || state.paused) { return; }

        if (target.kind === 'door') {
            state.endsAt -= 3000;
            state.streak = 0;
            showCombo();
            floatText(target.x, target.y, '−3s', true);
            native.haptic('warning');
            remove(target);
            return;
        }

        var base = target.kind === 'gold' ? 25 : 10;
        var gained = base * multiplier();

        state.score += gained;
        state.caught += 1;
        state.streak += 1;
        state.bestStreak = Math.max(state.bestStreak, state.streak);

        el.score.textContent = state.score;
        showCombo();
        burst(target.x, target.y);
        floatText(target.x, target.y, '+' + gained, false);
        native.haptic(target.kind === 'gold' ? 'success' : 'light');
        remove(target);
    }

    function expire(target) {
        if (target.dead) { return; }
        /* Only a missed spark breaks the run — an ignored door is the right move. */
        if (target.kind !== 'door' && state.streak > 0) {
            state.streak = 0;
            showCombo();
        }
        remove(target);
    }

    function clearField() {
        state.targets.slice().forEach(function (target) {
            window.clearTimeout(target.expiry);
            target.node.remove();
        });
        state.targets = [];
    }

    /* ---- the round ------------------------------------------------------- */

    function tick() {
        if (!state.running || state.paused) { return; }

        var left = Math.max(0, state.endsAt - Date.now());
        el.timer.textContent = (left / 1000).toFixed(1);
        el.timer.classList.toggle('low', left <= 10000);
        el.barFill.style.transform = 'scaleX(' + (left / config.roundMs) + ')';

        if (left <= 0) { finish(); }
    }

    function startRound() {
        clearField();
        random = makeRandom(config.seed + stats.rounds + state.score);

        state.running = true;
        state.paused = false;
        state.score = 0;
        state.streak = 0;
        state.bestStreak = 0;
        state.caught = 0;
        state.startedAt = Date.now();
        state.endsAt = state.startedAt + config.roundMs;

        el.score.textContent = '0';
        el.startPanel.classList.add('hidden');
        el.endPanel.classList.add('hidden');
        showCombo();

        state.tickTimer = window.setInterval(tick, 66);
        state.spawnTimer = window.setInterval(spawn, config.spawnMs);
        spawn();
        native.send('roundStarted', {});
    }

    function pauseRound() {
        if (state.paused) { return; }
        state.paused = true;
        state.remaining = Math.max(0, state.endsAt - Date.now());
        window.clearInterval(state.spawnTimer);
    }

    function resumeRound() {
        if (!state.paused) { return; }
        state.paused = false;
        state.endsAt = Date.now() + state.remaining;
        state.spawnTimer = window.setInterval(spawn, config.spawnMs);
    }

    function finish() {
        state.running = false;
        window.clearInterval(state.tickTimer);
        window.clearInterval(state.spawnTimer);
        clearField();

        el.timer.textContent = '0.0';
        el.barFill.style.transform = 'scaleX(0)';
        el.combo.classList.add('hidden');

        var beatIt = state.score > stats.best;
        el.endKicker.textContent = beatIt ? 'New best' : 'Time';
        el.endTitle.textContent = beatIt ? 'Best Run Yet' : 'Run Over';
        el.finalScore.textContent = state.score;
        el.endPanel.classList.remove('hidden');
        el.savedNote.textContent = 'Saving…';
        el.savedNote.classList.remove('warn');

        native.haptic(beatIt ? 'success' : 'light');
        native.send('roundFinished', { score: state.score, sparks: state.caught });

        submit();
    }

    /* ---- talking to the server ------------------------------------------- */

    function describe() {
        var parts = ['Best ' + stats.best];
        if (stats.streak > 0) { parts.push(stats.streak + ' day' + (stats.streak === 1 ? '' : 's') + ' in a row'); }
        if (stats.rounds > 0) { parts.push(stats.rounds + ' run' + (stats.rounds === 1 ? '' : 's')); }
        return parts.join(' · ');
    }

    function paintStats() {
        el.startStats.textContent = stats.rounds > 0
            ? describe()
            : 'First run. Your score is kept on this device.';
        el.endStats.textContent = describe();
    }

    function submit() {
        fetch('/app/api/round', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            /* The cookie is the whole identity, so it has to travel. */
            credentials: 'same-origin',
            body: JSON.stringify({
                score: state.score,
                combo: state.bestStreak,
                sparks: state.caught,
                duration_ms: Date.now() - state.startedAt
            })
        }).then(function (response) {
            if (!response.ok) { throw new Error('rejected'); }
            return response.json();
        }).then(function (data) {
            stats.best = data.player.best_score;
            stats.streak = data.player.streak_days;
            stats.rounds = data.player.rounds_played;
            paintStats();
            el.savedNote.textContent = 'Saved. It will still be here next time you open the app.';
        }).catch(function () {
            el.savedNote.textContent = 'Not saved — no connection. The round still counted for you.';
            el.savedNote.classList.add('warn');
        });
    }

    function refresh() {
        fetch('/app/api/state', { credentials: 'same-origin' })
            .then(function (response) { return response.json(); })
            .then(function (data) {
                stats.best = data.player.best_score;
                stats.streak = data.player.streak_days;
                stats.rounds = data.player.rounds_played;
                paintStats();
            })
            .catch(function () { /* The values rendered into the page will do. */ });
    }

    /* ---- wiring ---------------------------------------------------------- */

    el.startButton.addEventListener('click', startRound);
    el.againButton.addEventListener('click', startRound);
    el.closeButton.addEventListener('click', function () { native.send('close', {}); });

    document.addEventListener('visibilitychange', function () {
        if (document.hidden) { pauseRound(); } else if (state.running) { resumeRound(); }
    });

    /* A double tap on a phone zooms unless it is stopped here. */
    document.addEventListener('dblclick', function (event) { event.preventDefault(); }, { passive: false });

    paintStats();
    refresh();
})();
