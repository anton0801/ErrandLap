<?php
/**
 * @var array<string, string> $site
 * @var callable $e
 */
?>
<span class="section-label">Support</span>
<h1>Help With Errand Run</h1>

<p class="lead">Write to a person, not a form. Describe what happened and what you expected —
that is usually enough to find it.</p>

<div class="card">
    <p><strong>Email</strong></p>
    <p><a class="mail" href="mailto:<?= $e($site['support_email']) ?>"><?= $e($site['support_email']) ?></a></p>
    <p>Replies usually take a couple of working days. If it is about signing in, send the email address
    on the account — never send your password, and nobody here will ever ask for it.</p>
</div>

<h2>Things worth trying first</h2>

<h3>My errands are not appearing on my other phone</h3>
<p>Both devices must be signed in to the same account. Open <strong>Settings → Account</strong> and check
the line under “Sync”. It says when the last sync happened, or that the device is offline and how many
changes are waiting. Tap <strong>Sync Now</strong> to run it immediately. Changes made offline are kept
on the phone and sent as soon as there is a connection — nothing is lost in the meantime.</p>

<h3>I cannot sign in</h3>
<p>After several wrong passwords the account locks itself for fifteen minutes; that is deliberate, and it
protects you from someone else guessing. Wait it out and try again. There is no automatic password reset
yet — if you cannot get back in, write to support from the address on the account.</p>

<h3>I do not recognise a device in the list</h3>
<p><strong>Settings → Account → Signed-In Devices</strong> shows every phone signed in, when it was last
used and from which address. Sign out any you do not recognise, then change your password: a password
change ends every other session as well.</p>

<h3>The travel time looks wrong</h3>
<p>It is measured once per pair of points and then kept, so it does not change with traffic. Recalculate
it in <strong>Settings → Travel Times</strong>, or type the number you know is right — a hand-entered time
is used exactly as given. If there is no connection when a place is added, the app says so and lets you
enter the time by hand; nothing is blocked by it.</p>

<h3>A place is always slower than the app expects</h3>
<p>Record how long it actually took when you finish the errand. After two visits the app starts planning
with your own average for that place instead of the estimate. You can see the difference in
<strong>Insights → Estimates vs Reality</strong>.</p>

<h3>I want my data out</h3>
<p><strong>Settings → Data → Export Data</strong> writes your errands and runs out as CSV and a text
summary, which you can send anywhere with the normal share sheet.</p>

<h3>I want the account gone</h3>
<p><strong>Settings → Account → Delete Account</strong>. It asks for your password, then deletes
everything on the server and on this phone. It cannot be undone. What is kept and for how long is set
out on the <a href="/conditions-privacy">privacy page</a>.</p>

<h2>Things the app deliberately will not do</h2>

<div class="card quiet">
    <ul>
        <li><strong>It will not predict a queue.</strong> Nobody can know how long the clinic will take
        today. The app uses your own estimate, then your own measurements, and says which is which.</li>
        <li><strong>It will not track your location.</strong> The map service is used for one thing:
        travel time between two points you entered.</li>
        <li><strong>It will not quietly drop an errand.</strong> Anything that does not fit today moves to
        the next window that works, and the app tells you when that is.</li>
    </ul>
</div>

<h2>Reporting a security problem</h2>

<p>If you have found something that lets one account reach another's data, or anything else that looks
like a security hole, please write to
<a class="mail" href="mailto:<?= $e($site['support_email']) ?>"><?= $e($site['support_email']) ?></a>
with the details before publishing it. Reports are taken seriously and answered.</p>

<h2>When writing in</h2>
<ul>
    <li>The email address on the account.</li>
    <li>What you did, what you expected, what happened instead.</li>
    <li>The iPhone model and iOS version, and the app version from <strong>Settings → About</strong>.</li>
    <li>A screenshot, if there is something to see.</li>
</ul>
