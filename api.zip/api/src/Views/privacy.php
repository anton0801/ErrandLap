<?php
/**
 * The policy describes what the code actually does. Every claim here matches the
 * implementation in src/ — if the implementation changes, this page changes with it.
 *
 * @var array<string, string> $site
 * @var callable $e
 */
?>
<span class="section-label">Conditions &amp; Privacy</span>
<h1>Privacy</h1>
<p class="updated">Last updated: <?= $e($site['privacy_updated']) ?></p>

<p class="lead">Errand Run holds errands, places and opening hours. That is personal in a quiet way —
it says where you go and when you are free — so the rule here is simple: the data is yours, it is
used only to run the app for you, and it is never shared with anyone else.</p>

<?php if (!$site['connected']): ?>
<div class="card gold">
    <p><strong>The current version of the app keeps everything on your phone.</strong> There is no
    account, no sign-up and no sync. Nothing you enter is sent to us, and there is nothing on our
    side to look at, because none of it ever leaves the device.</p>
    <p>The rest of this page describes exactly what that means, and what the app does and does not
    ask of your phone.</p>
</div>
<?php endif; ?>

<div class="card">
    <p><strong>No advertising. No analytics. No trackers. No profiling. Nothing sold or shared
    with third parties, ever.</strong> There is no advertising identifier, no third-party SDK and no
    tracking pixel anywhere in the app or on this site.</p>
</div>

<h2>Who is responsible</h2>

<p><?= $e($site['owner']) ?> runs this service and decides how the data described below is handled. Questions, requests and complaints:
<a class="mail" href="mailto:<?= $e($site['support_email']) ?>"><?= $e($site['support_email']) ?></a>.</p>

<h2>What is stored</h2>

<?php if ($site['connected']): ?>
<h3>Your account</h3>
<ul>
    <li><strong>Email address</strong> — it identifies the account and is the only way to sign in.</li>
    <li><strong>Password</strong> — never stored. Only an Argon2id hash of it is kept, which cannot be
    turned back into your password.</li>
    <li><strong>Display name</strong>, if you enter one.</li>
    <li>The dates the account was created and the password was last changed.</li>
</ul>
<?php endif; ?>

<h3>What you put into the app<?= $site['connected'] ? '' : ', kept on your phone' ?></h3>
<ul>
    <li><strong>Errands</strong>: title, category, how long you expect them to take, deadline, priority,
    documents to bring, notes, shopping items, who a task is delegated to.</li>
    <li><strong>Places</strong>: name, address, opening hours, lunch breaks, last entry time, parking
    difficulty, your queue estimate and notes. If an address was located on the map, its coordinates.</li>
    <li><strong>Free windows</strong>: days and times you are available, and the points a window starts
    and ends at.</li>
    <li><strong>Runs</strong>: the routes that were planned and how they went.</li>
    <li><strong>Measured visits</strong>: how long a visit was expected to take and how long it took.</li>
    <li><strong>Wasted trips</strong>: the place, the date and why the trip was for nothing.</li>
    <li><strong>Travel times</strong> between your points, and your settings: home and work address,
    travel mode, walking pace, buffer, reminder preferences.</li>
</ul>

<div class="card gold">
    <p><strong>Photos stay on your phone.</strong> A photo attached to a place is stored on the device
    only. It is never uploaded, and it does not appear on another device.</p>
</div>

<?php if ($site['connected']): ?>
<h3>Records kept for security</h3>
<ul>
    <li><strong>Signed-in devices</strong>: the device name the phone reports, the IP address and browser
    or app identifier of the last request, and when the session was created and last used. This is what
    the “Signed-In Devices” list in the app shows, so you can end a session you do not recognise.</li>
    <li><strong>Account events</strong>: sign-in, sign-out, password change, account deletion and failed
    attempts, with the time, the IP address and the app identifier. The email address in this log is
    stored only as a hash, so the record survives account deletion without keeping your address.</li>
</ul>

<p>These records exist to stop someone else getting into your account and to let you see where it is
signed in. They are not used for anything else.</p>
<?php endif; ?>

<?php if ($site['connected']): ?>
<h2>The mini-game and its cookie</h2>

<p>Errand Run includes a small seasonal game that opens inside the app as a web page. It keeps
a score, and to remember whose score it is, the server sets <strong>one cookie</strong> on your
device.</p>

<div class="card">
    <ul>
        <li>The cookie holds a random value and nothing else — no name, no email, no account.</li>
        <li>The server stores only a hash of that value, together with your best score, how many
        rounds you have played and how many days in a row.</li>
        <li>It is <strong>not linked to your account</strong>. The game cannot see your errands,
        and your errands do not know the game exists.</li>
        <li>It is a first-party cookie used only to keep your score. It is not an advertising or
        tracking cookie, and it is not shared with anyone.</li>
        <li>It lasts two years and refreshes while you keep playing. Clearing it simply starts a
        new score; a player who never plays a round is deleted after 30 days.</li>
    </ul>
</div>

<?php endif; ?>

<h2>What is never collected</h2>
<ul>
    <li>Your location is never tracked. The app has no background location access and does not follow
    your movements.</li>
    <li>Your contacts, calendar, photo library and files are never read or uploaded.</li>
    <li>No behavioural analytics, no usage statistics, no crash reporting to a third party.</li>
    <li>No payment details of any kind.</li>
</ul>

<h2>The map service</h2>

<p>To turn an address into a point on a map and to work out the real travel time between two stops,
the app asks the map service built into your phone. That request is made <strong>by your device</strong>
and is handled under Apple's privacy policy, not this one. It happens once per address, the answer is
stored so the same question is not asked twice, and you can enter travel times by hand instead —
everything else in the app works without it.</p>

<?php if ($site['connected']): ?>
<h2>Where it is stored, and for how long</h2>

<p>Your data is stored on the server that runs this service<?= $site['region'] !== '' ? ' (' . $e($site['region']) . ')' : '' ?>,
in a database that is not readable from the internet, and is transferred only over an encrypted HTTPS
connection.</p>

<table>
    <tr><th>Data</th><th>Kept</th></tr>
    <tr><td>Account and everything you put into the app</td><td>Until you delete it, or delete the account</td></tr>
    <tr><td>Record of a deleted item</td><td>90 days, so your other devices learn about the deletion, then removed</td></tr>
    <tr><td>Signed-in device sessions</td><td>Until signed out; automatically 30 days after last use</td></tr>
    <tr><td>Account event log</td><td>Kept for security, with the email address stored only as a hash</td></tr>
</table>

<h2>Deleting your account</h2>

<div class="card">
    <p>In the app: <strong>Settings → Account → Delete Account</strong>. It asks for your password and a
    confirmation, because it cannot be undone.</p>
    <p>When you confirm, every session is ended and every row belonging to the account — errands, places,
    windows, runs, visits, wasted trips, travel times and settings — is deleted from the database
    immediately, not marked for later. The local copy on the phone is removed at the same time. What
    remains is a line in the security log recording that an account was deleted, containing a hash of the
    email address and no readable personal data.</p>
</div>

<?php else: ?>
<h2>Where it is stored, and for how long</h2>

<p>On your phone, in the app's own storage, and nowhere else. It stays until you delete it. There is
no copy on a server, so there is nothing for us to keep, hand over or lose.</p>

<div class="card">
    <p><strong>Deleting it.</strong> Any single errand, place or window can be deleted in the app.
    <strong>Settings → Data → Delete All App Data</strong> removes everything at once. Deleting the
    app from the phone removes it too — so export first if you want to keep it:
    <strong>Settings → Data → Export Data</strong> writes it out as CSV and a text summary.</p>
</div>

<h2>How the data is protected</h2>
<ul>
    <li>It never leaves the device, which removes most of the ways data goes missing.</li>
    <li>It sits in the app's own container, which iOS keeps separate from other apps.</li>
    <li>It is covered by your phone's own encryption while the device is locked.</li>
    <li>Reminders are scheduled locally by iOS. Their text never leaves the phone.</li>
</ul>
<?php endif; ?>

<?php if ($site['connected']): ?>
<h2>How the data is protected</h2>
<ul>
    <li>Everything travels over HTTPS. The app refuses a connection it cannot verify.</li>
    <li>Passwords are hashed with Argon2id — a slow, memory-hard algorithm chosen to make guessing expensive.</li>
    <li>Access tokens are stored on the phone in the Keychain, and on the server only as hashes.
    A stolen copy of the database contains no usable session.</li>
    <li>A token is short-lived and rotates. If an old one is replayed, that session is ended automatically.</li>
    <li>Every request is checked against the account it belongs to, and the database is arranged so that
    one account physically cannot read another's rows.</li>
    <li>Repeated failed sign-ins are throttled and then locked out for a while.</li>
</ul>
<?php endif; ?>

<h2>Your rights</h2>
<ul>
    <li><strong>See your data</strong> — it is all visible in the app; Settings → Data → Export Data writes
    it out as CSV and a text summary.</li>
    <li><strong>Correct it</strong> — every field is editable in the app.</li>
    <li><strong>Delete it</strong> — <?= $site['connected'] ? 'individual items, or the whole account, at any time, without asking anyone.' : 'individual items, or everything at once, at any time, on the device itself. No request to us is needed, and none is possible.' ?></li>
    <li><strong>Ask a question or object</strong> — write to
    <a class="mail" href="mailto:<?= $e($site['support_email']) ?>"><?= $e($site['support_email']) ?></a>.
    Requests are answered as soon as they can be.</li>
</ul>

<h2>Children</h2>

<p>Errand Run is a planning tool for adults running household errands. It is not directed at children
and is not designed to collect anything from them.</p>

<h2>Changes to this page</h2>

<p>If what the app stores changes, this page changes with it and the date at the top moves. Material
changes are shown in the app before they take effect.</p>

<h2>Contact</h2>

<p><a class="mail" href="mailto:<?= $e($site['support_email']) ?>"><?= $e($site['support_email']) ?></a></p>
