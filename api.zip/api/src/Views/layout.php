<?php
/**
 * Shared frame for the public pages.
 *
 * The palette and shapes follow the app: warm cream, charcoal, the fire gradient
 * on headings and buttons, a hard un-blurred shadow, a slanted left edge. The
 * slant stays on small decorative elements — a page of body text set in skewed
 * boxes is harder to read, and this page exists to be read.
 *
 * @var string $title
 * @var string $description
 * @var string $content
 * @var string $activePage
 * @var array<string, string> $site
 */

$e = static fn (?string $value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
$nav = [
    '/'                   => 'Home',
    '/support'            => 'Support',
    '/conditions-privacy' => 'Privacy',
];
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title><?= $e($title) ?></title>
<meta name="description" content="<?= $e($description) ?>">
<!-- Same policy the server sends. Repeated here because a CDN in front of the
     site may replace the header, and this copy travels inside the page. -->
<meta http-equiv="Content-Security-Policy"
      content="default-src 'none'; style-src 'unsafe-inline'; img-src 'self' data:; font-src data:; base-uri 'none'; form-action 'none'">
<meta name="color-scheme" content="light dark">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<style>
:root {
    --cream:    #FFF0D6;
    --card:     #FFFAEC;
    --charcoal: #171316;
    --cherry:   #3A0B12;
    --scarlet:  #FF3426;
    --orange:   #FF7A18;
    --gold:     #FFD24A;
    --ink:      #171316;
    --muted:    rgba(23, 19, 22, 0.72);
    --line:     rgba(23, 19, 22, 0.14);
}

@media (prefers-color-scheme: dark) {
    :root {
        --cream:  #3A0B12;
        --card:   #4A1219;
        --ink:    #FFF0D6;
        --muted:  rgba(255, 240, 214, 0.78);
        --line:   rgba(255, 240, 214, 0.18);
        --charcoal: #FFF0D6;
    }
}

* { box-sizing: border-box; }

html { -webkit-text-size-adjust: 100%; }

body {
    margin: 0;
    background: var(--cream);
    color: var(--ink);
    font: 400 17px/1.62 -apple-system, BlinkMacSystemFont, "SF Pro Text", "Segoe UI", Roboto, Helvetica, Arial, sans-serif;
    padding: 0 20px 80px;
}

.wrap { max-width: 780px; margin: 0 auto; }

/* ---- header ---------------------------------------------------------- */

header.top {
    display: flex;
    flex-wrap: wrap;
    gap: 14px 22px;
    align-items: center;
    justify-content: space-between;
    padding: 26px 0 30px;
    border-bottom: 2.5px solid var(--charcoal);
    margin-bottom: 34px;
}

.brand {
    font: italic 900 21px/1 -apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif;
    letter-spacing: -0.3px;
    text-transform: uppercase;
    text-decoration: none;
    background: linear-gradient(120deg, var(--scarlet), var(--orange) 52%, var(--gold));
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
}

nav.top-nav { display: flex; gap: 8px; flex-wrap: wrap; }

nav.top-nav a {
    display: inline-block;
    padding: 8px 15px;
    font: italic 900 11px/1 -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif;
    letter-spacing: 1px;
    text-transform: uppercase;
    text-decoration: none;
    color: var(--ink);
    border: 2px solid var(--charcoal);
    border-radius: 9px;
    transform: skewX(-8deg);
}

nav.top-nav a span { display: block; transform: skewX(8deg); }

nav.top-nav a.current {
    background: linear-gradient(120deg, var(--scarlet), var(--orange) 52%, var(--gold));
    color: var(--cherry);
    border-color: var(--charcoal);
}

/* ---- type ------------------------------------------------------------ */

h1 {
    font: italic 900 clamp(32px, 8vw, 46px)/1.03 -apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif;
    letter-spacing: -0.5px;
    text-transform: uppercase;
    margin: 0 0 18px;
    background: linear-gradient(120deg, var(--scarlet), var(--orange) 52%, var(--gold));
    -webkit-background-clip: text;
    background-clip: text;
    color: transparent;
}

h2 {
    font: italic 900 clamp(21px, 5vw, 25px)/1.2 -apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif;
    letter-spacing: -0.2px;
    margin: 44px 0 14px;
    color: var(--ink);
}

h3 {
    font: 700 18px/1.35 -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif;
    margin: 26px 0 8px;
    color: var(--ink);
}

p { margin: 0 0 15px; color: var(--muted); }
p.lead { font-size: 20px; color: var(--ink); }
strong { color: var(--ink); font-weight: 650; }

a { color: var(--ink); text-decoration-color: var(--orange); text-underline-offset: 3px; }
a:hover { text-decoration-color: var(--scarlet); }

ul { margin: 0 0 16px; padding-left: 0; list-style: none; }
li { position: relative; padding-left: 22px; margin-bottom: 9px; color: var(--muted); }
li::before {
    content: "";
    position: absolute;
    left: 2px; top: 10px;
    width: 8px; height: 8px;
    background: linear-gradient(120deg, var(--scarlet), var(--gold));
    transform: rotate(45deg);
}

.section-label {
    display: inline-block;
    font: italic 900 12px/1 -apple-system, BlinkMacSystemFont, "SF Pro Text", sans-serif;
    letter-spacing: 1.2px;
    text-transform: uppercase;
    color: var(--muted);
    margin-bottom: 10px;
}

/* ---- cards ----------------------------------------------------------- */

.card {
    position: relative;
    background: var(--card);
    border: 2.5px solid var(--charcoal);
    border-radius: 12px;
    padding: 22px 22px 22px 32px;
    margin: 0 0 18px;
    box-shadow: 4px 4px 0 var(--cherry);
    overflow: hidden;
}

@media (prefers-color-scheme: dark) {
    .card { box-shadow: 4px 4px 0 rgba(0, 0, 0, 0.5); }
}

/* The status stripe from the app's cards, with the same slant. */
.card::before {
    content: "";
    position: absolute;
    left: -3px; top: -8px; bottom: -8px;
    width: 14px;
    background: linear-gradient(180deg, var(--scarlet), var(--orange) 55%, var(--gold));
    transform: skewX(-8deg);
    transform-origin: top left;
}

.card.gold::before { background: var(--gold); }
.card.quiet::before { background: var(--line); }
.card p:last-child, .card ul:last-child, .card li:last-child { margin-bottom: 0; }
.card h3 { margin-top: 0; }

.hero-note {
    font: 700 16px/1.5 ui-monospace, SFMono-Regular, Menlo, monospace;
    color: var(--ink);
}

/* ---- buttons --------------------------------------------------------- */

.actions { display: flex; flex-wrap: wrap; gap: 12px; margin: 26px 0 8px; }

.btn {
    display: inline-block;
    padding: 17px 26px;
    font: italic 900 17px/1 -apple-system, BlinkMacSystemFont, "SF Pro Display", sans-serif;
    letter-spacing: 0.2px;
    text-transform: uppercase;
    text-decoration: none;
    border-radius: 12px;
    border: 2.5px solid var(--charcoal);
    transform: skewX(-8deg);
    box-shadow: 4px 4px 0 var(--cherry);
}

.btn span { display: block; transform: skewX(8deg); }
.btn.fire { background: linear-gradient(120deg, var(--scarlet), var(--orange) 52%, var(--gold)); color: var(--cherry); }
.btn.ghost { background: transparent; color: var(--ink); }

@media (prefers-color-scheme: dark) {
    .btn { box-shadow: 4px 4px 0 rgba(0, 0, 0, 0.5); }
}

/* ---- misc ------------------------------------------------------------ */

.updated {
    font: 600 13px/1.4 -apple-system, BlinkMacSystemFont, sans-serif;
    color: var(--muted);
    margin: -6px 0 26px;
}

table { width: 100%; border-collapse: collapse; margin: 0 0 20px; font-size: 15px; }
th, td { text-align: left; padding: 11px 12px; border-bottom: 1.5px solid var(--line); vertical-align: top; }
th { font: italic 900 11px/1.3 -apple-system, sans-serif; letter-spacing: 1px; text-transform: uppercase; color: var(--ink); }
td { color: var(--muted); }

.mail {
    font: 700 17px/1.4 ui-monospace, SFMono-Regular, Menlo, monospace;
    word-break: break-all;
}

footer.bottom {
    margin-top: 60px;
    padding-top: 26px;
    border-top: 2.5px solid var(--charcoal);
    display: flex;
    flex-wrap: wrap;
    gap: 10px 20px;
    justify-content: space-between;
    align-items: center;
    font-size: 14px;
    color: var(--muted);
}

footer.bottom a { color: var(--muted); }

@media (max-width: 560px) {
    body { padding: 0 16px 60px; }
    .card { padding: 18px 18px 18px 26px; }
    .btn { width: 100%; text-align: center; }
}
</style>
</head>
<body>
<div class="wrap">

<header class="top">
    <a class="brand" href="/">Errand Run</a>
    <nav class="top-nav">
        <?php foreach ($nav as $href => $label): ?>
            <a href="<?= $e($href) ?>"<?= $activePage === $href ? ' class="current"' : '' ?>><span><?= $e($label) ?></span></a>
        <?php endforeach; ?>
    </nav>
</header>

<main>
<?= $content ?>
</main>

<footer class="bottom">
    <span>© <?= $e((string) date('Y')) ?> <?= $e($site['owner']) ?></span>
    <span>
        <a href="/conditions-privacy">Privacy</a> ·
        <a href="/support">Support</a> ·
        <a href="mailto:<?= $e($site['support_email']) ?>"><?= $e($site['support_email']) ?></a>
    </span>
</footer>

</div>
</body>
</html>
