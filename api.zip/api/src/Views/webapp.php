<?php
/**
 * The WebView page. No inline script and no inline style — everything is loaded
 * from /app/spark.css and /app/spark.js, so the policy on this page can stay
 * strict. The starting values are handed to the script through data attributes
 * rather than a script block, for the same reason.
 *
 * @var array<string, mixed> $season
 * @var array<string, mixed> $stats
 */

$e = static fn (mixed $value): string => htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
?><!doctype html>
<html lang="en">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover, user-scalable=no">
<meta name="color-scheme" content="dark">
<title><?= $e($season['name']) ?> — Errand Run</title>
<!-- Kept in step with the header the server sends; a CDN cannot strip this copy. -->
<meta http-equiv="Content-Security-Policy"
      content="default-src 'none'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; base-uri 'none'; form-action 'none'">
<link rel="icon" href="/favicon.svg" type="image/svg+xml">
<link rel="stylesheet" href="/app/spark.css">
</head>
<body
    data-season="<?= $e($season['key']) ?>"
    data-seed="<?= $e($season['seed']) ?>"
    data-spawn="<?= $e($season['spawn']) ?>"
    data-fade="<?= $e($season['fade']) ?>"
    data-door="<?= $e($season['door']) ?>"
    data-gold="<?= $e($season['gold']) ?>"
    data-round="<?= $e($season['round_ms']) ?>"
    data-best="<?= $e($stats['best_score']) ?>"
    data-streak="<?= $e($stats['streak_days']) ?>"
    data-rounds="<?= $e($stats['rounds_played']) ?>"
    data-visits="<?= $e($stats['visits']) ?>">

<div class="frame">

    <header class="hud">
        <div class="hud-left">
            <span class="season"><?= $e($season['name']) ?></span>
            <span class="timer" id="timer">45.0</span>
        </div>
        <div class="hud-right">
            <span class="label">Score</span>
            <span class="score" id="score">0</span>
        </div>
    </header>

    <div class="bar"><i id="bar-fill"></i></div>

    <main class="field" id="field">
        <div class="ribbon" aria-hidden="true"></div>

        <section class="panel" id="start-panel">
            <span class="kicker"><?= $e($season['day']) ?></span>
            <h1><?= $e($season['name']) ?></h1>
            <p class="tagline"><?= $e($season['tagline']) ?></p>

            <ul class="rules">
                <li><b>Tap the sparks</b> before they burn out.</li>
                <li><b>Gold ones</b> are the last entry before closing — worth more, gone sooner.</li>
                <li><b>Closed doors</b> cost you three seconds. Leave them alone.</li>
                <li>Hit them in a row and the multiplier climbs to ×5.</li>
            </ul>

            <button class="btn fire" id="start-button" type="button"><span>Start the Run</span></button>

            <p class="stats" id="start-stats"></p>
        </section>

        <section class="panel hidden" id="end-panel">
            <span class="kicker" id="end-kicker">Time</span>
            <h1 id="end-title">Run Over</h1>
            <div class="final" id="final-score">0</div>
            <p class="stats" id="end-stats"></p>
            <p class="saved" id="saved-note"></p>

            <button class="btn fire" id="again-button" type="button"><span>Run Again</span></button>
            <button class="btn ghost hidden" id="close-button" type="button"><span>Close</span></button>
        </section>
    </main>

    <footer class="foot">
        <span id="combo-pill" class="combo hidden">×1</span>
        <span class="mark">Errand Run</span>
    </footer>

</div>

<script src="/app/spark.js" defer></script>
</body>
</html>
