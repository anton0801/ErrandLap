<?php
/**
 * @var array<string, string> $site
 * @var callable $e
 */
?>
<span class="section-label">Errands · iPhone</span>
<h1>What Can I Actually<br>Finish Today?</h1>

<p class="lead">A list of errands does not know that the post office closes at two, and that it is
twenty minutes away. Errand Run does.</p>

<p>You give it your free window — say, between leaving work and picking up a child — and the
errands you are carrying around. It takes the opening hours of every place, the lunch breaks, the
last-entry time, the real travel between the stops and a buffer for parking, and builds the route
that fits. What does not fit is not thrown away: it goes to the next window that works, and the
app tells you when that is.</p>

<div class="actions">
    <?php if ($site['app_store'] !== ''): ?>
        <a class="btn fire" href="<?= $e($site['app_store']) ?>"><span>Get the App</span></a>
    <?php endif; ?>
    <a class="btn ghost" href="/support"><span>Support</span></a>
</div>

<h2>The Route Explains Itself</h2>

<div class="card">
    <p class="hero-note">
        Window: 13:10 to 14:40. 90 minutes.<br>
        Pharmacy: 8 min drive, 6 min inside, closes 20:00. <strong>Fits.</strong><br>
        Post office: 11 min drive, 15 min inside, last entry 13:45.<br>
        You arrive 13:35. <strong>Tight but fits.</strong><br>
        Bank: would land at 14:20, school at 14:40. <strong>Does not fit.</strong>
    </p>
</div>

<p>The order is decided by doors, not by importance: what closes earliest goes first, even when it
matters less. Move a stop by hand and the app says immediately what it costs — “moving the post
office after the bank means you arrive at 14:05, and it closes at 14:00.”</p>

<h2>Honest About Queues</h2>

<div class="card gold">
    <p>The app never promises that the clinic will take fifteen minutes. Nobody can know that.</p>
    <p>It asks for <strong>your</strong> estimate, records how long the visit actually took, and after a
    few visits it plans with your own average for that place instead of your hopes. It never shows
    anyone else's statistics and never pretends to know how busy a counter is right now.</p>
</div>

<h2>What It Keeps for You</h2>

<ul>
    <li><strong>Places</strong> with opening hours, lunch breaks, last entry, parking difficulty and notes.</li>
    <li><strong>Free windows</strong> that start and end at real points — left work, must be at the school.</li>
    <li><strong>Measured times</strong>: how long that clinic, that post office, that service centre really takes.</li>
    <li><strong>Wasted trips</strong>: arrived and it was closed, the terminal was broken, a document was missing. The place card learns from it.</li>
    <li><strong>Deadlines counted in windows</strong>, not in days: “three windows left where the office is open” is the number that matters.</li>
</ul>

<h2>Your Account, Your Data</h2>

<p>An account exists for one reason: so a new phone finds your errands, places and measured times.
Nothing is shared between accounts, nothing is sold, there is no advertising and no analytics.
Deleting the account deletes the data — see the <a href="/conditions-privacy">privacy page</a> for
exactly what is stored and for how long.</p>

<p>The app keeps working without a connection. Edits are made on the phone first and go up when
there is a network again.</p>
