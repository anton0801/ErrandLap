<?php

declare(strict_types=1);

namespace ErrandRun\Security;

use ErrandRun\Core\Clock;
use ErrandRun\Core\Database;
use ErrandRun\Core\Request;

/**
 * Security trail for anything that touches an account. Emails are stored hashed
 * so the log stays useful after an account is deleted without keeping personal
 * data around.
 */
final class AuditLog
{
    public const REGISTER        = 'register';
    public const LOGIN           = 'login';
    public const REFRESH         = 'refresh';
    public const LOGOUT          = 'logout';
    public const LOGOUT_ALL      = 'logout_all';
    public const PASSWORD_CHANGE = 'password_change';
    public const PROFILE_UPDATE  = 'profile_update';
    public const ACCOUNT_DELETE  = 'account_delete';
    public const SESSION_REVOKE  = 'session_revoke';
    public const TOKEN_REUSE     = 'token_reuse';

    /** @param array<string, mixed> $meta */
    public static function record(
        string $event,
        string $outcome,
        Request $request,
        ?string $userId = null,
        ?string $email = null,
        array $meta = [],
    ): void {
        try {
            Database::run(
                'INSERT INTO auth_events (user_id, email_hash, event, outcome, ip_address, user_agent, meta, created_at)
                 VALUES (:user_id, :email_hash, :event, :outcome, :ip, :ua, :meta, :created)',
                [
                    'user_id'    => $userId,
                    'email_hash' => $email === null ? null : hash('sha256', mb_strtolower($email)),
                    'event'      => mb_substr($event, 0, 40),
                    'outcome'    => mb_substr($outcome, 0, 20),
                    'ip'         => $request->ipBinary(),
                    'ua'         => $request->userAgent,
                    'meta'       => $meta === [] ? null : json_encode($meta, JSON_UNESCAPED_UNICODE),
                    'created'    => Clock::sql(),
                ],
            );
        } catch (\Throwable) {
            // Logging must never break the request it is describing.
        }
    }
}
