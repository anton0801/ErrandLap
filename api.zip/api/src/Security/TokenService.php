<?php

declare(strict_types=1);

namespace ErrandRun\Security;

use ErrandRun\Core\ApiException;
use ErrandRun\Core\Clock;
use ErrandRun\Core\Config;
use ErrandRun\Core\Database;
use ErrandRun\Core\Request;

/**
 * Opaque bearer tokens.
 *
 * The server never stores a token, only its SHA-256 hash — a database dump does
 * not hand anyone a working session. Access tokens are short-lived; refresh
 * tokens rotate on every use and a replay of an already-rotated refresh token
 * kills the session it came from.
 */
final class TokenService
{
    public const ACCESS_PREFIX  = 'era_';
    public const REFRESH_PREFIX = 'err_';

    public static function accessTtl(): int
    {
        return Config::int('ACCESS_TOKEN_TTL', 3600);
    }

    public static function refreshTtl(): int
    {
        return Config::int('REFRESH_TOKEN_TTL', 2_592_000);
    }

    private static function randomToken(string $prefix): string
    {
        return $prefix . rtrim(strtr(base64_encode(random_bytes(32)), '+/', '-_'), '=');
    }

    public static function hashToken(string $token): string
    {
        return hash('sha256', $token);
    }

    /**
     * @return array{session_id: string, access_token: string, refresh_token: string,
     *               access_expires_at: string, refresh_expires_at: string}
     */
    public static function issue(string $userId, string $deviceName, Request $request): array
    {
        $now = Clock::now();
        $sessionId = self::uuid();
        $access = self::randomToken(self::ACCESS_PREFIX);
        $refresh = self::randomToken(self::REFRESH_PREFIX);
        $accessExpires = Clock::plusSeconds(self::accessTtl(), $now);
        $refreshExpires = Clock::plusSeconds(self::refreshTtl(), $now);

        Database::run(
            'INSERT INTO sessions (id, user_id, access_token_hash, access_expires_at, refresh_token_hash,
                                   refresh_expires_at, device_name, ip_address, user_agent, created_at, last_used_at)
             VALUES (:id, :user_id, :access_hash, :access_expires, :refresh_hash, :refresh_expires,
                     :device, :ip, :ua, :created, :used)',
            [
                'id'              => $sessionId,
                'user_id'         => $userId,
                'access_hash'     => self::hashToken($access),
                'access_expires'  => Clock::sql($accessExpires),
                'refresh_hash'    => self::hashToken($refresh),
                'refresh_expires' => Clock::sql($refreshExpires),
                'device'          => mb_substr($deviceName, 0, 120),
                'ip'              => $request->ipBinary(),
                'ua'              => $request->userAgent,
                'created'         => Clock::sql($now),
                'used'            => Clock::sql($now),
            ],
        );

        self::pruneSessions($userId);

        return [
            'session_id'         => $sessionId,
            'access_token'       => $access,
            'refresh_token'      => $refresh,
            'access_expires_at'  => Clock::iso($accessExpires),
            'refresh_expires_at' => Clock::iso($refreshExpires),
        ];
    }

    /**
     * Resolves a bearer access token to its user and session.
     *
     * @return array{user: array<string, mixed>, session: array<string, mixed>}
     */
    public static function authenticate(string $token): array
    {
        if (!str_starts_with($token, self::ACCESS_PREFIX) || strlen($token) > 128) {
            throw ApiException::unauthorized('The access token is not valid.', 'invalid_token');
        }

        $row = Database::first(
            'SELECT s.id AS session_id, s.user_id, s.access_expires_at, s.revoked_at,
                    u.id AS uid, u.email, u.display_name, u.created_at AS user_created_at,
                    u.password_changed_at, u.email_verified_at
               FROM sessions s
               INNER JOIN users u ON u.id = s.user_id
              WHERE s.access_token_hash = :hash
              LIMIT 1',
            ['hash' => self::hashToken($token)],
        );

        if ($row === null) {
            throw ApiException::unauthorized('The access token is not valid.', 'invalid_token');
        }
        if ($row['revoked_at'] !== null) {
            throw ApiException::unauthorized('This session has been signed out.', 'session_revoked');
        }

        $expires = Clock::fromSql((string) $row['access_expires_at']);
        if ($expires === null || $expires <= Clock::now()) {
            throw ApiException::unauthorized('The access token has expired.', 'token_expired');
        }

        Database::run(
            'UPDATE sessions SET last_used_at = :now WHERE id = :id',
            ['now' => Clock::sql(), 'id' => $row['session_id']],
        );

        return [
            'user' => [
                'id'                  => (string) $row['uid'],
                'email'               => (string) $row['email'],
                'display_name'        => (string) $row['display_name'],
                'created_at'          => (string) $row['user_created_at'],
                'password_changed_at' => (string) $row['password_changed_at'],
                'email_verified_at'   => $row['email_verified_at'],
            ],
            'session' => [
                'id'      => (string) $row['session_id'],
                'user_id' => (string) $row['user_id'],
            ],
        ];
    }

    /**
     * Exchanges a refresh token for a fresh pair, rotating both.
     *
     * @return array{user_id: string, session_id: string, access_token: string, refresh_token: string,
     *               access_expires_at: string, refresh_expires_at: string}
     */
    public static function rotate(string $refreshToken, Request $request): array
    {
        if (!str_starts_with($refreshToken, self::REFRESH_PREFIX) || strlen($refreshToken) > 128) {
            throw ApiException::unauthorized('The refresh token is not valid.', 'invalid_token');
        }

        $hash = self::hashToken($refreshToken);

        // Replay of a token that was already rotated away means it leaked.
        $replayed = Database::first(
            'SELECT id, user_id FROM sessions WHERE previous_refresh_hash = :hash LIMIT 1',
            ['hash' => $hash],
        );
        if ($replayed !== null) {
            self::revokeSession((string) $replayed['id'], 'refresh_reuse');
            throw ApiException::unauthorized(
                'This refresh token was already used. The session has been signed out for safety.',
                'refresh_reuse',
            );
        }

        $session = Database::first(
            'SELECT id, user_id, refresh_expires_at, revoked_at FROM sessions WHERE refresh_token_hash = :hash LIMIT 1',
            ['hash' => $hash],
        );
        if ($session === null) {
            throw ApiException::unauthorized('The refresh token is not valid.', 'invalid_token');
        }
        if ($session['revoked_at'] !== null) {
            throw ApiException::unauthorized('This session has been signed out.', 'session_revoked');
        }
        $expires = Clock::fromSql((string) $session['refresh_expires_at']);
        if ($expires === null || $expires <= Clock::now()) {
            throw ApiException::unauthorized('The refresh token has expired. Sign in again.', 'token_expired');
        }

        $now = Clock::now();
        $access = self::randomToken(self::ACCESS_PREFIX);
        $newRefresh = self::randomToken(self::REFRESH_PREFIX);
        $accessExpires = Clock::plusSeconds(self::accessTtl(), $now);
        $refreshExpires = Clock::plusSeconds(self::refreshTtl(), $now);

        Database::run(
            'UPDATE sessions
                SET access_token_hash = :access_hash,
                    access_expires_at = :access_expires,
                    previous_refresh_hash = refresh_token_hash,
                    refresh_token_hash = :refresh_hash,
                    refresh_expires_at = :refresh_expires,
                    ip_address = :ip,
                    user_agent = :ua,
                    last_used_at = :now
              WHERE id = :id AND revoked_at IS NULL',
            [
                'access_hash'     => self::hashToken($access),
                'access_expires'  => Clock::sql($accessExpires),
                'refresh_hash'    => self::hashToken($newRefresh),
                'refresh_expires' => Clock::sql($refreshExpires),
                'ip'              => $request->ipBinary(),
                'ua'              => $request->userAgent,
                'now'             => Clock::sql($now),
                'id'              => $session['id'],
            ],
        );

        return [
            'user_id'            => (string) $session['user_id'],
            'session_id'         => (string) $session['id'],
            'access_token'       => $access,
            'refresh_token'      => $newRefresh,
            'access_expires_at'  => Clock::iso($accessExpires),
            'refresh_expires_at' => Clock::iso($refreshExpires),
        ];
    }

    public static function revokeSession(string $sessionId, string $reason): void
    {
        Database::run(
            'UPDATE sessions
                SET revoked_at = :now, revoked_reason = :reason,
                    access_token_hash = NULL, previous_refresh_hash = NULL,
                    refresh_token_hash = CONCAT(\'revoked:\', id)
              WHERE id = :id AND revoked_at IS NULL',
            ['now' => Clock::sql(), 'reason' => $reason, 'id' => $sessionId],
        );
    }

    public static function revokeAllForUser(string $userId, string $reason, ?string $exceptSessionId = null): int
    {
        $sql = 'UPDATE sessions
                   SET revoked_at = :now, revoked_reason = :reason,
                       access_token_hash = NULL, previous_refresh_hash = NULL,
                       refresh_token_hash = CONCAT(\'revoked:\', id)
                 WHERE user_id = :user_id AND revoked_at IS NULL';
        $params = ['now' => Clock::sql(), 'reason' => $reason, 'user_id' => $userId];

        if ($exceptSessionId !== null) {
            $sql .= ' AND id <> :except';
            $params['except'] = $exceptSessionId;
        }

        return Database::run($sql, $params)->rowCount();
    }

    /** @return list<array<string, mixed>> */
    public static function listSessions(string $userId, string $currentSessionId): array
    {
        $rows = Database::all(
            'SELECT id, device_name, user_agent, ip_address, created_at, last_used_at, refresh_expires_at
               FROM sessions
              WHERE user_id = :user_id AND revoked_at IS NULL AND refresh_expires_at > :now
              ORDER BY last_used_at DESC
              LIMIT 100',
            ['user_id' => $userId, 'now' => Clock::sql()],
        );

        return array_map(static function (array $row) use ($currentSessionId): array {
            $ip = $row['ip_address'];
            return [
                'id'           => (string) $row['id'],
                'device_name'  => (string) $row['device_name'],
                'user_agent'   => (string) $row['user_agent'],
                'ip_address'   => is_string($ip) && $ip !== '' ? (@inet_ntop($ip) ?: null) : null,
                'created_at'   => Clock::isoFromSql((string) $row['created_at']),
                'last_used_at' => Clock::isoFromSql((string) $row['last_used_at']),
                'expires_at'   => Clock::isoFromSql((string) $row['refresh_expires_at']),
                'current'      => (string) $row['id'] === $currentSessionId,
            ];
        }, $rows);
    }

    /** Keeps the session table from growing without bound. */
    private static function pruneSessions(string $userId): void
    {
        $cutoff = Clock::sql(Clock::plusSeconds(-604800));
        Database::run(
            'DELETE FROM sessions
              WHERE user_id = :user_id
                AND (refresh_expires_at < :cutoff_expiry OR (revoked_at IS NOT NULL AND revoked_at < :cutoff_revoked))',
            ['user_id' => $userId, 'cutoff_expiry' => $cutoff, 'cutoff_revoked' => $cutoff],
        );

        // LIMIT/OFFSET cannot take bound parameters here, so the value is forced to an int.
        $max = max(1, Config::int('MAX_SESSIONS_PER_USER', 10));
        $extra = Database::all(
            sprintf(
                'SELECT id FROM sessions
                  WHERE user_id = :user_id AND revoked_at IS NULL
                  ORDER BY last_used_at DESC
                  LIMIT 500 OFFSET %d',
                $max,
            ),
            ['user_id' => $userId],
        );
        foreach ($extra as $row) {
            self::revokeSession((string) $row['id'], 'session_limit');
        }
    }

    public static function uuid(): string
    {
        $bytes = random_bytes(16);
        $bytes[6] = chr((ord($bytes[6]) & 0x0f) | 0x40);
        $bytes[8] = chr((ord($bytes[8]) & 0x3f) | 0x80);
        $hex = strtoupper(bin2hex($bytes));
        return sprintf(
            '%s-%s-%s-%s-%s',
            substr($hex, 0, 8),
            substr($hex, 8, 4),
            substr($hex, 12, 4),
            substr($hex, 16, 4),
            substr($hex, 20, 12),
        );
    }
}
