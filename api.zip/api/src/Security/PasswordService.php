<?php

declare(strict_types=1);

namespace ErrandRun\Security;

use ErrandRun\Core\Config;

/**
 * Argon2id with sane parameters, plus a policy that rejects the passwords that
 * actually get broken in practice.
 */
final class PasswordService
{
    /**
     * A hash of a value nobody knows, used to spend the same time verifying a
     * password for an account that does not exist.
     */
    private static ?string $dummyHash = null;

    /** @return array<string, int> */
    private static function options(): array
    {
        return [
            'memory_cost' => Config::int('ARGON_MEMORY_KIB', 65536),
            'time_cost'   => Config::int('ARGON_TIME_COST', 4),
            'threads'     => Config::int('ARGON_THREADS', 2),
        ];
    }

    public static function hash(string $password): string
    {
        $algorithm = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
        $hash = password_hash($password, $algorithm, $algorithm === PASSWORD_BCRYPT ? ['cost' => 12] : self::options());
        if (!is_string($hash) || $hash === '') {
            throw new \RuntimeException('Could not hash the password.');
        }
        return $hash;
    }

    public static function verify(string $password, string $hash): bool
    {
        return password_verify($password, $hash);
    }

    /**
     * Keeps the response time of a failed login independent of whether the
     * account exists.
     */
    public static function burnTime(string $password): void
    {
        if (self::$dummyHash === null) {
            self::$dummyHash = self::hash(bin2hex(random_bytes(16)));
        }
        password_verify($password, self::$dummyHash);
    }

    public static function needsRehash(string $hash): bool
    {
        $algorithm = defined('PASSWORD_ARGON2ID') ? PASSWORD_ARGON2ID : PASSWORD_BCRYPT;
        return password_needs_rehash($hash, $algorithm, $algorithm === PASSWORD_BCRYPT ? ['cost' => 12] : self::options());
    }

    /**
     * @return string|null an error message, or null when the password is acceptable
     */
    public static function policyError(string $password, string $email, string $displayName = ''): ?string
    {
        $lower = mb_strtolower($password);

        if (mb_strlen($password) < 10) {
            return 'At least 10 characters.';
        }
        if (preg_match('/^\s+$/u', $password) === 1) {
            return 'A password cannot be only spaces.';
        }

        $localPart = mb_strtolower(explode('@', $email)[0] ?? '');
        if ($localPart !== '' && mb_strlen($localPart) >= 4 && str_contains($lower, $localPart)) {
            return 'The password must not contain your email address.';
        }
        if ($displayName !== '' && mb_strlen($displayName) >= 4 && str_contains($lower, mb_strtolower($displayName))) {
            return 'The password must not contain your name.';
        }

        foreach (self::commonPasswords() as $common) {
            if ($lower === $common) {
                return 'That password is one of the most common ones. Pick another.';
            }
        }

        // A single repeated character, or a plain ascending run, is not a password.
        if (preg_match('/^(.)\1+$/u', $password) === 1) {
            return 'A password cannot be one repeated character.';
        }
        if (str_contains($lower, '1234567890') || str_contains($lower, 'abcdefghij') || str_contains($lower, 'qwertyuiop')) {
            return 'That password is a keyboard or number run. Pick another.';
        }

        return null;
    }

    /** @return list<string> */
    private static function commonPasswords(): array
    {
        return [
            'password', 'password1', 'password123', 'passw0rd123', '1234567890', '12345678901',
            'qwerty12345', 'qwertyuiop', 'letmein123', 'iloveyou123', 'admin12345', 'welcome123',
            'monkey12345', 'dragon12345', 'football123', 'baseball123', 'sunshine123', 'princess123',
            'superman123', 'trustno1234', 'changeme123', 'secret12345', 'errandrun1', 'errandrun123',
        ];
    }
}
