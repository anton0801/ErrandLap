<?php

declare(strict_types=1);

namespace ErrandRun\Security;

use ErrandRun\Core\ApiException;
use ErrandRun\Core\Clock;
use ErrandRun\Core\Database;

/**
 * Fixed-window counters in MySQL. Buckets are hashed, so an email address never
 * lands in the table in the clear.
 */
final class RateLimiter
{
    public static function bucket(string $scope, string $identifier): string
    {
        return $scope . ':' . hash('sha256', mb_strtolower($identifier));
    }

    /**
     * Counts one hit and refuses the request when the window is full.
     */
    public static function hit(string $bucket, int $limit, int $windowSeconds): void
    {
        $now = Clock::now();
        $expires = Clock::plusSeconds($windowSeconds, $now);

        Database::run(
            'INSERT INTO rate_limits (bucket, hits, expires_at)
             VALUES (:bucket, 1, :expires_new)
             ON DUPLICATE KEY UPDATE
                hits = IF(expires_at <= :now_a, 1, hits + 1),
                expires_at = IF(expires_at <= :now_b, :expires_reset, expires_at)',
            [
                'bucket'        => mb_substr($bucket, 0, 190),
                'expires_new'   => Clock::sql($expires),
                'expires_reset' => Clock::sql($expires),
                'now_a'         => Clock::sql($now),
                'now_b'         => Clock::sql($now),
            ],
        );

        $row = Database::first(
            'SELECT hits, expires_at FROM rate_limits WHERE bucket = :bucket LIMIT 1',
            ['bucket' => mb_substr($bucket, 0, 190)],
        );

        if ($row === null) {
            return;
        }

        if ((int) $row['hits'] > $limit) {
            $until = Clock::fromSql((string) $row['expires_at']);
            $retryAfter = $until === null ? $windowSeconds : max(1, $until->getTimestamp() - $now->getTimestamp());
            throw ApiException::tooManyRequests($retryAfter);
        }
    }

    /** Clears the counter after a success, so a good login resets the window. */
    public static function clear(string $bucket): void
    {
        Database::run('DELETE FROM rate_limits WHERE bucket = :bucket', ['bucket' => mb_substr($bucket, 0, 190)]);
    }

    /** Occasional housekeeping; cheap enough to run on a small share of requests. */
    public static function sweep(): void
    {
        if (random_int(1, 50) !== 1) {
            return;
        }
        Database::run('DELETE FROM rate_limits WHERE expires_at < :now LIMIT 1000', ['now' => Clock::sql()]);
    }
}
