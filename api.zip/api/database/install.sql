-- ===========================================================================
--  Errand Run — полная установка базы данных
-- ===========================================================================
--
--  КАК ПОСТАВИТЬ НА HOSTINGER
--  1. hPanel → Базы данных → MySQL. Создайте базу и пользователя,
--     запишите имя базы, имя пользователя и пароль — они пойдут в .env.
--  2. hPanel → Базы данных → phpMyAdmin → откройте свою базу.
--  3. Вкладка «Импорт» → выберите этот файл → «Вперёд».
--  4. Внизу должна появиться таблица из 11 строк — это проверка установки.
--
--  Файл ничего не удаляет: повторный импорт безопасен.
--  Чтобы поставить базу начисто, сначала выполните блок DROP ниже
--  (он закомментирован намеренно — он стирает все данные).
--
--  Совместимость: MySQL 5.7+ / 8.x / 9.x и MariaDB 10.2+.
--  Все отметки времени хранятся в UTC.
-- ===========================================================================

SET NAMES utf8mb4;
SET SESSION sql_mode = 'STRICT_ALL_TABLES,NO_ENGINE_SUBSTITUTION';
SET SESSION foreign_key_checks = 1;

-- --------------------------------------------------------------------------
-- Только для VPS или локальной машины, где есть права администратора.
-- На Hostinger база уже создана в hPanel — эти строки оставьте закрытыми.
-- --------------------------------------------------------------------------
-- CREATE DATABASE IF NOT EXISTS errandrun
--     CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
-- USE errandrun;

-- --------------------------------------------------------------------------
-- ПОЛНАЯ ПЕРЕУСТАНОВКА — стирает все данные.
-- Снимите комментарий только если хотите начать с чистого листа.
-- --------------------------------------------------------------------------
-- DROP TABLE IF EXISTS onAnalytics, web_players, travel_times, wasted_trips, visits, runs, windows,
--                      errands, places, user_settings, rate_limits,
--                      auth_events, sessions, users;

-- ===========================================================================
-- 1. Аккаунты
-- ===========================================================================

CREATE TABLE IF NOT EXISTS users (
    id                  CHAR(36)     NOT NULL,
    email               VARCHAR(190) NOT NULL,
    password_hash       VARCHAR(255) NOT NULL,
    display_name        VARCHAR(80)  NOT NULL DEFAULT '',
    email_verified_at   DATETIME(3)  NULL DEFAULT NULL,
    failed_attempts     INT UNSIGNED NOT NULL DEFAULT 0,
    locked_until        DATETIME(3)  NULL DEFAULT NULL,
    password_changed_at DATETIME(3)  NOT NULL,
    created_at          DATETIME(3)  NOT NULL,
    updated_at          DATETIME(3)  NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_users_email (email)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- Одна строка на устройство, где выполнен вход.
-- Хранятся только SHA-256 хеши токенов: из дампа базы рабочую сессию не собрать.
CREATE TABLE IF NOT EXISTS sessions (
    id                    CHAR(36)      NOT NULL,
    user_id               CHAR(36)      NOT NULL,
    access_token_hash     CHAR(64)      NULL DEFAULT NULL,
    access_expires_at     DATETIME(3)   NULL DEFAULT NULL,
    refresh_token_hash    CHAR(64)      NOT NULL,
    refresh_expires_at    DATETIME(3)   NOT NULL,
    previous_refresh_hash CHAR(64)      NULL DEFAULT NULL,
    device_name           VARCHAR(120)  NOT NULL DEFAULT '',
    ip_address            VARBINARY(16) NULL DEFAULT NULL,
    user_agent            VARCHAR(255)  NOT NULL DEFAULT '',
    created_at            DATETIME(3)   NOT NULL,
    last_used_at          DATETIME(3)   NOT NULL,
    revoked_at            DATETIME(3)   NULL DEFAULT NULL,
    revoked_reason        VARCHAR(40)   NULL DEFAULT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_sessions_access (access_token_hash),
    UNIQUE KEY uq_sessions_refresh (refresh_token_hash),
    KEY idx_sessions_user (user_id, revoked_at),
    KEY idx_sessions_previous (previous_refresh_hash),
    CONSTRAINT fk_sessions_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- Журнал событий безопасности. Почта хранится только хешем,
-- поэтому запись остаётся полезной и после удаления аккаунта.
CREATE TABLE IF NOT EXISTS auth_events (
    id         BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
    user_id    CHAR(36)      NULL DEFAULT NULL,
    email_hash CHAR(64)      NULL DEFAULT NULL,
    event      VARCHAR(40)   NOT NULL,
    outcome    VARCHAR(20)   NOT NULL,
    ip_address VARBINARY(16) NULL DEFAULT NULL,
    user_agent VARCHAR(255)  NOT NULL DEFAULT '',
    meta       TEXT          NULL DEFAULT NULL,
    created_at DATETIME(3)   NOT NULL,
    PRIMARY KEY (id),
    KEY idx_auth_events_user (user_id, created_at),
    KEY idx_auth_events_email (email_hash, created_at),
    CONSTRAINT fk_auth_events_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- Счётчики для ограничения частоты запросов. Ключи хешированы.
CREATE TABLE IF NOT EXISTS rate_limits (
    bucket     VARCHAR(190) NOT NULL,
    hits       INT UNSIGNED NOT NULL DEFAULT 0,
    expires_at DATETIME(3)  NOT NULL,
    PRIMARY KEY (bucket),
    KEY idx_rate_limits_expiry (expires_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ===========================================================================
-- 2. Настройки пользователя — одна строка на аккаунт
-- ===========================================================================

CREATE TABLE IF NOT EXISTS user_settings (
    user_id           CHAR(36)        NOT NULL,
    payload           TEXT            NOT NULL,
    revision          BIGINT UNSIGNED NOT NULL DEFAULT 1,
    client_updated_at DATETIME(3)     NOT NULL,
    updated_at        DATETIME(3)     NOT NULL,
    PRIMARY KEY (user_id),
    CONSTRAINT fk_user_settings_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ===========================================================================
-- 3. Синхронизируемые данные
--
--    Первичный ключ (user_id, id) — по построению ни один аккаунт не может
--    прочитать или переписать чужую строку, даже подставив чужой идентификатор.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS places (
    user_id           CHAR(36)        NOT NULL,
    id                CHAR(36)        NOT NULL,
    name              VARCHAR(120)    NOT NULL DEFAULT '',
    category          VARCHAR(24)     NOT NULL DEFAULT 'other',
    payload           TEXT            NOT NULL,
    revision          BIGINT UNSIGNED NOT NULL DEFAULT 1,
    client_updated_at DATETIME(3)     NOT NULL,
    updated_at        DATETIME(3)     NOT NULL,
    deleted_at        DATETIME(3)     NULL DEFAULT NULL,
    PRIMARY KEY (user_id, id),
    KEY idx_places_sync (user_id, updated_at),
    CONSTRAINT fk_places_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE IF NOT EXISTS errands (
    user_id           CHAR(36)        NOT NULL,
    id                CHAR(36)        NOT NULL,
    title             VARCHAR(200)    NOT NULL DEFAULT '',
    place_id          CHAR(36)        NULL DEFAULT NULL,
    state             VARCHAR(16)     NOT NULL DEFAULT 'open',
    payload           TEXT            NOT NULL,
    revision          BIGINT UNSIGNED NOT NULL DEFAULT 1,
    client_updated_at DATETIME(3)     NOT NULL,
    updated_at        DATETIME(3)     NOT NULL,
    deleted_at        DATETIME(3)     NULL DEFAULT NULL,
    PRIMARY KEY (user_id, id),
    KEY idx_errands_sync (user_id, updated_at),
    KEY idx_errands_place (user_id, place_id),
    CONSTRAINT fk_errands_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE IF NOT EXISTS windows (
    user_id           CHAR(36)        NOT NULL,
    id                CHAR(36)        NOT NULL,
    title             VARCHAR(120)    NOT NULL DEFAULT '',
    payload           TEXT            NOT NULL,
    revision          BIGINT UNSIGNED NOT NULL DEFAULT 1,
    client_updated_at DATETIME(3)     NOT NULL,
    updated_at        DATETIME(3)     NOT NULL,
    deleted_at        DATETIME(3)     NULL DEFAULT NULL,
    PRIMARY KEY (user_id, id),
    KEY idx_windows_sync (user_id, updated_at),
    CONSTRAINT fk_windows_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE IF NOT EXISTS runs (
    user_id           CHAR(36)        NOT NULL,
    id                CHAR(36)        NOT NULL,
    run_day           DATE            NULL DEFAULT NULL,
    state             VARCHAR(16)     NOT NULL DEFAULT 'planned',
    payload           TEXT            NOT NULL,
    revision          BIGINT UNSIGNED NOT NULL DEFAULT 1,
    client_updated_at DATETIME(3)     NOT NULL,
    updated_at        DATETIME(3)     NOT NULL,
    deleted_at        DATETIME(3)     NULL DEFAULT NULL,
    PRIMARY KEY (user_id, id),
    KEY idx_runs_sync (user_id, updated_at),
    CONSTRAINT fk_runs_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE IF NOT EXISTS visits (
    user_id           CHAR(36)        NOT NULL,
    id                CHAR(36)        NOT NULL,
    place_id          CHAR(36)        NULL DEFAULT NULL,
    payload           TEXT            NOT NULL,
    revision          BIGINT UNSIGNED NOT NULL DEFAULT 1,
    client_updated_at DATETIME(3)     NOT NULL,
    updated_at        DATETIME(3)     NOT NULL,
    deleted_at        DATETIME(3)     NULL DEFAULT NULL,
    PRIMARY KEY (user_id, id),
    KEY idx_visits_sync (user_id, updated_at),
    KEY idx_visits_place (user_id, place_id),
    CONSTRAINT fk_visits_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

CREATE TABLE IF NOT EXISTS wasted_trips (
    user_id           CHAR(36)        NOT NULL,
    id                CHAR(36)        NOT NULL,
    place_id          CHAR(36)        NULL DEFAULT NULL,
    reason            VARCHAR(32)     NOT NULL DEFAULT 'other',
    payload           TEXT            NOT NULL,
    revision          BIGINT UNSIGNED NOT NULL DEFAULT 1,
    client_updated_at DATETIME(3)     NOT NULL,
    updated_at        DATETIME(3)     NOT NULL,
    deleted_at        DATETIME(3)     NULL DEFAULT NULL,
    PRIMARY KEY (user_id, id),
    KEY idx_wasted_sync (user_id, updated_at),
    CONSTRAINT fk_wasted_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- Время в пути между двумя точками: считается один раз и хранится.
CREATE TABLE IF NOT EXISTS travel_times (
    user_id           CHAR(36)        NOT NULL,
    cache_key         VARCHAR(190)    NOT NULL,
    minutes           INT UNSIGNED    NOT NULL DEFAULT 0,
    source            VARCHAR(16)     NOT NULL DEFAULT 'manual',
    payload           TEXT            NOT NULL,
    revision          BIGINT UNSIGNED NOT NULL DEFAULT 1,
    client_updated_at DATETIME(3)     NOT NULL,
    updated_at        DATETIME(3)     NOT NULL,
    deleted_at        DATETIME(3)     NULL DEFAULT NULL,
    PRIMARY KEY (user_id, cache_key),
    KEY idx_travel_sync (user_id, updated_at),
    CONSTRAINT fk_travel_user FOREIGN KEY (user_id) REFERENCES users (id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ===========================================================================
-- 4. Мини-приложение для WebView (Spark Run)
--
--    Отдельный, анонимный игрок: связан только с кукой, не с аккаунтом.
--    В таблице нет ничего личного — ни почты, ни имени, ни адресов.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS web_players (
    id             CHAR(36)     NOT NULL,
    cookie_hash    CHAR(64)     NOT NULL,
    best_score     INT UNSIGNED NOT NULL DEFAULT 0,
    last_score     INT UNSIGNED NOT NULL DEFAULT 0,
    best_combo     INT UNSIGNED NOT NULL DEFAULT 0,
    rounds_played  INT UNSIGNED NOT NULL DEFAULT 0,
    sparks_caught  INT UNSIGNED NOT NULL DEFAULT 0,
    streak_days    INT UNSIGNED NOT NULL DEFAULT 0,
    best_streak    INT UNSIGNED NOT NULL DEFAULT 0,
    last_played_on DATE         NULL DEFAULT NULL,
    visits         INT UNSIGNED NOT NULL DEFAULT 0,
    state          TEXT         NOT NULL,
    created_at     DATETIME(3)  NOT NULL,
    updated_at     DATETIME(3)  NOT NULL,
    last_seen_at   DATETIME(3)  NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_web_players_cookie (cookie_hash),
    KEY idx_web_players_seen (last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- ===========================================================================
-- 5. Переключатель для приложения
--
--    Одна строка. Её значение уходит в каждом ответе заголовком
--    X-App-Target: true | false — приложение читает его при запуске.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS onAnalytics (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    isOn       TINYINT(1)   NOT NULL DEFAULT 0,
    created_at DATETIME(3)  NOT NULL,
    updated_at DATETIME(3)  NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

INSERT INTO onAnalytics (id, isOn, created_at, updated_at)
SELECT 1, 0, UTC_TIMESTAMP(3), UTC_TIMESTAMP(3)
 WHERE NOT EXISTS (SELECT 1 FROM onAnalytics WHERE id = 1);

-- ===========================================================================
-- Проверка установки
-- ===========================================================================
--  Ожидается ровно 14 строк со словом OK. Если строк меньше — импорт
--  прервался, и в отчёте phpMyAdmin выше будет видно, на какой таблице.
-- ===========================================================================

SELECT t.needed AS `Таблица`,
       CASE WHEN COUNT(i.TABLE_NAME) > 0 THEN 'OK' ELSE 'НЕ СОЗДАНА' END AS `Статус`
  FROM (
        SELECT 'users' AS needed
  UNION SELECT 'sessions'
  UNION SELECT 'auth_events'
  UNION SELECT 'rate_limits'
  UNION SELECT 'user_settings'
  UNION SELECT 'places'
  UNION SELECT 'errands'
  UNION SELECT 'windows'
  UNION SELECT 'runs'
  UNION SELECT 'visits'
  UNION SELECT 'wasted_trips'
  UNION SELECT 'travel_times'
  UNION SELECT 'web_players'
  UNION SELECT 'onAnalytics'
       ) AS t
  LEFT JOIN information_schema.TABLES i
         ON i.TABLE_NAME = t.needed
        AND i.TABLE_SCHEMA = DATABASE()
 GROUP BY t.needed
 ORDER BY t.needed;
