-- ===========================================================================
--  Обновление базы: мини-приложение для WebView (Spark Run)
--
--  Нужно только если install.sql уже импортирован раньше и таблицы
--  web_players в базе ещё нет. Импортируется так же, через phpMyAdmin.
--  Ничего не удаляет и не меняет в существующих таблицах.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS web_players (
    id             CHAR(36)     NOT NULL,
    cookie_hash    CHAR(64)     NOT NULL,
    best_score     INT UNSIGNED NOT NULL DEFAULT 0,
    last_score     INT UNSIGNED NOT NULL DEFAULT 0,
    best_combo     INT UNSIGNED NOT NULL DEFAULT 0,
    rounds_played  INT UNSIGNED NOT NULL DEFAULT 0,
    sparks_caught  INT UNSIGNED NOT NULL DEFAULT 0,
    streak_days    INT UNSIGNED NOT NULL DEFAULT 0,
    best_streak    INT UNSIGNED NOT NULL DEFAULT 0,
    last_played_on DATE         NULL DEFAULT NULL,
    visits         INT UNSIGNED NOT NULL DEFAULT 0,
    state          TEXT         NOT NULL,
    created_at     DATETIME(3)  NOT NULL,
    updated_at     DATETIME(3)  NOT NULL,
    last_seen_at   DATETIME(3)  NOT NULL,
    PRIMARY KEY (id),
    UNIQUE KEY uq_web_players_cookie (cookie_hash),
    KEY idx_web_players_seen (last_seen_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

SELECT CASE WHEN COUNT(*) = 1 THEN 'OK — таблица web_players на месте'
            ELSE 'НЕ СОЗДАНА' END AS `Статус`
  FROM information_schema.TABLES
 WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = 'web_players';
