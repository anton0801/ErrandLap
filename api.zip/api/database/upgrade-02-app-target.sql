-- ===========================================================================
--  Обновление базы: таблица onAnalytics
--
--  Одна строка, один переключатель. Его значение сервер отдаёт в каждом ответе
--  заголовком  X-App-Target: true | false  — приложение читает его при запуске.
--
--  Импортируется через phpMyAdmin так же, как install.sql. Ничего не удаляет.
--  Повторный импорт безопасен: таблица и строка создаются только если их нет.
-- ===========================================================================

CREATE TABLE IF NOT EXISTS onAnalytics (
    id         INT UNSIGNED NOT NULL AUTO_INCREMENT,
    isOn       TINYINT(1)   NOT NULL DEFAULT 0,
    created_at DATETIME(3)  NOT NULL,
    updated_at DATETIME(3)  NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=DYNAMIC;

-- Единственная строка. id = 1 всегда, вставляется только один раз.
INSERT INTO onAnalytics (id, isOn, created_at, updated_at)
SELECT 1, 0, UTC_TIMESTAMP(3), UTC_TIMESTAMP(3)
 WHERE NOT EXISTS (SELECT 1 FROM onAnalytics WHERE id = 1);

-- ---------------------------------------------------------------------------
-- Как переключать
-- ---------------------------------------------------------------------------
--   Включить:   UPDATE onAnalytics SET isOn = 1, updated_at = UTC_TIMESTAMP(3) WHERE id = 1;
--   Выключить:  UPDATE onAnalytics SET isOn = 0, updated_at = UTC_TIMESTAMP(3) WHERE id = 1;
--
-- В phpMyAdmin это же делается мышью: вкладка «Обзор», карандаш, поле isOn.
-- ---------------------------------------------------------------------------

SELECT id,
       isOn,
       CASE WHEN isOn = 1 THEN 'true' ELSE 'false' END AS `X-App-Target отдаёт`,
       created_at,
       updated_at
  FROM onAnalytics;
