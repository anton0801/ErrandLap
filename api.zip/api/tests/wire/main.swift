//
//  Wire-format check.
//
//  Compiles the app's own model and API types and runs them against the live API:
//  if the payload the app produces is not what the server accepts, this fails.
//

import Foundation

// Defaults to the local server; point ER_BASE at a deployment to check that one.
let base = URL(string: ProcessInfo.processInfo.environment["ER_BASE"] ?? "http://127.0.0.1:8799")!
var passed = 0
var failed = 0

func check(_ label: String, _ condition: Bool, _ detail: String = "") {
    if condition {
        passed += 1
        print("  ok   \(label)")
    } else {
        failed += 1
        print("  FAIL \(label) \(detail)")
    }
}

struct HTTPResult {
    var status: Int
    var data: Data
}

func request(_ method: String, _ path: String, body: Data? = nil, token: String? = nil) async -> HTTPResult {
    var request = URLRequest(url: URL(string: path, relativeTo: base)!)
    request.httpMethod = method
    if let body {
        request.httpBody = body
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
    }
    if let token {
        request.setValue("Bearer \(token)", forHTTPHeaderField: "Authorization")
    }
    do {
        let (data, response) = try await URLSession.shared.data(for: request)
        return HTTPResult(status: (response as? HTTPURLResponse)?.statusCode ?? 0, data: data)
    } catch {
        return HTTPResult(status: 0, data: Data(error.localizedDescription.utf8))
    }
}

func encode(_ value: some Encodable) -> Data {
    (try? APICoder.encoder.encode(value)) ?? Data()
}

// MARK: - Sign up with the app's own coder

let stamp = Int(Date().timeIntervalSince1970)
let email = "wire+\(stamp)@errandrun.test"
let password = "correct horse battery staple 7"

print("== account ==")
let registerBody = try! JSONSerialization.data(withJSONObject: [
    "email": email, "password": password, "display_name": "Wire", "device_name": "Wire check",
])
let registered = await request("POST", "/v1/auth/register", body: registerBody)
check("register", registered.status == 201, "status \(registered.status)")

guard let auth = try? APICoder.decoder.decode(AuthResponse.self, from: registered.data) else {
    print("  FAIL the app cannot decode the auth response")
    print(String(data: registered.data, encoding: .utf8) ?? "")
    exit(1)
}
check("AuthResponse decodes", !auth.tokens.accessToken.isEmpty)
check("token expiry parsed", auth.tokens.accessExpiresAt > Date(), "\(auth.tokens.accessExpiresAt)")
let token = auth.tokens.accessToken

// MARK: - Push the app's real models

print("== the app's models on the wire ==")

var place = Place()
place.name = "Post Office"
place.address = "Main street 1"
place.category = .post
place.queueEstimate = 15
place.parking = .hard
place.notes = "Parcels at window three."
place.coordinate = GeoPoint(latitude: 37.3323, longitude: -122.0322)
place.hours[2] = DayHours(isOpen: true, open: 9 * 60, close: 14 * 60, hasLunch: true,
                          lunchStart: 12 * 60, lunchEnd: 12 * 60 + 30, lastEntryOffset: 15)
place.updatedAt = Date()

var errand = Errand()
errand.title = "Collect the parcel"
errand.placeID = place.id
errand.category = .post
errand.duration = 15
errand.priority = .high
errand.requiresDocuments = true
errand.documents = ["Passport", "Delivery slip"]
errand.deadline = Date().addingTimeInterval(86_400 * 9)
errand.shopping = [ShoppingItem(name: "Tape", quantity: "1", note: "", bought: false)]
errand.recurrence = Recurrence(intervalDays: 30, nextDue: Date(), lastDone: nil, flexibleByDays: 3)
errand.delegation = Delegation(assignedTo: "Marina", instructions: "Window three.", status: .assigned)
errand.updatedAt = Date()

var window = FreeWindow()
window.title = "Lunch break"
window.weekdays = [2, 3, 4, 5, 6]
window.start = 13 * 60 + 10
window.end = 14 * 60 + 40
window.from = .work
window.to = .place(place.id)
window.updatedAt = Date()

var visit = VisitLog(placeID: place.id, errandID: errand.id, date: Date(),
                     estimated: 30, actual: 41, taskMinutes: 15)
visit.updatedAt = Date()

var trip = WastedTrip(placeID: place.id, errandID: nil, date: Date(),
                      reason: .wrongHours, missing: "", notes: "Closed at one, not two.")
trip.updatedAt = Date()

var run = Run()
run.day = Date()
run.windowID = window.id
run.windowTitle = "Lunch break"
run.start = 13 * 60 + 10
run.end = 14 * 60 + 40
run.from = .work
run.to = .place(place.id)
run.stops = [RunStop(errandID: errand.id, placeID: place.id, title: errand.title,
                     placeName: place.name, plannedTravel: 11, plannedArrival: 13 * 60 + 35,
                     plannedInside: 30, plannedLeave: 14 * 60 + 5, queueAllowance: 15,
                     closeTime: 14 * 60, lastEntry: 13 * 60 + 45, documents: errand.documents,
                     state: .done, arrivedAt: Date(), actualInside: 41, skipReason: nil)]
run.state = .finished
run.updatedAt = Date()

var settings = Settings()
settings.displayName = "Wire"
settings.homeAddress = "1 Infinite Loop"
settings.homeCoordinate = GeoPoint(latitude: 37.33182, longitude: -122.03118)
settings.travelMode = .driving
settings.buffer = 10
settings.setupComplete = true
settings.onboardingSeen = true

let travelKey = "home>\(place.id.uuidString)|driving"
let travel = TravelEntry(minutes: 11, source: .map, updatedAt: Date())

var push = SyncPush()
push.settings = SyncSettingsItem(updatedAt: Date(), payload: settings)
push.places = [SyncItem(id: place.id.uuidString, updatedAt: place.updatedAt!, deleted: false, payload: place)]
push.errands = [SyncItem(id: errand.id.uuidString, updatedAt: errand.updatedAt!, deleted: false, payload: errand)]
push.windows = [SyncItem(id: window.id.uuidString, updatedAt: window.updatedAt!, deleted: false, payload: window)]
push.runs = [SyncItem(id: run.id.uuidString, updatedAt: run.updatedAt!, deleted: false, payload: run)]
push.visits = [SyncItem(id: visit.id.uuidString, updatedAt: visit.updatedAt!, deleted: false, payload: visit)]
push.wastedTrips = [SyncItem(id: trip.id.uuidString, updatedAt: trip.updatedAt!, deleted: false, payload: trip)]
push.travelTimes = [SyncItem(id: travelKey, updatedAt: travel.updatedAt, deleted: false, payload: travel)]

check("push counts every record", push.count == 8, "\(push.count)")

let pushed = await request("POST", "/v1/sync", body: encode(push), token: token)
check("server accepts the app's payload", pushed.status == 200,
      "status \(pushed.status): \(String(data: pushed.data, encoding: .utf8)?.prefix(300) ?? "")")

// MARK: - Pull it back and decode into the same types

print("== round trip ==")
let pulled = await request("GET", "/v1/sync", token: token)
check("pull", pulled.status == 200, "status \(pulled.status)")

guard let delta = try? APICoder.decoder.decode(SyncDelta.self, from: pulled.data) else {
    print("  FAIL the app cannot decode the delta")
    print(String(data: pulled.data, encoding: .utf8)?.prefix(400) ?? "")
    exit(1)
}

check("delta decodes", delta.totalItems == 7, "\(delta.totalItems) items")

let backPlace = delta.places.first?.payload
check("place survived", backPlace?.name == "Post Office")
check("opening hours survived", backPlace?.hours[2].lastEntryOffset == 15, "\(backPlace?.hours[2].lastEntryOffset ?? -1)")
check("lunch break survived", backPlace?.hours[2].hasLunch == true)
check("coordinate survived", backPlace?.coordinate?.latitude == 37.3323)
check("parking difficulty survived", backPlace?.parking == .hard)

let backErrand = delta.errands.first?.payload
check("errand survived", backErrand?.title == "Collect the parcel")
check("documents survived", backErrand?.documents == ["Passport", "Delivery slip"])
check("deadline survived", backErrand?.deadline != nil)
check("shopping list survived", backErrand?.shopping.first?.name == "Tape")
check("recurrence survived", backErrand?.recurrence?.intervalDays == 30)
check("delegation survived", backErrand?.delegation?.assignedTo == "Marina")
check("place link survived", backErrand?.placeID == place.id)

let backWindow = delta.windows.first?.payload
check("window endpoints survived", backWindow?.to == .place(place.id), "\(String(describing: backWindow?.to))")
check("window times survived", backWindow?.start == 13 * 60 + 10)

let backRun = delta.runs.first?.payload
check("run stops survived", backRun?.stops.first?.actualInside == 41)
check("run state survived", backRun?.state == .finished)

let backVisit = delta.visits.first?.payload
check("measured visit survived", backVisit?.actual == 41 && backVisit?.taskMinutes == 15)

let backTrip = delta.wastedTrips.first?.payload
check("wasted trip survived", backTrip?.reason == .wrongHours)

let backTravel = delta.travelTimes.first
check("travel key survived", backTravel?.id == travelKey, backTravel?.id ?? "nil")
check("travel minutes survived", backTravel?.payload?.minutes == 11)

check("settings survived", delta.settings?.payload?.buffer == 10)
check("home coordinate survived", delta.settings?.payload?.homeCoordinate?.latitude == 37.33182)
check("server time parsed", delta.serverTime.timeIntervalSinceNow > -120)

// MARK: - Conflict and tombstone behaviour, as the engine relies on it

print("== conflicts and deletions ==")
var stale = place
stale.name = "Stale name"
let staleItem = SyncItem(id: place.id.uuidString, updatedAt: Date().addingTimeInterval(-7200),
                         deleted: false, payload: stale)
var stalePush = SyncPush()
stalePush.places = [staleItem]
let staleResult = await request("POST", "/v1/sync", body: encode(stalePush), token: token)
check("stale edit is not applied", staleResult.status == 200)
if let staleDelta = try? APICoder.decoder.decode(SyncDelta.self, from: staleResult.data) {
    let name = staleDelta.places.first(where: { $0.id == place.id.uuidString })?.payload?.name
    check("server kept the newer name", name == "Post Office", name ?? "nil")
}

var deletion = SyncPush()
deletion.errands = [SyncItem<Errand>(id: errand.id.uuidString, updatedAt: Date(), deleted: true, payload: nil)]
let deleted = await request("POST", "/v1/sync", body: encode(deletion), token: token)
check("delete accepted", deleted.status == 200)

let after = await request("GET", "/v1/sync", token: token)
if let afterDelta = try? APICoder.decoder.decode(SyncDelta.self, from: after.data) {
    let tomb = afterDelta.errands.first { $0.id == errand.id.uuidString }
    check("tombstone comes back", tomb?.deleted == true)
    check("tombstone decodes without a payload", tomb?.payload == nil)
}

// MARK: - Token handling

print("== tokens ==")
let refreshBody = try! JSONSerialization.data(withJSONObject: ["refresh_token": auth.tokens.refreshToken])
let refreshed = await request("POST", "/v1/auth/refresh", body: refreshBody)
check("refresh", refreshed.status == 200, "status \(refreshed.status)")
let rotated = try? APICoder.decoder.decode(AuthResponse.self, from: refreshed.data)
check("rotated token differs", rotated?.tokens.accessToken != auth.tokens.accessToken)

let withOld = await request("GET", "/v1/me", token: token)
check("the first access token still works until it expires", withOld.status == 200 || withOld.status == 401,
      "status \(withOld.status)")

let profile = await request("GET", "/v1/me", token: rotated?.tokens.accessToken ?? "")
check("profile with the new token", profile.status == 200)
if let decoded = try? APICoder.decoder.decode(ProfileResponse.self, from: profile.data) {
    check("ProfileResponse decodes", decoded.user.email == email)
    check("counts come back", (decoded.counts?["places"] ?? 0) >= 1)
}

let sessionsResult = await request("GET", "/v1/me/sessions", token: rotated?.tokens.accessToken ?? "")
if let sessions = try? APICoder.decoder.decode(SessionsResponse.self, from: sessionsResult.data) {
    check("SessionsResponse decodes", sessions.sessions.count >= 1)
    check("current device is flagged", sessions.sessions.contains { $0.current })
}

// MARK: - Error shape the app shows to the user

print("== errors ==")
let badLogin = await request("POST", "/v1/auth/login",
                             body: try! JSONSerialization.data(withJSONObject: ["email": email, "password": "wrong-password"]))
check("bad login refused", badLogin.status == 401)
if let body = try? APICoder.decoder.decode(APIErrorBody.self, from: badLogin.data) {
    check("APIErrorBody decodes", body.error.code == "invalid_credentials")
    check("message is human", body.error.message.hasSuffix("."))
}

let badField = await request("POST", "/v1/auth/register",
                             body: try! JSONSerialization.data(withJSONObject: ["email": "nope", "password": "short"]))
if let body = try? APICoder.decoder.decode(APIErrorBody.self, from: badField.data) {
    check("field errors decode", (body.error.details?.fields?.count ?? 0) >= 1,
          "\(String(describing: body.error.details?.fields))")
}

// MARK: - Clean up after ourselves

let deleteBody = try! JSONSerialization.data(withJSONObject: ["password": password, "confirm": "DELETE"])
let removed = await request("DELETE", "/v1/me", body: deleteBody, token: rotated?.tokens.accessToken ?? "")
check("test account deleted", removed.status == 200)

print("")
print("passed: \(passed)   failed: \(failed)")
exit(failed == 0 ? 0 : 1)
