#!/usr/bin/env python3
"""End-to-end exercise of the Errand Run API, including the cases that must fail."""
import json, time, uuid, datetime, urllib.request, urllib.error, subprocess, sys

BASE = "http://127.0.0.1:8799"
passed, failed = 0, 0
last_body = {}


def req(method, path, body=None, token=None):
    global last_body
    data = json.dumps(body).encode() if body is not None else None
    r = urllib.request.Request(BASE + path, data=data, method=method)
    if data is not None:
        r.add_header("Content-Type", "application/json")
    if token:
        r.add_header("Authorization", "Bearer " + token)
    try:
        with urllib.request.urlopen(r) as resp:
            raw = resp.read().decode()
            last_body = json.loads(raw) if raw else {}
            return resp.status
    except urllib.error.HTTPError as e:
        raw = e.read().decode()
        try:
            last_body = json.loads(raw) if raw else {}
        except json.JSONDecodeError:
            last_body = {"raw": raw[:300]}
        return e.code
    except Exception as e:
        last_body = {"error": str(e)}
        return 0


def check(label, expected, actual):
    global passed, failed
    if expected == actual:
        print(f"  ok   {label} ({actual})")
        passed += 1
    else:
        print(f"  FAIL {label} — expected {expected}, got {actual}")
        print(f"       {json.dumps(last_body)[:300]}")
        failed += 1


def expect(label, condition, detail=""):
    global passed, failed
    if condition:
        print(f"  ok   {label}")
        passed += 1
    else:
        print(f"  FAIL {label} {detail}")
        failed += 1


def reset_limits():
    """The throttle is doing its job; clear the counters so the suite can continue."""
    subprocess.run(["mysql", "-u", "root", "-e", "DELETE FROM errandrun.rate_limits"],
                   check=False, capture_output=True)


def now_iso(offset_hours=0):
    moment = datetime.datetime.now(datetime.timezone.utc) + datetime.timedelta(hours=offset_hours)
    return moment.strftime("%Y-%m-%dT%H:%M:%S.000Z")


stamp = str(int(time.time()))
EMAIL = f"tester+{stamp}@errandrun.test"
PW = "correct horse battery staple 7"

reset_limits()  # start from a clean throttle window

print("== health ==")
check("health", 200, req("GET", "/v1/health"))
expect("service identifies itself", last_body.get("api") == "errandrun", str(last_body))

print("== registration ==")
check("register", 201, req("POST", "/v1/auth/register",
      {"email": EMAIL, "password": PW, "display_name": "Anton", "device_name": "Test runner"}))
tokens = last_body.get("tokens", {})
ACCESS, REFRESH = tokens.get("access_token", ""), tokens.get("refresh_token", "")
expect("access token issued", ACCESS.startswith("era_"), ACCESS[:12])
expect("refresh token issued", REFRESH.startswith("err_"), REFRESH[:12])
expect("password never echoed", "password" not in json.dumps(last_body))

check("duplicate email rejected", 409, req("POST", "/v1/auth/register", {"email": EMAIL, "password": PW}))
check("weak password rejected", 422, req("POST", "/v1/auth/register",
      {"email": f"weak+{stamp}@errandrun.test", "password": "password123"}))
check("short password rejected", 422, req("POST", "/v1/auth/register",
      {"email": f"short+{stamp}@errandrun.test", "password": "short"}))
check("bad email rejected", 422, req("POST", "/v1/auth/register",
      {"email": "not-an-email", "password": PW}))
reset_limits()
check("unknown field rejected", 422, req("POST", "/v1/auth/register",
      {"email": f"x+{stamp}@errandrun.test", "password": PW, "is_admin": True}))

print("== throttling ==")
code = 200
for i in range(8):
    code = req("POST", "/v1/auth/register",
               {"email": f"flood{i}+{stamp}@errandrun.test", "password": PW})
    if code == 429:
        break
check("registration is rate limited", 429, code)
expect("retry-after supplied", isinstance(last_body.get("error", {}).get("details", {}).get("retry_after"), int))
reset_limits()

print("== authentication required ==")
check("no token", 401, req("GET", "/v1/me"))
check("junk token", 401, req("GET", "/v1/me", None, "era_totally-made-up-token"))
check("wrong prefix", 401, req("GET", "/v1/me", None, "nonsense"))
check("sync needs a token", 401, req("GET", "/v1/sync"))

print("== profile ==")
check("me", 200, req("GET", "/v1/me", None, ACCESS))
expect("no password hash in profile", "password_hash" not in json.dumps(last_body))
check("patch display name", 200, req("PATCH", "/v1/me", {"display_name": "Anton D"}, ACCESS))
expect("display name updated", last_body.get("user", {}).get("display_name") == "Anton D")
check("patch rejects unknown field", 422, req("PATCH", "/v1/me", {"role": "admin"}, ACCESS))
check("email change needs password", 422, req("PATCH", "/v1/me",
      {"email": f"other+{stamp}@errandrun.test"}, ACCESS))

print("== login ==")
reset_limits()
check("login", 200, req("POST", "/v1/auth/login", {"email": EMAIL, "password": PW, "device_name": "Second device"}))
ACCESS2 = last_body.get("tokens", {}).get("access_token", "")
check("wrong password", 401, req("POST", "/v1/auth/login", {"email": EMAIL, "password": "nope-nope-nope"}))
expect("no hint about which half was wrong",
       last_body.get("error", {}).get("message") == "That email or password is not right.")
check("unknown account", 401, req("POST", "/v1/auth/login",
      {"email": f"ghost+{stamp}@errandrun.test", "password": "nope-nope-nope"}))
expect("same message for unknown account",
       last_body.get("error", {}).get("message") == "That email or password is not right.")

print("== sessions ==")
check("list sessions", 200, req("GET", "/v1/me/sessions", None, ACCESS))
sessions = last_body.get("sessions", [])
expect("two devices listed", len(sessions) == 2, str(len(sessions)))
expect("current session flagged", any(s.get("current") for s in sessions))
expect("no token material in session list", "token" not in json.dumps(sessions).lower())
check("revoke unknown session", 404, req("DELETE", "/v1/me/sessions/11111111-1111-1111-1111-111111111111", None, ACCESS))

print("== resources ==")
PLACE_ID = str(uuid.uuid4()).upper()
NOW = now_iso()
place = {"id": PLACE_ID, "updated_at": NOW, "payload": {
    "id": PLACE_ID, "name": "Post Office", "address": "Main street 1", "category": "post",
    "queueEstimate": 15, "notes": "", "photos": [], "createdAt": NOW}}
check("create place", 201, req("POST", "/v1/places", place, ACCESS))
check("read place", 200, req("GET", f"/v1/places/{PLACE_ID}", None, ACCESS))
expect("payload round-tripped", last_body.get("item", {}).get("payload", {}).get("name") == "Post Office")
check("list places", 200, req("GET", "/v1/places", None, ACCESS))
check("unknown collection", 404, req("GET", "/v1/dragons", None, ACCESS))
check("payload with unknown key rejected", 422, req("POST", "/v1/places",
      {"id": PLACE_ID, "updated_at": NOW, "payload": {"name": "x", "evil": 1}}, ACCESS))
check("non-uuid id rejected", 404, req("GET", "/v1/places/not-a-uuid", None, ACCESS))
check("sql-injection-shaped id rejected", 404,
      req("GET", "/v1/places/%27%20OR%201%3D1%20--", None, ACCESS))

print("== injection attempts are stored as data, not executed ==")
NASTY_ID = str(uuid.uuid4()).upper()
nasty = {"id": NASTY_ID, "updated_at": NOW, "payload": {
    "id": NASTY_ID, "name": "'; DROP TABLE users; --", "category": "other", "createdAt": NOW}}
check("hostile string accepted as text", 201, req("POST", "/v1/places", nasty, ACCESS))
check("users table intact", 200, req("GET", "/v1/me", None, ACCESS))

print("== ownership isolation ==")
reset_limits()
OTHER_EMAIL = f"other+{stamp}@errandrun.test"
req("POST", "/v1/auth/register", {"email": OTHER_EMAIL, "password": PW, "device_name": "Other"})
OTHER = last_body.get("tokens", {}).get("access_token", "")
check("another account cannot read the place", 404, req("GET", f"/v1/places/{PLACE_ID}", None, OTHER))
check("another account cannot delete it", 404, req("DELETE", f"/v1/places/{PLACE_ID}", None, OTHER))
check("another account cannot overwrite it", 200, req("PUT", f"/v1/places/{PLACE_ID}",
      {"id": PLACE_ID, "updated_at": now_iso(1), "payload": {"name": "Hijacked", "category": "other"}}, OTHER))
check("original owner still sees their own name", 200, req("GET", f"/v1/places/{PLACE_ID}", None, ACCESS))
expect("no cross-account write", last_body.get("item", {}).get("payload", {}).get("name") == "Post Office",
       json.dumps(last_body)[:200])
check("other account sees only its own copy", 200, req("GET", f"/v1/places/{PLACE_ID}", None, OTHER))
expect("separate row per account", last_body.get("item", {}).get("payload", {}).get("name") == "Hijacked")

print("== sync ==")
ERRAND_ID = str(uuid.uuid4()).upper()
sync_body = {
    "settings": {"updated_at": NOW, "payload": {"displayName": "Anton", "buffer": 5,
                                                "travelMode": "driving", "setupComplete": True}},
    "errands": [{"id": ERRAND_ID, "updated_at": NOW, "payload": {
        "id": ERRAND_ID, "title": "Collect the parcel", "placeID": PLACE_ID, "duration": 15,
        "state": "open", "category": "post", "createdAt": NOW}}],
}
check("push sync", 200, req("POST", "/v1/sync", sync_body, ACCESS))
expect("push reported applied", last_body.get("applied", {}).get("errands") == 1, json.dumps(last_body.get("applied")))
check("pull sync", 200, req("GET", "/v1/sync", None, ACCESS))
errands = last_body.get("errands", [])
expect("errand round-tripped", any(e["payload"].get("title") == "Collect the parcel" for e in errands))
expect("settings round-tripped", last_body.get("settings", {}).get("payload", {}).get("buffer") == 5)
server_time = last_body.get("server_time")
expect("server time present", isinstance(server_time, str) and server_time.endswith("Z"))

check("delta since now is empty", 200, req("GET", f"/v1/sync?since={now_iso(1)}", None, ACCESS))
expect("nothing newer than the future", last_body.get("errands") == [])

check("push rejects unknown collection key", 422, req("POST", "/v1/sync", {"dragons": []}, ACCESS))
check("push rejects malformed item", 422, req("POST", "/v1/sync", {"errands": [{"id": "nope"}]}, ACCESS))

print("== conflict resolution ==")
check("older edit is refused", 409, req("PUT", f"/v1/places/{PLACE_ID}",
      {"id": PLACE_ID, "updated_at": now_iso(-2), "payload": {"name": "Stale name", "category": "post"}}, ACCESS))
check("newer edit wins", 200, req("PUT", f"/v1/places/{PLACE_ID}",
      {"id": PLACE_ID, "updated_at": now_iso(0), "payload": {"name": "Post Office on Main", "category": "post"}}, ACCESS))

print("== deletion and tombstones ==")
check("delete place", 200, req("DELETE", f"/v1/places/{PLACE_ID}", None, ACCESS))
check("deleted place is gone", 404, req("GET", f"/v1/places/{PLACE_ID}", None, ACCESS))
check("tombstone visible in sync", 200, req("GET", "/v1/sync", None, ACCESS))
places = last_body.get("places", [])
tomb = [p for p in places if p["id"] == PLACE_ID]
expect("tombstone returned", tomb and tomb[0]["deleted"] is True)
expect("deleted payload emptied", tomb and tomb[0]["payload"] in ({}, None), json.dumps(tomb[:1])[:200])

print("== token rotation ==")
check("refresh", 200, req("POST", "/v1/auth/refresh", {"refresh_token": REFRESH}))
NEW = last_body.get("tokens", {})
check("new access works", 200, req("GET", "/v1/me", None, NEW.get("access_token", "")))
check("replayed refresh token is refused", 401, req("POST", "/v1/auth/refresh", {"refresh_token": REFRESH}))
expect("reuse is named", last_body.get("error", {}).get("code") == "refresh_reuse", json.dumps(last_body)[:200])
check("session killed after replay", 401, req("GET", "/v1/me", None, NEW.get("access_token", "")))
check("rotated refresh also dead", 401, req("POST", "/v1/auth/refresh", {"refresh_token": NEW.get("refresh_token", "")}))

print("== password change ==")
NEWPW = "a totally different passphrase 9"
check("wrong current password refused", 401, req("POST", "/v1/me/password",
      {"current_password": "not-the-password", "new_password": NEWPW}, ACCESS2))
check("same password refused", 422, req("POST", "/v1/me/password",
      {"current_password": PW, "new_password": PW}, ACCESS2))
check("change password", 200, req("POST", "/v1/me/password",
      {"current_password": PW, "new_password": NEWPW}, ACCESS2))
check("old password no longer works", 401, req("POST", "/v1/auth/login", {"email": EMAIL, "password": PW}))
check("new password works", 200, req("POST", "/v1/auth/login", {"email": EMAIL, "password": NEWPW}))
FINAL = last_body.get("tokens", {}).get("access_token", "")

print("== logout ==")
check("logout", 200, req("POST", "/v1/auth/logout", None, FINAL))
check("token dead after logout", 401, req("GET", "/v1/me", None, FINAL))

print("== account deletion ==")
check("login again", 200, req("POST", "/v1/auth/login", {"email": EMAIL, "password": NEWPW}))
DEL = last_body.get("tokens", {}).get("access_token", "")
check("delete needs confirmation", 422, req("DELETE", "/v1/me", {"password": NEWPW, "confirm": "yes"}, DEL))
check("delete needs the right password", 401, req("DELETE", "/v1/me",
      {"password": "wrong-password-here", "confirm": "DELETE"}, DEL))
check("delete account", 200, req("DELETE", "/v1/me", {"password": NEWPW, "confirm": "DELETE"}, DEL))
check("token dead after deletion", 401, req("GET", "/v1/me", None, DEL))
check("cannot log in to deleted account", 401, req("POST", "/v1/auth/login", {"email": EMAIL, "password": NEWPW}))

print()
print(f"passed: {passed}   failed: {failed}")
sys.exit(1 if failed else 0)
