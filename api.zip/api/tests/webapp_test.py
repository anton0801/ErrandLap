#!/usr/bin/env python3
"""The WebView mini-app: does the cookie actually carry the progress, and can a
round be faked? Run against a live instance."""
import json
import http.cookiejar
import urllib.error
import urllib.request

BASE = "http://127.0.0.1:8799"
passed = failed = 0


def client():
    """A fresh 'device': its own cookie jar, like a WebView with no cookies yet."""
    jar = http.cookiejar.CookieJar()
    return urllib.request.build_opener(urllib.request.HTTPCookieProcessor(jar)), jar


def call(opener, path, body=None, method=None):
    data = json.dumps(body).encode() if body is not None else None
    request = urllib.request.Request(BASE + path, data=data, method=method or ("POST" if data else "GET"))
    if data is not None:
        request.add_header("Content-Type", "application/json")
    try:
        with opener.open(request) as response:
            raw = response.read()
            return response.status, response.headers, (json.loads(raw) if raw[:1] in (b"{", b"[") else raw)
    except urllib.error.HTTPError as error:
        raw = error.read()
        try:
            return error.code, error.headers, json.loads(raw)
        except json.JSONDecodeError:
            return error.code, error.headers, raw


def check(label, condition, detail=""):
    global passed, failed
    if condition:
        print(f"  ok   {label}")
        passed += 1
    else:
        print(f"  FAIL {label} — {str(detail)[:170]}")
        failed += 1


ROUND = {"score": 480, "combo": 22, "sparks": 30, "duration_ms": 45000}

print("== a device opens the WebView for the first time ==")
app, jar = client()
status, headers, body = call(app, "/app")
check("page loads", status == 200 and b"Spark" in body or b"Run" in body, status)
cookie = headers.get("Set-Cookie") or ""
check("a cookie is set on first visit", "er_play=" in cookie, cookie[:80])
check("cookie is HttpOnly", "HttpOnly" in cookie, cookie[:120])
check("cookie is long-lived", "expires=" in cookie.lower(), cookie[:120])
check("cookie is SameSite=Lax", "SameSite=Lax" in cookie, cookie[:120])
check("cookie value carries no data", "erp_" in cookie and "@" not in cookie, cookie[:60])

status, headers, body = call(app, "/app/api/state")
check("state reads back", status == 200 and "player" in body, body)
check("new player starts empty", body["player"]["best_score"] == 0, body["player"])
check("season comes from the server", body["season"]["name"].endswith("Run"), body.get("season"))
check("everyone gets the same daily seed", isinstance(body["season"]["seed"], int), body["season"].get("seed"))

print("== playing a round ==")
status, headers, body = call(app, "/app/api/round", ROUND)
check("round accepted", status == 200, body)
check("best score recorded", body["player"]["best_score"] == 480, body.get("player"))
check("streak starts at one", body["player"]["streak_days"] == 1, body.get("player"))
check("sparks counted", body["player"]["sparks_caught"] == 30, body.get("player"))

status, headers, body = call(app, "/app/api/round", {**ROUND, "score": 300})
check("a worse round does not lower the best", body["player"]["best_score"] == 480, body.get("player"))
check("rounds keep counting", body["player"]["rounds_played"] == 2, body.get("player"))

print("== the app is closed and reopened (same cookie jar) ==")
status, headers, body = call(app, "/app/api/state")
check("progress survives", body["player"]["best_score"] == 480, body.get("player"))
status, headers, page = call(app, "/app")
check("page is rendered with the stored best", b'data-best="480"' in page, page[:200])
check("visits are counted", b'data-visits="2"' in page, page[:300])

print("== a different device is a different player ==")
other, _ = client()
status, headers, body = call(other, "/app/api/state")
check("a fresh cookie jar sees nothing", body["player"]["best_score"] == 0, body.get("player"))
check("and its own visit count", body["player"]["rounds_played"] == 0, body.get("player"))

print("== a forged cookie cannot pick up someone else's progress ==")
forged, forged_jar = client()
call(forged, "/app/api/state")
fake = http.cookiejar.Cookie(
    version=0, name="er_play", value="erp_this-value-was-made-up", port=None, port_specified=False,
    domain="127.0.0.1", domain_specified=False, domain_initial_dot=False, path="/", path_specified=True,
    secure=False, expires=None, discard=False, comment=None, comment_url=None, rest={}, rfc2109=False)
forged_jar.clear()
forged_jar.set_cookie(fake)
status, headers, body = call(forged, "/app/api/state")
check("unknown cookie starts a new player", status == 200 and body["player"]["best_score"] == 0, body.get("player"))

print("== rounds that did not happen ==")
status, headers, body = call(app, "/app/api/round", {**ROUND, "duration_ms": 900})
check("a two-second 'round' is refused", status == 400, (status, body))
status, headers, body = call(app, "/app/api/round", {**ROUND, "duration_ms": 400000})
check("a seven-minute 'round' is refused", status == 400, (status, body))
status, headers, body = call(app, "/app/api/round", {"score": 99999, "combo": 5, "sparks": 3, "duration_ms": 45000})
check("a score the sparks cannot justify is refused", status == 400, (status, body))
status, headers, body = call(app, "/app/api/round", {**ROUND, "cheat": True})
check("unexpected fields are refused", status == 422, (status, body))
status, headers, body = call(app, "/app/api/round", {"score": -5, "combo": 1, "sparks": 1, "duration_ms": 45000})
check("a negative score is refused", status == 422, (status, body))

status, headers, body = call(app, "/app/api/state")
check("the refused rounds changed nothing", body["player"]["best_score"] == 480, body.get("player"))

print("== the mini-app cannot reach the account API ==")
status, headers, body = call(app, "/v1/me")
check("no account access from a game cookie", status == 401, (status, body))
status, headers, body = call(app, "/v1/sync")
check("no sync access either", status == 401, (status, body))

print("== assets ==")
status, headers, body = call(app, "/app/spark.js")
check("script is served as javascript", status == 200 and "javascript" in headers.get("Content-Type", ""), headers.get("Content-Type"))
check("script is cacheable", "max-age" in (headers.get("Cache-Control") or ""), headers.get("Cache-Control"))
etag = headers.get("ETag")
check("script has an ETag", bool(etag), etag)
status, headers, body = call(app, "/app/spark.css")
check("stylesheet is served as css", status == 200 and "text/css" in headers.get("Content-Type", ""), headers.get("Content-Type"))
status, headers, body = call(app, "/app/../.env")
check("no path traversal out of /app", status in (400, 403, 404), status)

print()
print(f"passed: {passed}   failed: {failed}")
raise SystemExit(1 if failed else 0)
