<?php

declare(strict_types=1);

/**
 * Errand Run API — front controller.
 *
 * Everything enters here: one router, one error funnel, one place where the
 * bearer token is turned into an authenticated user.
 */

use ErrandRun\Controllers\AuthController;
use ErrandRun\Controllers\PageController;
use ErrandRun\Controllers\ProfileController;
use ErrandRun\Controllers\ResourceController;
use ErrandRun\Controllers\SyncController;
use ErrandRun\Controllers\WebAppController;
use ErrandRun\Core\ApiException;
use ErrandRun\Core\AppTarget;
use ErrandRun\Core\Clock;
use ErrandRun\Core\Config;
use ErrandRun\Core\Database;
use ErrandRun\Core\Request;
use ErrandRun\Core\Response;
use ErrandRun\Core\Router;
use ErrandRun\Http\AuthContext;
use ErrandRun\Security\RateLimiter;
use ErrandRun\Security\TokenService;

// ---------------------------------------------------------------------------
// Bootstrap
// ---------------------------------------------------------------------------

const ERRANDRUN_ROOT = __DIR__ . '/..';

// Said plainly, before anything else can fail with a parse error instead.
if (PHP_VERSION_ID < 80100) {
    http_response_code(500);
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode([
        'error' => [
            'code'    => 'php_version',
            'message' => 'This API needs PHP 8.1 or newer. Running ' . PHP_VERSION
                . '. On shared hosting the version is switched in the control panel.',
        ],
    ]);
    exit;
}

spl_autoload_register(static function (string $class): void {
    $prefix = 'ErrandRun\\';
    if (!str_starts_with($class, $prefix)) {
        return;
    }
    $relative = str_replace('\\', '/', substr($class, strlen($prefix)));
    $file = ERRANDRUN_ROOT . '/src/' . $relative . '.php';
    if (is_file($file)) {
        require_once $file;
    }
});

Config::load(
    ERRANDRUN_ROOT . '/.env',
    ERRANDRUN_ROOT . '/errandrun.env',
    ERRANDRUN_ROOT . '/config/errandrun.env',
);

// Errors are for the log, never for the client.
error_reporting(E_ALL);
ini_set('display_errors', '0');
ini_set('log_errors', '1');
$logFile = Config::get('ERROR_LOG', '');
if ($logFile !== null && $logFile !== '') {
    ini_set('error_log', $logFile);
}
date_default_timezone_set('UTC');

set_error_handler(static function (int $severity, string $message, string $file, int $line): bool {
    if ((error_reporting() & $severity) === 0) {
        return false;
    }
    throw new ErrorException($message, 0, $severity, $file, $line);
});

$request = null;

try {
    $request = Request::capture();

    $https = $request->isSecure();
    Response::securityHeaders($https);
    header('X-Request-Id: ' . $request->requestId);

    // The app reads this on its very first request, whatever that request is.
    AppTarget::send();

    // Transport: plain HTTP is only ever tolerated on a developer machine.
    if (!$https && !Config::bool('ALLOW_INSECURE_HTTP', false)) {
        throw ApiException::forbidden('This API is only served over HTTPS.');
    }

    // The mobile client is not a browser: cross-origin access stays off unless
    // an origin is explicitly allowed in configuration.
    $origin = $request->header('origin');
    if ($origin !== null && $origin !== '') {
        $allowed = Config::list('CORS_ALLOWED_ORIGINS');
        if (in_array($origin, $allowed, true)) {
            header('Access-Control-Allow-Origin: ' . $origin);
            header('Vary: Origin');
            header('Access-Control-Allow-Headers: Authorization, Content-Type, X-Request-Id');
            header('Access-Control-Allow-Methods: GET, POST, PUT, PATCH, DELETE, OPTIONS');
            header('Access-Control-Max-Age: 600');
        } else {
            throw ApiException::forbidden('This origin is not allowed.');
        }
    }

    if ($request->method === 'OPTIONS') {
        http_response_code(204);
        exit;
    }

    // A blunt ceiling per address, before anything touches the account tables.
    RateLimiter::hit(RateLimiter::bucket('global:ip', $request->ip), Config::int('RATE_GLOBAL_PER_IP', 600), 60);
    RateLimiter::sweep();

    // -----------------------------------------------------------------------
    // Routes
    // -----------------------------------------------------------------------

    $pages = new PageController();
    $auth = new AuthController();
    $profile = new ProfileController();
    $resources = new ResourceController();
    $sync = new SyncController();
    $webApp = new WebAppController();

    $router = new Router();

    // Public pages. The App Store asks for a privacy address and a support
    // address, and both live here beside the API.
    $router->get('/', static fn (Request $r) => $pages->home($r), auth: false);
    $router->get('/conditions-privacy', static fn (Request $r) => $pages->privacy($r), auth: false);
    $router->get('/support', static fn (Request $r) => $pages->support($r), auth: false);
    $router->get('/favicon.svg', static fn (Request $r) => $pages->favicon($r), auth: false);
    $router->get('/favicon.ico', static fn (Request $r) => $pages->favicon($r), auth: false);
    $router->get('/robots.txt', static fn (Request $r) => $pages->robots($r), auth: false);

    // The mini-app the native side opens in a WebView. Identified by a cookie,
    // never by an account: nothing here can reach anyone's errands.
    $router->get('/app', static fn (Request $r) => $webApp->page($r), auth: false);
    $router->get('/app/spark.css', static fn (Request $r) => $webApp->styles($r), auth: false);
    $router->get('/app/spark.js', static fn (Request $r) => $webApp->script($r), auth: false);
    $router->get('/app/api/state', static fn (Request $r) => $webApp->state($r), auth: false);
    $router->post('/app/api/round', static fn (Request $r) => $webApp->round($r), auth: false);

    $router->get('/v1/health', static function (Request $r): void {
        Response::json([
            'status'      => 'ok',
            'server_time' => Clock::iso(),
            'api'         => 'errandrun',
            'version'     => Config::get('API_VERSION', '1.0.0'),
            'app_target'  => AppTarget::isOn(),
        ]);
    }, auth: false);

    $router->post('/v1/auth/register', static fn (Request $r) => $auth->register($r), auth: false);
    $router->post('/v1/auth/login', static fn (Request $r) => $auth->login($r), auth: false);
    $router->post('/v1/auth/refresh', static fn (Request $r) => $auth->refresh($r), auth: false);
    $router->post('/v1/auth/logout', static fn (Request $r, AuthContext $a) => $auth->logout($r, $a));
    $router->post('/v1/auth/logout-all', static fn (Request $r, AuthContext $a) => $auth->logoutAll($r, $a));

    $router->get('/v1/me', static fn (Request $r, AuthContext $a) => $profile->show($r, $a));
    $router->patch('/v1/me', static fn (Request $r, AuthContext $a) => $profile->update($r, $a));
    $router->delete('/v1/me', static fn (Request $r, AuthContext $a) => $profile->destroy($r, $a));
    $router->post('/v1/me/password', static fn (Request $r, AuthContext $a) => $profile->changePassword($r, $a));
    $router->get('/v1/me/sessions', static fn (Request $r, AuthContext $a) => $profile->sessions($r, $a));
    $router->delete('/v1/me/sessions/{id}', static fn (Request $r, AuthContext $a, array $p) => $profile->revokeSession($r, $a, $p));

    $router->get('/v1/sync', static fn (Request $r, AuthContext $a) => $sync->pull($r, $a));
    $router->post('/v1/sync', static fn (Request $r, AuthContext $a) => $sync->push($r, $a));

    $router->get('/v1/{collection}', static fn (Request $r, AuthContext $a, array $p) => $resources->index($r, $a, $p));
    $router->post('/v1/{collection}', static fn (Request $r, AuthContext $a, array $p) => $resources->store($r, $a, $p));
    $router->get('/v1/{collection}/{id}', static fn (Request $r, AuthContext $a, array $p) => $resources->show($r, $a, $p));
    $router->put('/v1/{collection}/{id}', static fn (Request $r, AuthContext $a, array $p) => $resources->update($r, $a, $p));
    $router->patch('/v1/{collection}/{id}', static fn (Request $r, AuthContext $a, array $p) => $resources->update($r, $a, $p));
    $router->delete('/v1/{collection}/{id}', static fn (Request $r, AuthContext $a, array $p) => $resources->destroy($r, $a, $p));

    // -----------------------------------------------------------------------
    // Dispatch
    // -----------------------------------------------------------------------

    $route = $router->match($request);
    $context = null;

    if ($route['auth']) {
        $token = $request->bearerToken();
        if ($token === null) {
            throw ApiException::unauthorized('Send an access token: Authorization: Bearer <token>.');
        }
        $resolved = TokenService::authenticate($token);
        $context = new AuthContext(
            userId: (string) $resolved['session']['user_id'],
            sessionId: (string) $resolved['session']['id'],
            user: $resolved['user'],
        );
    }

    $handler = $route['handler'];
    if ($route['auth']) {
        $handler($request, $context, $route['params']);
    } else {
        $handler($request, $route['params']);
    }
} catch (ApiException $exception) {
    // Outside /v1 the caller is a browser unless it says otherwise, so a wrong
    // address gets a page rather than a JSON object.
    $wantsPage = $exception->status() === 404
        && $request !== null
        && !str_starts_with($request->path, '/v1')
        && !str_contains(strtolower($request->header('accept') ?? ''), 'application/json');

    if ($wantsPage) {
        (new PageController())->notFound($request);
    } else {
        Response::error(
            $exception->status(),
            $exception->code(),
            $exception->getMessage(),
            $exception->details(),
            $exception->headers(),
        );
    }
} catch (Throwable $error) {
    $reference = bin2hex(random_bytes(6));
    error_log(sprintf(
        '[errandrun][%s] %s in %s:%d%s%s',
        $reference,
        $error->getMessage(),
        $error->getFile(),
        $error->getLine(),
        PHP_EOL,
        $error->getTraceAsString(),
    ));

    if (Config::bool('DEBUG', false)) {
        Response::error(500, 'server_error', $error->getMessage(), [
            'reference' => $reference,
            'file'      => $error->getFile(),
            'line'      => $error->getLine(),
        ]);
    } else {
        Response::error(500, 'server_error', 'Something went wrong on our side.', ['reference' => $reference]);
    }
}
