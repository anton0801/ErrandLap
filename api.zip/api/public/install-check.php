<?php

declare(strict_types=1);

/**
 * Self-check for a fresh install.
 *
 * Shared hosting fails in a handful of predictable ways, and most of them look
 * identical from the outside. This page names the one that is actually wrong.
 *
 * It answers only when SETUP_CHECK_TOKEN is set in the configuration and the
 * same value arrives as ?token=… — with no token configured it does not exist.
 * Clear the value once the install is working.
 *
 *   https://your-domain/install-check.php?token=…
 */

const ERRANDRUN_ROOT = __DIR__ . '/..';

require_once ERRANDRUN_ROOT . '/src/Core/Config.php';

use ErrandRun\Core\Config;

Config::load(
    ERRANDRUN_ROOT . '/.env',
    ERRANDRUN_ROOT . '/errandrun.env',
    ERRANDRUN_ROOT . '/config/errandrun.env',
);

header('Content-Type: application/json; charset=utf-8');
header('Cache-Control: no-store');
header('X-Robots-Tag: noindex, nofollow');

$expected = (string) Config::get('SETUP_CHECK_TOKEN', '');
$given = (string) ($_GET['token'] ?? '');

if ($expected === '' || strlen($given) < 8 || !hash_equals($expected, $given)) {
    http_response_code(404);
    echo json_encode(['error' => ['code' => 'not_found', 'message' => 'Not found.']]);
    exit;
}

$checks = [];
$failed = 0;

function check(string $name, bool $ok, string $detail, string $fix = ''): void
{
    global $checks, $failed;
    if (!$ok) {
        $failed++;
    }
    $checks[] = array_filter([
        'check'  => $name,
        'status' => $ok ? 'ok' : 'FAILED',
        'detail' => $detail,
        'fix'    => $ok ? null : ($fix === '' ? null : $fix),
    ], static fn ($value) => $value !== null);
}

// --- PHP ---------------------------------------------------------------------

check(
    'PHP version',
    PHP_VERSION_ID >= 80100,
    PHP_VERSION,
    'Switch the PHP version to 8.1 or newer in the hosting control panel.',
);

foreach (['pdo_mysql', 'json', 'mbstring', 'openssl', 'filter'] as $extension) {
    check(
        "Extension {$extension}",
        extension_loaded($extension),
        extension_loaded($extension) ? 'loaded' : 'missing',
        'Enable it in the PHP settings of the control panel.',
    );
}

check(
    'Password hashing',
    defined('PASSWORD_ARGON2ID') || defined('PASSWORD_BCRYPT'),
    defined('PASSWORD_ARGON2ID') ? 'Argon2id available' : 'bcrypt only (still fine)',
);

// --- Configuration -----------------------------------------------------------

$envFound = null;
foreach (['/.env', '/errandrun.env', '/config/errandrun.env'] as $candidate) {
    if (is_readable(ERRANDRUN_ROOT . $candidate)) {
        $envFound = $candidate;
        break;
    }
}
check(
    'Configuration file',
    $envFound !== null,
    $envFound ?? 'none of .env, errandrun.env, config/errandrun.env was found',
    'Upload .env next to the public/ folder. If the file manager hides dot-files, name it errandrun.env instead.',
);

foreach (['DB_NAME', 'DB_USER'] as $key) {
    $value = (string) Config::get($key, '');
    check("Setting {$key}", $value !== '', $value !== '' ? 'set' : 'empty', 'Fill it in the configuration file.');
}

// --- Web server --------------------------------------------------------------

$authorization = $_SERVER['HTTP_AUTHORIZATION']
    ?? $_SERVER['REDIRECT_HTTP_AUTHORIZATION']
    ?? null;

if ($authorization === null && function_exists('apache_request_headers')) {
    foreach (apache_request_headers() as $name => $value) {
        if (strtolower((string) $name) === 'authorization') {
            $authorization = $value;
        }
    }
}

$sentAuthorization = isset($_GET['auth_probe']);
check(
    'Authorization header reaches PHP',
    !$sentAuthorization || is_string($authorization),
    $sentAuthorization
        ? (is_string($authorization) ? 'received' : 'lost before PHP')
        : 'not tested — add &auth_probe=1 and send an Authorization header',
    'Check that the .htaccess rule setting E=HTTP_AUTHORIZATION is present and that mod_rewrite is enabled.',
);

$https = (($_SERVER['HTTPS'] ?? '') !== '' && strtolower((string) $_SERVER['HTTPS']) !== 'off')
    || (int) ($_SERVER['SERVER_PORT'] ?? 0) === 443
    || strtolower((string) ($_SERVER['REQUEST_SCHEME'] ?? '')) === 'https';
check(
    'HTTPS detected',
    $https || Config::bool('ALLOW_INSECURE_HTTP', false),
    $https ? 'yes' : 'no',
    'Open this page over https://. If the certificate is issued and it still says no, set TRUSTED_PROXIES to your proxy address.',
);

// --- Database ----------------------------------------------------------------

$expectedTables = [
    'users', 'sessions', 'auth_events', 'rate_limits', 'user_settings',
    'places', 'errands', 'windows', 'runs', 'visits', 'wasted_trips', 'travel_times',
];

try {
    $host = Config::get('DB_HOST', 'localhost');
    $port = (int) Config::get('DB_PORT', '3306');
    $name = (string) Config::get('DB_NAME', '');
    $socket = (string) Config::get('DB_SOCKET', '');

    $dsn = $socket !== ''
        ? sprintf('mysql:unix_socket=%s;dbname=%s;charset=utf8mb4', $socket, $name)
        : sprintf('mysql:host=%s;port=%d;dbname=%s;charset=utf8mb4', $host, $port, $name);

    $pdo = new PDO($dsn, (string) Config::get('DB_USER', ''), (string) Config::get('DB_PASSWORD', ''), [
        PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
        PDO::ATTR_TIMEOUT => 5,
    ]);

    $version = (string) $pdo->getAttribute(PDO::ATTR_SERVER_VERSION);
    check('Database connection', true, $version);

    $found = [];
    $statement = $pdo->query('SHOW TABLES');
    foreach ($statement->fetchAll(PDO::FETCH_COLUMN) as $table) {
        $found[] = (string) $table;
    }

    $missing = array_values(array_diff($expectedTables, $found));
    check(
        'Tables',
        $missing === [],
        $missing === [] ? count($expectedTables) . ' of ' . count($expectedTables) . ' present' : 'missing: ' . implode(', ', $missing),
        'Import database/install.sql through phpMyAdmin into this database.',
    );

    $pdo->prepare('SELECT COUNT(*) FROM users')->execute();
    check('Read access', true, 'SELECT works');
} catch (Throwable $error) {
    check(
        'Database connection',
        false,
        $error->getMessage(),
        'Check DB_HOST (usually localhost on shared hosting), DB_NAME, DB_USER and DB_PASSWORD in the configuration file.',
    );
}

// --- Filesystem ---------------------------------------------------------------

check(
    'Source files in place',
    is_file(ERRANDRUN_ROOT . '/src/Core/Database.php') && is_file(ERRANDRUN_ROOT . '/src/Controllers/AuthController.php'),
    is_dir(ERRANDRUN_ROOT . '/src') ? 'src/ found' : 'src/ is missing',
    'Upload the whole api/ folder, not only public/.',
);

http_response_code($failed === 0 ? 200 : 500);
echo json_encode([
    'ready'  => $failed === 0,
    'failed' => $failed,
    'checks' => $checks,
    'next'   => $failed === 0
        ? 'Everything is in place. Clear SETUP_CHECK_TOKEN in the configuration file, then point the app at https://' . ($_SERVER['HTTP_HOST'] ?? 'your-domain') . '/'
        : 'Fix the lines marked FAILED and reload this page.',
], JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);
