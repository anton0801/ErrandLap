# Errand Run API

REST API for the Errand Run iOS app. PHP 8.2+ and MySQL 8.0.19+ (tested on PHP 8.5 and
MySQL 9.7). No framework, no Composer dependencies — the whole surface is in `src/`.

The app stays usable offline: the phone keeps its own copy and the API is the place
where that copy lives between devices. Every request is authenticated with a bearer
token; there is no anonymous read or write anywhere except `/v1/health`.

---

## Install

```bash
# 1. Database and a dedicated account (never use root from the app)
mysql -u root -e "CREATE DATABASE errandrun CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci"
mysql -u root errandrun < database/install.sql
mysql -u root -e "CREATE USER 'errandrun'@'127.0.0.1' IDENTIFIED BY 'a-long-random-password';
                  GRANT SELECT, INSERT, UPDATE, DELETE ON errandrun.* TO 'errandrun'@'127.0.0.1';"

# 2. Configuration
cp .env.example .env
chmod 600 .env          # the file holds the database password
$EDITOR .env

# 3. Web server
#    Document root MUST be api/public — src/, .env and database/ stay outside it.
#    nginx: see deploy/nginx.conf.example    Apache: public/.htaccess is included.
```

**Shared hosting (Hostinger and friends)** — where everything has to live inside
`public_html` and PHP runs as CGI: upload the whole `api/` folder there, put
`deploy/hostinger/.htaccess` at `public_html/.htaccess`, and follow
[deploy/hostinger/УСТАНОВКА.md](deploy/hostinger/УСТАНОВКА.md). That `.htaccess`
does three things the API cannot do for itself: route every request to
`public/index.php`, keep `src/`, `.env` and the SQL dump unreachable, and pass the
`Authorization` header through to PHP — CGI drops it otherwise, and every
authenticated request would fail with no obvious reason.

Requires **PHP 8.1+**. MySQL 5.7+/8/9 and MariaDB 10.2+ are both supported; the
upsert syntax adapts to whichever is there.

Local development only:

```bash
php -S 127.0.0.1:8799 -t public public/index.php
# and set ALLOW_INSECURE_HTTP=true in .env — never do this on a public host
```

The `errandrun` database account is granted `SELECT, INSERT, UPDATE, DELETE` and nothing
else: the running application cannot drop a table or change the schema.

---

## Endpoints

| Method | Path | Auth | Purpose |
|---|---|---|---|
| GET | `/` | — | Front page |
| GET | `/conditions-privacy` | — | Privacy policy (the URL App Store Connect asks for) |
| GET | `/support` | — | Support page (the other URL it asks for) |
| GET | `/v1/health` | — | Liveness and server time |
| POST | `/v1/auth/register` | — | Create an account, returns the first token pair |
| POST | `/v1/auth/login` | — | Sign in on a device |
| POST | `/v1/auth/refresh` | — | Exchange a refresh token for a new pair |
| POST | `/v1/auth/logout` | token | End the current session |
| POST | `/v1/auth/logout-all` | token | End every session of the account |
| GET | `/v1/me` | token | Profile, settings and row counts |
| PATCH | `/v1/me` | token | Change display name or email (email needs the password) |
| POST | `/v1/me/password` | token | Change password (ends other sessions by default) |
| DELETE | `/v1/me` | token | Delete the account and all of its data |
| GET | `/v1/me/sessions` | token | List signed-in devices |
| DELETE | `/v1/me/sessions/{id}` | token | Sign one device out remotely |
| GET | `/v1/sync?since=…` | token | Everything changed since a moment |
| POST | `/v1/sync` | token | Push a batch of changes and pull the delta back |
| GET | `/v1/{collection}` | token | List a collection (`?since=`, `?include_deleted=1`) |
| POST | `/v1/{collection}` | token | Create or replace one item |
| GET | `/v1/{collection}/{id}` | token | Read one item |
| PUT / PATCH | `/v1/{collection}/{id}` | token | Replace one item |
| DELETE | `/v1/{collection}/{id}` | token | Delete one item (leaves a tombstone) |

Collections: `places`, `errands`, `windows`, `runs`, `visits`, `wasted-trips`, `travel-times`.

Errors always look the same:

```json
{ "error": { "code": "validation_failed", "message": "Some fields are not valid.",
             "details": { "fields": { "password": "At least 10 characters." } } } }
```

---

## Public pages

`/`, `/conditions-privacy` and `/support` are served by the same front controller, in the
app's own visual language: no scripts, no external requests, no fonts or images fetched from
anywhere — the CSP for those pages is `default-src 'none'`. The privacy page describes what
the code in `src/` actually stores, so it stays true as long as both change together.

Names, email and links come from configuration (`SITE_OWNER`, `SUPPORT_EMAIL`,
`APP_STORE_URL`, `SITE_REGION`, `PRIVACY_UPDATED`) — nothing about the operator is written
into the source. Set `SITE_OWNER` and `SUPPORT_EMAIL` before submitting to the App Store.
Page text lives in `src/Views/`.

## The WebView mini-app

`/app` serves **Spark Run**, a 45-second seasonal game the native app opens in a WebView.
It is deliberately separate from everything else:

- **Identity is one cookie.** `er_play` carries a random value and nothing else; the server
  keeps only its SHA-256 hash, alongside a best score, a round count and a day streak.
  Two years, `HttpOnly`, `Secure`, `SameSite=Lax`, refreshed on every visit.
- **No account, no token, no personal data.** A game cookie cannot reach `/v1` — the tests
  check that it gets a 401 there.
- **Rounds are checked before they are recorded**: a round has to last about as long as a
  round does, and a score has to be justified by the sparks caught.
- The page loads no outside host and runs no inline code: `script-src 'self'`.

The season comes from the server clock, so everyone is in the same season on the same day and
a phone with a wrong clock cannot pick an easier one. `src/Web/Season.php` holds the four
seasons, `src/Views/webapp.php` the page, `src/Web/assets/` the styles and the game.

### The bridge to the host

The page posts to `window.webkit.messageHandlers.errandrun` when it exists, and calls
`window.ErrandRunNative.postMessage(json)` otherwise. Every call is optional — with no host
listening, the game just works.

| Message | When | Payload |
|---|---|---|
| `ready` | On load | `{game}` |
| `roundStarted` | A round begins | — |
| `roundFinished` | A round ends | `{score, sparks}` |
| `haptic` | On a hit, a miss or a best | `{style: light\|success\|warning}` |
| `close` | The close button, shown only when a host answered `ready` | — |

The host may call back into the page: `window.ErrandRunWeb.pause()` and `.resume()`.

### Database

The mini-app needs the `web_players` table. It is part of `database/install.sql`; a database
imported before this feature existed takes `database/upgrade-01-webview.sql`.

## The app-target switch

One row, one column, read by the app on launch.

```sql
-- turn it on
UPDATE onAnalytics SET isOn = 1, updated_at = UTC_TIMESTAMP(3) WHERE id = 1;
-- turn it off
UPDATE onAnalytics SET isOn = 0, updated_at = UTC_TIMESTAMP(3) WHERE id = 1;
```

Its value goes out on **every** response, success or failure:

```
X-App-Target: true          X-App-Target: false
```

`GET /v1/health` also carries it in the body as `app_target`, which makes it easy to
check with curl and gives the app a request it can make before anyone has signed in.

If the table is missing — a database imported before this feature — the flag reads as
`false` and nothing else breaks. `database/upgrade-02-app-target.sql` adds it.

## Authentication

```
POST /v1/auth/login  { "email": "…", "password": "…", "device_name": "iPhone 16" }
→ { "user": {…}, "tokens": { "access_token": "era_…", "refresh_token": "err_…",
                             "access_expires_at": "…", "refresh_expires_at": "…" } }

Every later request:   Authorization: Bearer era_…
When the access token expires (401 token_expired):
POST /v1/auth/refresh { "refresh_token": "err_…" }   → a brand-new pair
```

- **Access token** — opaque, 256 bits of randomness, valid one hour by default.
- **Refresh token** — opaque, valid 30 days, **rotated on every use**.
- Tokens are stored as SHA-256 hashes. A database dump contains no usable session.
- Replaying a refresh token that was already rotated is treated as theft: that session is
  revoked immediately and the event is logged (`refresh_reuse`).

## What protects the data

| Concern | How it is handled |
|---|---|
| Passwords | Argon2id (64 MiB, t=4, p=2), rehashed automatically when parameters change |
| Password policy | ≥10 characters, not a common password, must not contain the email or name |
| Credential stuffing | Per-IP and per-email throttling, plus a 15-minute account lock after 10 failures |
| Account enumeration | Identical message and identical work for "no such user" and "wrong password" |
| SQL injection | PDO with emulation **off**; every value is a bound parameter, table names come from a fixed map |
| Mass assignment | Whitelist validation; an unexpected field is a 422, never a silent write |
| Cross-account access | Tables are keyed `(user_id, id)` and every statement is scoped to the token's user |
| Transport | HTTPS enforced in code and at the web server; HSTS; TLS 1.2+ |
| Caching of personal data | `Cache-Control: no-store` on every response |
| Browser attack surface | CSP `default-src 'none'`, `X-Frame-Options: DENY`, no CORS unless configured |
| Payload abuse | 1 MB body limit, 32 KB per item, 500 items per push, depth limit 8 |
| Leaked internals | Any unexpected exception becomes a 500 with a reference id; the detail goes to the log |
| Audit | Every account event recorded with a hashed email, IP and user agent |
| Deletion | `ON DELETE CASCADE` from `users`; tokens revoked first; only a hashed email survives in the log |

## Sync protocol

Each item travels in the same envelope:

```json
{ "id": "UUID", "updated_at": "2026-08-13T17:10:00.000Z", "deleted": false,
  "payload": { …the model as the app stores it… } }
```

`updated_at` is the moment **the user edited it**, kept by the client. Conflicts are settled
by that timestamp: the newer edit wins, the loser comes back in `conflicts` so the client can
adopt it without another round trip. A client clock more than five minutes ahead is clamped,
so a wrong device clock cannot win every conflict forever.

Deletes leave a tombstone (`deleted: true`, payload emptied) so other devices learn about
them; tombstones are purged after `TOMBSTONE_DAYS`.

```
POST /v1/sync
{ "since": "2026-08-13T12:00:00.000Z",
  "settings": { "updated_at": "…", "payload": {…} },
  "errands":  [ {…}, {…} ],
  "places":   [ {…} ] }
→ { "server_time": "…", "applied": {"errands": 2}, "conflicts": {},
    "errands": [ …everything changed on the server since "since"… ], … }
```

## Operations

- Point `ERROR_LOG` at a file the web server can write; nothing is ever printed to the client.
- `rate_limits` and expired sessions are swept opportunistically; no cron is required.
- To rotate the database password: update `.env` and `ALTER USER` — no code change.
- Set `DEBUG=false` in production (it is the default). With `DEBUG=true` a 500 also returns
  the exception message.

## Tests

`tests/api_test.py` exercises the whole surface against a running instance, including the
paths that must fail: expired and forged tokens, refresh replay, throttling, cross-account
reads and writes, stale-edit conflicts, and account deletion.

```bash
php -S 127.0.0.1:8799 -t public public/index.php &
python3 tests/api_test.py
```

---

## Client contract notes

- **Endpoints inside payloads** (`from` / `to` on a window or a run) travel as one string:
  `"home"`, `"work"`, `"place:<UUID>"`, `"custom:<label>"`. A nested one-key object would
  not survive a PHP `json_decode`/`json_encode` round trip — an empty JSON object comes back
  as an empty array — so the flat string is part of the contract.
- **Timestamps** are ISO-8601 UTC with milliseconds (`2026-08-13T17:10:00.000Z`). The API
  accepts both with and without the fractional part; it always answers with it.
- **Ids** are UUIDs generated by the client, uppercased by the server. Travel-time keys are
  free-form strings up to 190 printable characters.

### Configuring the app

`ErrandRun/Network/APIClient.swift` holds `APIConfiguration`:

- `baseURL` — the development default is `http://127.0.0.1:8799` (loopback is exempt from
  App Transport Security); release builds use the HTTPS URL you set there. A `ERAPIBaseURL`
  value in `UserDefaults` overrides both, which is handy for a staging build.
- `pinnedPublicKeyHashes` — leave empty for standard trust, or add base64 SHA-256 hashes of
  the server's public key to pin it:

```bash
openssl s_client -connect runoferrandapp.site:443 </dev/null 2>/dev/null \
  | openssl x509 -pubkey -noout \
  | openssl pkey -pubin -outform der \
  | openssl dgst -sha256 -binary | base64
```

### Wire-format test

`tests/wire/main.swift` compiles the app's own model types and runs them against a live API,
proving that what the app encodes is what the server stores and returns:

```bash
xcrun swiftc -O -o /tmp/wirecheck \
  ../ErrandRun/Model/ERTime.swift ../ErrandRun/Model/Models.swift \
  ../ErrandRun/Model/SyncState.swift ../ErrandRun/Design/Theme.swift \
  ../ErrandRun/Network/APIModels.swift tests/wire/main.swift
/tmp/wirecheck
```
